# ÖNEMLİ NOTLAR - SİSTEM KARARLILIĞI

## Çoklu TP (Take Profit) ve Stop Loss Özellikleri

Bu sistemdeki en önemli ve hassas özelliklerden biri çoklu take profit seviyeleri ve stop loss ile işlem açabilme ve kapatabilme özelliğidir. Bu özellik, kod tabanında birkaç kritik bölümün doğru çalışmasına bağlıdır.

### Kritik Bileşenler ve Koruma Altındaki Kodlar

#### 1. OKX API Entegrasyonu

`server/okx-api.ts` dosyasındaki şu fonksiyonlar çoklu TP için çok önemlidir:

- `createTakeProfitOrders` - Çoklu TP emirleri oluşturmak için özel fonksiyon
- `processSignal` - Sinyal işleme fonksiyonu
- `createOrder` - Emir oluşturma fonksiyonu

**ÖNEMLİ NOT 1**: `createTakeProfitOrders` fonksiyonunda "tag" parametresi kullanımından kaynaklanan bir hata tespit edildi ve düzeltildi. Gelecek güncellemelerde bu parametreyi tekrar eklemeyin. Bu parametre OKX API'da sorunlara yol açıyor.

**ÖNEMLİ NOT 2**: TP seviyelerinde lot/hacim değerleri doğru hesaplanmalı. Toplam işlem miktarı, TP seviyeleri arasında doğru oranlarda bölünmelidir.

#### 2. Webhook Sistemi

`server/routes.ts` dosyasındaki webhook handler (yaklaşık 520. satır), sistemi TradingView sinyalleriyle entegre eder. Bu kod aşağıdaki özellikleri korumalıdır:

- Bot ID'nin URL'den veya request body'den doğru şekilde alınması
- Placeholder değerlerin (BOT_ID veya <BOT_ID>) kontrolü ve reddedilmesi
- Boş bot_id değerleriyle gelen isteklerin düzgün şekilde işlenmesi

#### 3. Frontend Bileşenleri

`client/src/components/smart-trades/create-smart-trade-modal.tsx` ve `client/src/components/smart-trades/smart-trade-card.tsx` dosyaları, takeProfitLevels dizisi ve stopLoss değerlerini doğru şekilde işleyecek şekilde yapılandırılmıştır. Bu yapıyı değiştirirken dikkatli olunmalıdır.

### Güncelleme Yapmadan Önce Test Prosedürü

Herhangi bir güncelleme yapmadan önce şu adımları izleyin:

1. Yeni bir smart trade açın ve çoklu TP seviyeleri ile stop loss ayarlayın
2. Açılan pozisyonun tüm TP seviyelerinin doğru şekilde oluşturulduğunu OKX hesabından kontrol edin
3. Pozisyonu manuel olarak kapatın ve kapatma işleminin başarılı olduğunu doğrulayın
4. Bir sinyal botu oluşturun ve TradingView'den gelen webhook ile test edin
5. Bu testler başarılıysa, diğer özellikleri güvenle güncelleyebilirsiniz

### Acil Durum Prosedürü

Eğer bir güncelleme sonrası çoklu TP veya stop loss özellikleri bozulursa:

1. Son çalışan sürüme geri dönün
2. Sorunlu güncellemeyi ayrı bir branch'e taşıyın
3. Kritik bileşenlerdeki değişiklikleri izole edin ve tek tek test edin
4. Sorunu bulduğunuzda, bu dokümana belirtilen çözümü ekleyin

## Mevcut Bilinen Sorunlar ve Çözümleri

### Sorun 1: Webhook ile Bot ID İletimi

**Sorun Açıklaması**: Webhook URL'lerinde ve JSON içeriğinde placeholder değerler (<BOT_ID> veya BOT_ID) kullanıldığında, sistem bunları gerçek bot ID'leriyle değiştirmiyor.

**Çözüm**: Webhook URL'sini oluştururken placeholder değer olarak "BOT_ID" yerine, bot oluşturulduktan sonra gerçek bot ID'sini kullanın.

**İlgili Kod**: 
```javascript
// client/src/components/bots/create-bot-modal.tsx
const botId = editBot?.id || "BOT_ID";
const webhookUrl = window.location.protocol + "//" + window.location.host + "/api/bots/" + botId + "/signal";
```

### Sorun 2: Çoklu TP Emirleri Oluşturma

**Sorun Açıklaması**: "tag" parametresi kullanıldığında OKX API'da hatalar oluşuyor.

**Çözüm**: "tag" parametresini kaldırın ve tüm algo emirleri için aynı lot/hacim hesaplama yöntemini kullanın.

**İlgili Kod**: 
```javascript
// server/okx-api.ts - createTakeProfitOrders fonksiyonu
// Tag parametresi kaldırıldı ve hacim hesaplaması düzeltildi
```