# OKX Trading Bot Platform - Teknik Analiz ve Geliştirme Dokümanı

## Proje Özeti

Bu proje, TradingView'dan gelen sinyalleri kullanarak bireysel kullanıcıların OKX borsasında (şu anda demo hesap üzerinde, ileride gerçek hesaba geçiş planlanıyor) otomatik işlem yapabilecekleri bir platformdur. Kullanıcılar özel botlar oluşturarak kendi belirlediği işlem parametreleriyle (pozisyon büyüklüğü, kaldıraç, take profit, stop loss, vb.) otomatik alım-satım yapabilirler.

## Tespit Edilen Sorunlar ve Çözümleri

### 1. OKX API Pozisyon Kapatma Hatası

**Sorun:** İşlemler görünürde başarıyla kapatılıyor (veritabanında durum "CLOSED" olarak güncelleniyor) ancak borsa tarafında pozisyonlar açık kalıyor.

**Kök Neden:** API isteklerinde yanlış parametre formatı ve eksik parametre kullanımı:

1. OKX API'ye pozisyon sorgulamak için yapılan isteklerde `instType` ve `instId` parametreleri birlikte kullanılmadığından doğru pozisyonlar bulunamıyor
2. "BTC-USDT-SWAP" gibi bir değer gönderildiğinde API birden fazla parametre bekliyor:
   - `instType` = "SWAP" (işlem tipi)
   - `instId` = "BTC-USDT-SWAP" (enstrüman ID'si)

**Çözüm:** 

1. `server/okx-api.ts` dosyasındaki `getPositions` ve `getOpenOrders` fonksiyonları yeniden yazıldı:
   - Her iki fonksiyon da artık tek parametre üzerinden hem `instType` hem de `instId` değerlerini doğru formatta alıp gönderiyor
   - "BTC-USDT-SWAP" gibi bir değer geldiğinde, bu değerden otomatik olarak `instType` ve `instId` parametreleri çıkarılıyor

2. API istekleri için loglama geliştirmeleri yapıldı:
   - Her API isteği öncesi tam parametre seti loglanıyor
   - Hata durumlarında detaylı açıklamalar eklendi

3. Pozisyon kapatma işlemi iyileştirildi:
   - İlk olarak OKX'in `/trade/close-position` API'si deneniyor
   - Başarısız olursa alternatif olarak `reduceOnly=true` parametreli market emri deneniyor
   - Son çare olarak basit piyasa emri (market order) deneniyor

### 2. OKX API Authentication Hatası

**Sorun:** API isteklerinde "Invalid Sign" hatası alınıyor, kimlik doğrulama başarısız oluyor.

**Kök Neden:** İmzalama yöntemi (signature generation) OKX API'nin beklediği formatta değil.

**Çözüm:**
1. `generateSignature` fonksiyonu tamamen yeniden yazıldı
2. OKX dokümantasyonuna göre doğru imzalama sırası uygulandı:
   - Timestamp + Method + RequestPath + Body formatı kullanılıyor
   - GET istekleri için sorgu parametreleri doğru şekilde birleştiriliyor

### 3. Pozisyon Eşleştirme Sorunları

**Sorun:** Pozisyon kapatma işlemi için doğru pozisyon bulunamıyor ve "Açık pozisyon bulunamadı" hatası alınıyor.

**Kök Neden:** Pozisyon tipi (`posSide`) karşılaştırmaları doğru yapılmıyor.

**Çözüm:**
1. Pozisyon eşleştirme algoritması iyileştirildi:
   - `posSide` karşılaştırmaları (long/short/net) daha esnek hale getirildi
   - Pozisyon büyüklüğü (`pos`) kontrolleri eklendi
   - Daha fazla alternatif eşleştirme yöntemi eklendi

## Düzeltilen Dosyalar

### 1. server/okx-api.ts

- `getPositions` fonksiyonu: OKX API'ye yapılan pozisyon sorgulama istekleri düzeltildi
- `getOpenOrders` fonksiyonu: Açık emirleri sorgulama istekleri düzeltildi
- `closePosition` fonksiyonu: Pozisyon kapatma işlemi için çoklu yöntem stratejisi eklendi
- `generateSignature` fonksiyonu: İmzalama mekanizması OKX dokümantasyonuna göre yeniden yazıldı

### 2. server/routes.ts

- Pozisyon kapatma işlemindeki parametre geçişleri düzeltildi
- Pozisyon tipini (long/short) doğru belirleme mantığı eklendi

## Teknik Detaylar ve API Parametreleri

OKX API ile doğru çalışabilmek için şu parametrelerin doğru kullanılması kritiktir:

### Pozisyon Sorgulama
```
GET /api/v5/account/positions
```
**Gerekli Parametreler:**
- `instType`: "SWAP", "FUTURES", "SPOT" gibi işlem tipi
- `instId`: "BTC-USDT-SWAP" gibi enstrüman ID'si

### Emir Sorgulama
```
GET /api/v5/trade/orders-pending
```
**Gerekli Parametreler:**
- `instType`: "SWAP", "FUTURES", "SPOT" gibi işlem tipi
- `instId`: "BTC-USDT-SWAP" gibi enstrüman ID'si (opsiyonel)

### Pozisyon Kapatma
```
POST /api/v5/trade/close-position
```
**Gerekli Parametreler:**
- `instId`: "BTC-USDT-SWAP" gibi enstrüman ID'si
- `posSide`: "long", "short" veya "net" pozisyon yönü
- `mgnMode`: "cross" veya "isolated" teminat modu
- `closeAll`: "true" tüm pozisyonu kapatmak için

## Gelecek İyileştirmeler

### 1. Webhook Format Geliştirmeleri

TradingView'dan gelen webhook sinyallerinin formatını daha esnek hale getirmek için:

```javascript
// Örnek webhook formatı
{
  "pair": "BTCUSDT",
  "action": "BUY",
  "bot_id": 1,
  "orderSize": 1000,
  "orderUnit": "USDT",
  "leverage": 10,
  "stopLoss": 2.5,
  "takeProfitLevels": [
    { "target": 1.5, "volume": 25 },
    { "target": 3, "volume": 25 },
    { "target": 5, "volume": 25 },
    { "target": 7, "volume": 25 }
  ]
}
```

### 2. Hata İşleme Geliştirmeleri

API isteklerinde oluşabilecek hatalar için daha ayrıntılı hata mesajları ve otomatik yeniden deneme mekanizmaları eklenebilir.

### 3. OKX API İmzalama Optimizasyonu

İmzalama mekanizması için kapsamlı bir test paketi oluşturulabilir.

## İşlem Akışı

1. Bot kurulumu: Kullanıcı takip etmek istediği parite, kaldıraç, TP/SL oranları gibi parametreleri belirler
2. TradingView webhook JSON formatı üretilir ve kullanıcıya verilir
3. TradingView'de bu JSON formatı kullanılarak alert ayarlanır
4. Alert tetiklendiğinde webhook sinyali platforma ulaşır
5. Sistem, sinyali işleyerek OKX API ile işlemi gerçekleştirir
6. Take Profit ve Stop Loss emirleri otomatik ayarlanır
7. Takip ekranında işlem durumu izlenebilir

## Sonuç

Yapılan düzeltmelerle OKX API entegrasyonu iyileştirilmiş ve pozisyon kapatma sorunu çözülmüştür. TradingView'dan gelen sinyallerin OKX borsasında otomatik işlem yapılması için gerekli altyapı hazırdır.

---

*Not: Bu platform bireysel kullanım için tasarlanmıştır ve şu anda OKX demo hesabıyla çalışmaktadır. İleriki aşamalarda gerçek hesaba geçiş planlanmaktadır.*