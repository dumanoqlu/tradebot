# Kripto Trading Bot Platformu - Geliştirici Rehberi

Bu rehber, kripto trading bot platformunun yapısını ve bileşenlerini açıklar. Platform, çoklu borsa desteği (Binance, OKX), TradingView webhook entegrasyonu ve ileri seviye ticaret sinyal işleme yetenekleri sağlar.

## Proje Yapısı

Proje, klasik istemci-sunucu mimarisiyle yapılandırılmıştır:

```
/
├── client/            # Frontend kodları (React + TypeScript)
├── server/            # Backend kodları (Express API)
├── shared/            # İstemci ve sunucu arasında paylaşılan kodlar
└── ... yapılandırma dosyaları
```

## Backend (Server) Bileşenleri

### Temel Backend Dosyaları

| Dosya | Açıklama |
|-------|----------|
| `server/index.ts` | Ana sunucu giriş noktası. Express uygulamasını başlatır ve middleware'leri yapılandırır. |
| `server/routes.ts` | Tüm API endpoint'lerini tanımlar. İstemcinin sunucuyla iletişim kurduğu ana nokta. |
| `server/db.ts` | Veritabanı bağlantısını kurar. PostgreSQL veritabanı havuzunu yapılandırır. |
| `server/vite.ts` | Geliştirme ortamında frontend'in servis edilmesini sağlar. |

### Borsa API Entegrasyonları

| Dosya | Açıklama |
|-------|----------|
| `server/binance-api.ts` | Binance borsası ile iletişim kurmak için API istemcisi. Emir oluşturma, hesap bilgisi alma ve işlem geçmişi sorgulama gibi işlemleri yönetir. |
| `server/okx-api.ts` | OKX borsası ile iletişim kurmak için API istemcisi. Pozisyon açma, kapatma, hesap bilgilerini alma gibi işlemleri yönetir. Özellikle SWAP işlemleri için optimize edilmiştir. |

### Veri Depolama ve İşleme

| Dosya | Açıklama |
|-------|----------|
| `server/storage.ts` | Veritabanı işlemlerini yöneten ana sınıf. API anahtarları, botlar ve işlemler için CRUD operasyonları sağlar. `IStorage` arayüzünü uygulayan `DatabaseStorage` sınıfını içerir. |

## Frontend (Client) Bileşenleri

### Temel Frontend Dosyaları

| Dosya | Açıklama |
|-------|----------|
| `client/src/main.tsx` | React uygulamasının başlangıç noktası. |
| `client/src/App.tsx` | Ana uygulama bileşeni ve sayfa yönlendirmelerini içerir. |

### Sayfalar

| Dosya | Açıklama |
|-------|----------|
| `client/src/pages/dashboard.tsx` | Ana kontrol paneli. Kullanıcıya genel bakış sağlar. |
| `client/src/pages/smart-trades.tsx` | Akıllı işlemler sayfası. Kullanıcının aktif işlemlerini gösterir ve yeni işlem başlatmasını sağlar. |
| `client/src/pages/trade-history.tsx` | İşlem geçmişi sayfası. Tamamlanmış işlemleri ve performansı gösterir. |
| `client/src/pages/api-keys.tsx` | API anahtarlarının yönetildiği sayfa. |
| `client/src/pages/bots.tsx` | Trading botlarının yapılandırıldığı sayfa. |

### Bileşenler

#### Akıllı İşlem Bileşenleri

| Dosya | Açıklama |
|-------|----------|
| `client/src/components/smart-trades/smart-trade-card.tsx` | Bir akıllı işlemi temsil eden kart bileşeni. İşlemin durumunu, kar/zarar bilgilerini gösterir ve işlemi kapatma işlevini sağlar. |
| `client/src/components/smart-trades/create-smart-trade-modal.tsx` | Yeni akıllı işlem oluşturmak için modal bileşeni. |

#### Grafik Bileşenleri

| Dosya | Açıklama |
|-------|----------|
| `client/src/components/charts/price-chart.tsx` | Fiyat grafiği bileşeni. Lightweight-charts kütüphanesini kullanarak fiyat verilerini görselleştirir. |

#### İşlem Bileşenleri

| Dosya | Açıklama |
|-------|----------|
| `client/src/components/trades/trades-table.tsx` | İşlemleri tablo şeklinde gösteren bileşen. Sayfalama ve filtreleme özellikleri içerir. |
| `client/src/components/trades/trade-row.tsx` | İşlem tablosundaki her bir satırı temsil eden bileşen. |

### Yardımcı Bileşenler ve Hook'lar

| Dosya | Açıklama |
|-------|----------|
| `client/src/hooks/use-toast.ts` | Bildirim mesajları göstermek için custom hook. |
| `client/src/hooks/use-mobile.tsx` | Mobil cihaz tespiti için custom hook. |
| `client/src/lib/binance-api.ts` | Frontend'den Binance API'sini çağırmak için yardımcı fonksiyonlar. |
| `client/src/lib/constants.ts` | Trading çiftleri, sinyal kaynakları ve diğer sabit değerleri içerir. |
| `client/src/lib/queryClient.ts` | React Query yapılandırması ve API istek fonksiyonları. |

## Paylaşılan Bileşenler

| Dosya | Açıklama |
|-------|----------|
| `shared/schema.ts` | Veri modelleri, Zod şemaları ve tip tanımlamaları. Frontend ve backend arasında veri yapılarının tutarlılığını sağlar. |

## Veri Modelleri

Projedeki ana veri modelleri `shared/schema.ts` dosyasında tanımlanmıştır:

### API Anahtarları (`ApiKey`)
- Borsalarla iletişim kurmak için API anahtarlarını saklar
- `apiKey`, `apiSecret`, `passphrase` (OKX için), `name`, `exchange` alanlarını içerir
- `isActive` alanı hangi anahtarın kullanımda olduğunu belirtir

### Botlar (`Bot`)
- Trading botlarını tanımlar
- `name`, `description`, `tradingPair`, `exchange`, `strategy` gibi alanlar içerir
- Botlar aktif/pasif olarak işaretlenebilir (`isActive`)

### İşlemler (`Trade`)
- Açık veya kapalı işlemleri temsil eder
- `botId`, `tradingPair`, `type` (BUY/SELL), `price`, `amount`, `status` gibi alanlar içerir
- Take-profit ve stop-loss ayarları `notes` JSON alanında saklanır

### Sinyaller (`Signal`)
- TradingView ve diğer kaynaklardan gelen ticaret sinyallerini tanımlar
- İşlem çifti, yön (BUY/SELL), fiyat, stop-loss ve take-profit seviyelerini içerir

## İşlem Akışı

1. Kullanıcı bir borsa API anahtarı ekler (`API Keys` sayfası)
2. Kullanıcı bir trading botu oluşturur (`Bots` sayfası)
3. Kullanıcı manuel olarak veya TradingView webhook'u aracılığıyla bir işlem sinyali gönderir
4. Sunucu sinyali işler ve borsada ilgili emirleri oluşturur
5. İşlemler `Smart Trades` sayfasında izlenir ve yönetilir
6. Kullanıcı işlemleri manuel olarak kapatabilir veya otomatik take-profit/stop-loss seviyeleri devreye girebilir
7. Tamamlanan işlemler `Trade History` sayfasında görüntülenebilir

## Sorun Giderme

### İşlem Kapama Sorunları
- `server/okx-api.ts` içindeki `closePosition` metodu, OKX borsasındaki bir pozisyonu kapatmak için kullanılır
- Pozisyon kapatma işlemi başarısız olursa, birkaç alternatif yöntem denenir
- Yöntemler başarısız olursa bile, işlem veritabanında kapalı olarak işaretlenir

### API Bağlantı Sorunları
- API anahtarlarının doğru ve aktif olduğundan emin olun
- OKX API kullanırken passphrase değeri gereklidir
- Demo modunda mı yoksa gerçek modda mı çalıştığınızı kontrol edin

## Geliştirme Kılavuzları

### Yeni Borsa Ekleme
1. `server/` dizininde yeni borsa için bir API istemcisi oluşturun (örn. `kraken-api.ts`)
2. `server/routes.ts` dosyasında yeni borsa için endpoint'ler ekleyin
3. `shared/schema.ts` dosyasında ilgili veri tiplerini güncelleyin
4. Frontend'de yeni borsayı seçeneklere ekleyin

### Yeni İşlem Stratejisi Ekleme
1. `shared/schema.ts` dosyasında yeni stratejiyi tanımlayın
2. `server/routes.ts` içinde sinyal işleme mantığını güncelleyin
3. Frontend'deki bot oluşturma formunu ve akıllı işlem bileşenlerini güncelleyin

### Webhook Entegrasyonunu Genişletme
1. `server/routes.ts` içindeki sinyal işleme mantığını güncelleyin
2. Yeni webhook parametrelerini `shared/schema.ts` içindeki `Signal` tipine ekleyin

## İleriki Geliştirmeler

- Çoklu dil desteği
- Gelişmiş işlem stratejileri
- Daha fazla borsa desteği
- Risk yönetimi araçları
- Gelişmiş performans analizi

## ÖNEMLİ NOTLAR

- Gerçek borsalar ile çalışırken her zaman önce küçük miktarlarla test edin
- API anahtarlarınızı güvenli bir şekilde saklayın ve paylaşmayın
- Emir limitlerini ve ticaret kurallarını her borsa için kontrol edin