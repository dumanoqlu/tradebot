# TradeBotMaster - Replit Kurulum Rehberi

Merhaba! Bu rehber, TradeBotMaster web sitenizi Replit platformuna nasıl yükleyeceğinizi ve yayınlayacağınızı adım adım açıklamaktadır.

## 1. Dosyaları Yükleme

1. Replit projenizde "public" adında bir klasör oluşturun:
   - Sol taraftaki dosya gezgininde boş bir alana sağ tıklayın
   - "Add Folder" seçeneğini seçin ve klasöre "public" adını verin

2. Web sitenizin dosyalarını bu klasöre yükleyin:
   - "public" klasörüne sağ tıklayın ve "Upload Folder" veya "Upload File" seçeneğini seçin
   - ZIP dosyanızın içeriğini buraya yükleyin
   - En önemlisi, ana HTML dosyanızın (genellikle index.html) "public" klasöründe olduğundan emin olun

## 2. Sunucu Yapılandırması

Bu proje, web sitenizi sunmak için Express.js kullanmaktadır ve çoğu statik web sitesi için hazır olarak çalışacaktır. 

### Farklı Teknolojiler İçin Ayarlar

#### Statik HTML/CSS/JavaScript Sitesi
Statik bir site için ek yapılandırma gerekmez. Dosyalarınızı "public" klasörüne yüklemeniz yeterlidir.

#### PHP Sitesi İçin
Eğer siteniz PHP kullanıyorsa:

1. `.replit` dosyasını açın ve şu şekilde güncelleyin:
