import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Bot } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { CircleOff, Edit, Play, BadgeCheck, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface BotCardProps {
  bot: Bot;
  onEdit: (bot: Bot) => void;
}

export function BotCard({ bot, onEdit }: BotCardProps) {
  const { toast } = useToast();
  const [isUpdating, setIsUpdating] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const toggleActiveStatus = async () => {
    try {
      setIsUpdating(true);
      
      const updatedData = { isActive: !bot.isActive };
      
      await apiRequest(
        "PUT",
        `/api/bots/${bot.id}`,
        updatedData
      );
      
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      
      toast({
        title: bot.isActive ? "Bot durduruldu" : "Bot başlatıldı",
        description: `${bot.name} başarıyla ${bot.isActive ? "durduruldu" : "başlatıldı"}.`,
      });
    } catch (error) {
      console.error("Error toggling bot status:", error);
      toast({
        title: "Hata",
        description: "Bot durumu güncellenirken bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const deleteBot = async () => {
    try {
      setIsDeleting(true);
      
      await apiRequest(
        "DELETE",
        `/api/bots/${bot.id}`
      );
      
      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
      
      toast({
        title: "Bot silindi",
        description: `${bot.name} başarıyla silindi.`,
      });
    } catch (error) {
      console.error("Error deleting bot:", error);
      toast({
        title: "Hata",
        description: "Bot silinirken bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  // Format created date
  const formattedDate = bot.createdAt ? new Date(bot.createdAt).toISOString().split('T')[0] : '-';
  
  return (
    <div className="p-4 border-b border-dark-300 last:border-0">
      <div className="flex flex-col md:flex-row justify-between">
        <div className="mb-4 md:mb-0">
          <div className="flex items-center mb-2">
            <div className={`w-3 h-3 ${bot.isActive ? 'bg-secondary' : 'bg-danger'} rounded-full mr-2`}></div>
            <h3 className="font-medium">{bot.name}</h3>
            <span className="ml-2 bg-dark-300 text-xs px-2 py-1 rounded-full text-dark-100">
              {bot.isActive ? "Aktif" : "Durduruldu"}
            </span>
          </div>
          <div className="text-dark-100 text-sm mb-2">
            Oluşturulma: {formattedDate} | Sinyal kaynağı: {bot.signalIdentifier}
          </div>
          <div className="text-dark-100 text-sm">
            <span className="mr-4">Çift: {bot.tradingPair}</span>
            <span className="mr-4">Kâr Al: {Array.isArray(bot.takeProfitLevels) ? bot.takeProfitLevels.length : 0} seviye</span>
            <span>Stop Loss: -%{bot.stopLoss}</span>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            className="bg-dark-300 hover:bg-dark-200 text-white"
            onClick={() => onEdit(bot)}
          >
            <Edit className="mr-1 h-4 w-4" />
            Düzenle
          </Button>
          <Button
            variant={bot.isActive ? "destructive" : "default"}
            size="sm"
            className={bot.isActive ? "bg-danger/20 hover:bg-danger/30 text-danger" : ""}
            onClick={toggleActiveStatus}
            disabled={isUpdating}
          >
            {bot.isActive ? (
              <>
                <CircleOff className="mr-1 h-4 w-4" />
                Durdur
              </>
            ) : (
              <>
                <Play className="mr-1 h-4 w-4" />
                Başlat
              </>
            )}
          </Button>
          <Button
            variant="destructive"
            size="sm"
            className="bg-transparent hover:bg-danger/10 text-danger"
            onClick={() => setShowDeleteConfirm(true)}
            disabled={isDeleting}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Silme onay diyaloğu */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent className="bg-dark-400 text-white border-dark-300">
          <AlertDialogHeader>
            <AlertDialogTitle>Bu botu silmek istiyor musunuz?</AlertDialogTitle>
            <AlertDialogDescription className="text-dark-100">
              Bu işlem geri alınamaz. Bot ve ilgili tüm işlem verileri silinecektir.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-dark-300 text-white hover:bg-dark-200">İptal</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-danger hover:bg-danger/90 text-white" 
              onClick={deleteBot}
              disabled={isDeleting}
            >
              {isDeleting ? "Siliniyor..." : "Sil"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
