import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { X, ChevronDown, ChevronUp, Trash2, Copy, Code, Info, HelpCircle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { TRADING_PAIRS, SIGNAL_SOURCES, SIGNAL_SOURCE_LABELS, DEFAULT_TP_LEVELS, ORDER_UNITS } from "@/lib/constants";
import { Bot, TakeProfitLevel } from "@shared/schema";

// Yardımcı panoya kopyalama fonksiyonu
function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text).catch(err => {
    console.error('Panoya kopyalama başarısız:', err);
  });
}

const createBotSchema = z.object({
  name: z.string().min(1, "Bot adı gerekli"),
  tradingPair: z.string().min(1, "İşlem çifti gerekli"),
  signalSource: z.string().min(1, "Sinyal kaynağı gerekli"),
  signalIdentifier: z.string().min(1, "Sinyal tanımlayıcı gerekli"),
  signalSettings: z.string().optional(),
  isHedgeMode: z.boolean().default(false),
  totalFunds: z.number().min(0, "Toplam bakiye negatif olamaz"),
  maxActiveTrades: z.number().min(1, "Maksimum aktif işlem sayısı en az 1 olmalı"),
  cooldownPeriod: z.number().min(0, "Bekleme süresi negatif olamaz"),
  enableDCA: z.boolean().default(false),
  isActive: z.boolean().default(true),
  // Long position settings
  longEnabled: z.boolean().default(true),
  longOrderSize: z.number().min(0.1, "Long işlem miktarı en az 0.1 olmalı"),
  longOrderUnit: z.string().min(1, "Long işlem birimi gerekli"),
  longLeverage: z.number().min(1, "Long kaldıraç en az 1 olmalı").max(125, "Long kaldıraç en fazla 125 olabilir"),
  longStopLoss: z.number().min(0.1, "Long stop loss en az %0.1 olmalı"),
  longTrailingStop: z.boolean().default(false),
  longTrailingStopValue: z.number().optional(),
  // Short position settings
  shortEnabled: z.boolean().default(true),
  shortOrderSize: z.number().min(0.1, "Short işlem miktarı en az 0.1 olmalı"),
  shortOrderUnit: z.string().min(1, "Short işlem birimi gerekli"),
  shortLeverage: z.number().min(1, "Short kaldıraç en az 1 olmalı").max(125, "Short kaldıraç en fazla 125 olabilir"),
  shortStopLoss: z.number().min(0.1, "Short stop loss en az %0.1 olmalı"),
  shortTrailingStop: z.boolean().default(false),
  shortTrailingStopValue: z.number().optional(),
  // Backwards compatibility
  baseOrderSize: z.number().default(100),
  baseOrderUnit: z.string().default("USDT"),
  leverage: z.number().default(1),
  stopLoss: z.number().default(3.0),
  trailingStopLoss: z.boolean().default(false),
  takeProfitLevels: z.array(z.object({
    target: z.number(),
    volume: z.number()
  })).default(DEFAULT_TP_LEVELS),
});

type FormValues = z.infer<typeof createBotSchema> & {
  longTakeProfitLevels: TakeProfitLevel[];
  shortTakeProfitLevels: TakeProfitLevel[];
};

interface CreateBotModalProps {
  isOpen: boolean;
  onClose: () => void;
  editBot?: Bot;
}

export function CreateBotModal({ isOpen, onClose, editBot }: CreateBotModalProps) {
  const { toast } = useToast();
  const [mainTab, setMainTab] = useState("position"); // position, parameters
  const [longTakeProfitLevels, setLongTakeProfitLevels] = useState<TakeProfitLevel[]>(DEFAULT_TP_LEVELS);
  const [shortTakeProfitLevels, setShortTakeProfitLevels] = useState<TakeProfitLevel[]>(DEFAULT_TP_LEVELS);
  const longJsonRef = useRef<HTMLTextAreaElement>(null);
  const shortJsonRef = useRef<HTMLTextAreaElement>(null);
  
  const form = useForm<FormValues>({
    resolver: zodResolver(createBotSchema),
    defaultValues: {
      name: "",
      tradingPair: "BTC/USDT",
      signalSource: "tradingview",
      signalIdentifier: "",
      signalSettings: "",
      isHedgeMode: false,
      totalFunds: 1000,
      maxActiveTrades: 3,
      cooldownPeriod: 30,
      enableDCA: false,
      isActive: true,
      // Long settings
      longEnabled: true,
      longOrderSize: 100,
      longOrderUnit: "USDT",
      longLeverage: 1,
      longStopLoss: 3.0,
      longTrailingStop: false,
      longTrailingStopValue: 0.5,
      // Short settings
      shortEnabled: true,
      shortOrderSize: 100,
      shortOrderUnit: "USDT",
      shortLeverage: 1,
      shortStopLoss: 3.0,
      shortTrailingStop: false,
      shortTrailingStopValue: 0.5,
      // For backward compatibility
      baseOrderSize: 100,
      baseOrderUnit: "USDT",
      leverage: 1,
      stopLoss: 3.0,
      trailingStopLoss: false,
      takeProfitLevels: DEFAULT_TP_LEVELS,
      // Form specific fields
      longTakeProfitLevels: DEFAULT_TP_LEVELS,
      shortTakeProfitLevels: DEFAULT_TP_LEVELS,
    },
  });

  // Bot düzenleme durumunda form değerlerini ayarla
  useEffect(() => {
    if (editBot) {
      // Form değerlerini güvenli şekilde ayarla
      const defaultValues: any = {
        name: editBot.name || "",
        tradingPair: editBot.tradingPair || "BTC/USDT",
        signalSource: editBot.signalSource || "tradingview",
        signalIdentifier: editBot.signalIdentifier || "",
        signalSettings: editBot.signalSettings || "",
        isHedgeMode: editBot.isHedgeMode || false,
        totalFunds: editBot.totalFunds || 1000,
        maxActiveTrades: editBot.maxActiveTrades || 3,
        cooldownPeriod: editBot.cooldownPeriod || 30,
        enableDCA: editBot.enableDCA || false,
        isActive: editBot.isActive !== undefined ? editBot.isActive : true,
        
        // Long settings
        longEnabled: editBot.longEnabled !== undefined ? editBot.longEnabled : true,
        longOrderSize: editBot.longOrderSize || 100,
        longOrderUnit: editBot.longOrderUnit || "USDT",
        longLeverage: editBot.longLeverage || 1,
        longStopLoss: editBot.longStopLoss || 3.0,
        longTrailingStop: editBot.longTrailingStop || false,
        longTrailingStopValue: editBot.longTrailingStopValue || 0.5,
        
        // Short settings
        shortEnabled: editBot.shortEnabled !== undefined ? editBot.shortEnabled : true,
        shortOrderSize: editBot.shortOrderSize || 100,
        shortOrderUnit: editBot.shortOrderUnit || "USDT",
        shortLeverage: editBot.shortLeverage || 1,
        shortStopLoss: editBot.shortStopLoss || 3.0,
        shortTrailingStop: editBot.shortTrailingStop || false,
        shortTrailingStopValue: editBot.shortTrailingStopValue || 0.5,
        
        // For backward compatibility
        baseOrderSize: editBot.baseOrderSize || 100,
        baseOrderUnit: editBot.baseOrderUnit || "USDT",
        leverage: editBot.leverage || 1,
        stopLoss: editBot.stopLoss || 3.0,
        trailingStopLoss: editBot.trailingStopLoss || false,
        takeProfitLevels: DEFAULT_TP_LEVELS,
        
        // Form specific fields
        longTakeProfitLevels: DEFAULT_TP_LEVELS,
        shortTakeProfitLevels: DEFAULT_TP_LEVELS,
      };
      
      form.reset(defaultValues);
      
      // Set the take profit levels for long/short if they exist
      if (Array.isArray(editBot.longTakeProfitLevels) && editBot.longTakeProfitLevels.length > 0) {
        setLongTakeProfitLevels(editBot.longTakeProfitLevels);
      } else if (Array.isArray(editBot.takeProfitLevels) && editBot.takeProfitLevels.length > 0) {
        // Fallback to old takeProfitLevels if longTakeProfitLevels doesn't exist
        setLongTakeProfitLevels(editBot.takeProfitLevels);
      }
      
      if (Array.isArray(editBot.shortTakeProfitLevels) && editBot.shortTakeProfitLevels.length > 0) {
        setShortTakeProfitLevels(editBot.shortTakeProfitLevels);
      } else if (Array.isArray(editBot.takeProfitLevels) && editBot.takeProfitLevels.length > 0) {
        // Fallback to old takeProfitLevels if shortTakeProfitLevels doesn't exist
        setShortTakeProfitLevels(editBot.takeProfitLevels);
      }
    }
  }, [editBot, form]);

  const onSubmit = async (data: FormValues) => {
    try {
      // Kar alma seviyelerini doğrula
      const longTotalVolume = longTakeProfitLevels.reduce((sum, level) => sum + level.volume, 0);
      if (Math.abs(longTotalVolume - 100) > 0.01) {
        throw new Error("Long kâr alma seviyeleri toplam hacmi %100 olmalı");
      }

      const shortTotalVolume = shortTakeProfitLevels.reduce((sum, level) => sum + level.volume, 0);
      if (Math.abs(shortTotalVolume - 100) > 0.01) {
        throw new Error("Short kâr alma seviyeleri toplam hacmi %100 olmalı");
      }

      const botData = {
        ...data,
        // For backward compatibility, also set the old fields
        baseOrderSize: data.longOrderSize,
        baseOrderUnit: data.longOrderUnit,
        leverage: data.longLeverage,
        stopLoss: data.longStopLoss,
        trailingStopLoss: data.longTrailingStop,
        takeProfitLevels: longTakeProfitLevels,
        // New fields
        longTakeProfitLevels,
        shortTakeProfitLevels,
      };

      if (editBot) {
        // Mevcut botu güncelle
        await apiRequest("PUT", `/api/bots/${editBot.id}`, botData);
        toast({
          title: "Bot güncellendi",
          description: "Bot başarıyla güncellendi.",
        });
      } else {
        // Yeni bot oluştur
        await apiRequest("POST", "/api/bots", botData);
        toast({
          title: "Bot oluşturuldu",
          description: "Bot başarıyla oluşturuldu.",
        });
      }

      queryClient.invalidateQueries({ queryKey: ['/api/bots'] });
      onClose();
    } catch (error) {
      console.error("Bot kaydedilirken hata:", error);
      toast({
        title: "Hata",
        description: error instanceof Error ? error.message : "Bot kaydedilirken hata oluştu.",
        variant: "destructive",
      });
    }
  };

  // Kar alma seviyesi fonksiyonları
  const addTakeProfitLevel = (type: 'long' | 'short') => {
    const levels = type === 'long' ? longTakeProfitLevels : shortTakeProfitLevels;
    const setLevels = type === 'long' ? setLongTakeProfitLevels : setShortTakeProfitLevels;
    
    if (levels.length >= 10) {
      toast({
        title: "Maksimum seviyeye ulaşıldı",
        description: "10'dan fazla kâr alma seviyesi ekleyemezsiniz.",
        variant: "destructive",
      });
      return;
    }

    // Son hedefin biraz üzerinde yeni bir hedef ekle
    const lastLevel = levels[levels.length - 1];
    const newTarget = type === 'long' 
      ? lastLevel ? (Math.abs(lastLevel.target) + 2) : 2.5 
      : lastLevel ? -(Math.abs(lastLevel.target) + 2) : -2.5;
    
    setLevels([
      ...levels,
      { target: newTarget, volume: 25 }
    ]);
  };

  const removeTakeProfitLevel = (type: 'long' | 'short', index: number) => {
    const levels = type === 'long' ? longTakeProfitLevels : shortTakeProfitLevels;
    const setLevels = type === 'long' ? setLongTakeProfitLevels : setShortTakeProfitLevels;
    
    if (levels.length <= 1) {
      toast({
        title: "Minimum seviye gerekli",
        description: "En az bir kâr alma seviyesi gereklidir.",
        variant: "destructive",
      });
      return;
    }

    setLevels(levels.filter((_, i) => i !== index));
  };

  const updateTakeProfitLevel = (type: 'long' | 'short', index: number, field: keyof TakeProfitLevel, value: number) => {
    const levels = type === 'long' ? longTakeProfitLevels : shortTakeProfitLevels;
    const setLevels = type === 'long' ? setLongTakeProfitLevels : setShortTakeProfitLevels;
    
    const updatedLevels = [...levels];
    updatedLevels[index] = { ...updatedLevels[index], [field]: value };
    setLevels(updatedLevels);
  };

  // TradingView webhook JSON fonksiyonu
  const generateTradingViewWebhook = () => {
    const formValues = form.getValues();
    
    // Güvenlik için rastgele oluşturulan bir anahtar
    const secret = Math.random().toString(36).substring(2, 15);
    
    // Webhook URL bilgisini oluştur - Sinyal botu ID'sini URL yoluna ekle
    const botId = editBot?.id || "BOT_ID";
    const webhookUrl = window.location.protocol + "//" + window.location.host + "/api/bots/" + botId + "/signal";
    
    // Webhook kullanım açıklaması için webhook ID formatları
    const webhookIdTypes = {
      botId: `Mevcut bot ID: ${botId} (tercih edilen)`,
      comment: `TradingView strategy.order.comment değeri`
    };
    
    // LONG pozisyon için JSON (BUY işlemi)
    const longJson = {
      secret: secret,
      bot_id: editBot?.id || "", // Gerçek bot ID'si (yoksa boş bırak, sunucu URL'den alacak)
      action: "BUY",
      pair: formValues.tradingPair.replace("/", ""),
      price: "{{strategy.order.price}}",
      orderSize: formValues.longOrderSize,
      orderUnit: formValues.longOrderUnit,
      leverage: formValues.longLeverage,
      stopLoss: formValues.longStopLoss,
      takeProfitLevels: longTakeProfitLevels,
      timeframe: "{{interval}}",
      tradingview_alert_id: "{{alert.id}}"
    };
    
    // SHORT pozisyon için JSON (SELL işlemi)
    const shortJson = {
      secret: secret,
      bot_id: editBot?.id || "", // Gerçek bot ID'si (yoksa boş bırak, sunucu URL'den alacak)
      action: "SELL",
      pair: formValues.tradingPair.replace("/", ""),
      price: "{{strategy.order.price}}",
      orderSize: formValues.shortOrderSize,
      orderUnit: formValues.shortOrderUnit,
      leverage: formValues.shortLeverage,
      stopLoss: formValues.shortStopLoss,
      takeProfitLevels: shortTakeProfitLevels,
      timeframe: "{{interval}}",
      tradingview_alert_id: "{{alert.id}}"
    };
    
    // Akıllı algılama modu için JSON - TradingView'in strategy.order.action değerine göre işlem tipi belirlenir
    const smartJson = {
      secret: secret,
      bot_id: editBot?.id || "", // Gerçek bot ID'si (yoksa boş bırak, sunucu URL'den alacak)
      action: "{{strategy.order.action}}", // TradingView'den gelecek (buy veya sell)
      pair: formValues.tradingPair.replace("/", ""),
      price: "{{strategy.order.price}}",
      // action değerine göre otomatik olarak değerleri belirleyen koşullu alanlar
      orderSize: "{{strategy.order.action == 'buy' ? " + formValues.longOrderSize + " : " + formValues.shortOrderSize + "}}",
      orderUnit: "{{strategy.order.action == 'buy' ? '" + formValues.longOrderUnit + "' : '" + formValues.shortOrderUnit + "'}}",
      leverage: "{{strategy.order.action == 'buy' ? " + formValues.longLeverage + " : " + formValues.shortLeverage + "}}",
      stopLoss: "{{strategy.order.action == 'buy' ? " + formValues.longStopLoss + " : " + formValues.shortStopLoss + "}}",
      timeframe: "{{interval}}",
      tradingview_alert_id: "{{alert.id}}"
    };
    
    return {
      long: JSON.stringify(longJson, null, 2),
      short: JSON.stringify(shortJson, null, 2),
      smart: JSON.stringify(smartJson, null, 2),
      instructions: 
`TradingView Webhook Ayarları:

1. TradingView'de bir uyarı oluşturun
2. Webhook URL olarak aşağıdaki adresi kullanın:
   ${webhookUrl}
3. Webhook mesajı için yukarıdaki JSON formatlarından birini seçin:
   • LONG (ALIM) işlemleri için LONG JSON formatı
   • SHORT (SATIM) işlemleri için SHORT JSON formatı
   • Otomatik algılama modu için AKILLI JSON formatı
   
Önemli Notlar:
- Webhook URL'de botunuzun ID'si ${botId} olmalıdır. Bot oluşturulduktan sonra bu URL otomatik olarak güncellenecektir.
- "strategy.order.action" alanı, TradingView'den otomatik olarak "buy" veya "sell" değeriyle doldurulacaktır.
- Akıllı format, gelen değere göre doğru pozisyon ayarlarını kullanacaktır.
- Webhook'u test etmek için bot oluşturma işlemini tamamlayın ve Webhook URL'de gerçek bot ID'nizi kullandığınızdan emin olun.`
    };
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(
      () => {
        toast({
          title: "Kopyalandı!",
          description: "Webhook JSON kodu panoya kopyalandı.",
        });
      },
      (err) => {
        console.error("Kopyalama başarısız oldu:", err);
        toast({
          title: "Hata",
          description: "Kopyalama başarısız oldu. Lütfen manuel olarak seçip kopyalayın.",
          variant: "destructive",
        });
      }
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-dark-400 text-white border-dark-300 max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            {editBot ? "Sinyal Botu Düzenle" : "Sinyal Botu Oluşturma"}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Üst Bilgi */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-dark-300 p-4 rounded-lg flex items-center space-x-4">
                <div className="bg-dark-200 w-10 h-10 rounded-md flex items-center justify-center text-primary">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 12c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"></path>
                    <path d="M12 21c-5 0-8-3-8-8V7c0-1.1.9-2 2-2h2c1.1 0 2 .9 2 2v2h4v-2c0-1.1.9-2 2-2h2c1.1 0 2 .9 2 2v6c0 5-3 8-8 8z"></path>
                  </svg>
                </div>
                <div>
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input
                            {...field}
                            className="bg-dark-300 border-none text-white text-lg font-medium focus-visible:ring-0 p-0 h-auto"
                            placeholder="Bot Adı"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <div className="flex items-center mt-1 text-sm text-dark-100">
                    <span>Durum:</span>
                    <FormField
                      control={form.control}
                      name="isActive"
                      render={({ field }) => (
                        <FormItem className="flex items-center m-0 ml-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="mr-1 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                            />
                          </FormControl>
                          <FormLabel className="text-sm font-normal m-0">Aktif</FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </div>

              <div className="bg-dark-300 p-4 rounded-lg flex items-center space-x-4">
                <div className="bg-dark-200 w-10 h-10 rounded-md flex items-center justify-center text-green-500">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 2v20M2 5h20M5 20h14"></path>
                  </svg>
                </div>
                <div>
                  <FormField
                    control={form.control}
                    name="tradingPair"
                    render={({ field }) => (
                      <FormItem>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="bg-dark-300 border-none text-white text-lg font-medium focus:ring-0 p-0 h-auto">
                              <SelectValue placeholder="İşlem Çifti" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-dark-300 border-dark-200 text-white max-h-60">
                            {TRADING_PAIRS.map((pair) => (
                              <SelectItem key={pair} value={pair} className="hover:bg-dark-200">
                                {pair}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                  <div className="flex items-center mt-1 text-sm text-dark-100">
                    <span>Sinyal Kaynağı:</span>
                    <FormField
                      control={form.control}
                      name="signalSource"
                      render={({ field }) => (
                        <FormItem className="ml-2 mb-0">
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger className="h-6 text-xs min-w-32 py-0 px-2 bg-dark-200 border-dark-300">
                                <SelectValue placeholder="Kaynak" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-dark-300 border-dark-200 text-white">
                              {SIGNAL_SOURCES.map((source) => (
                                <SelectItem key={source} value={source} className="hover:bg-dark-200">
                                  {source in SIGNAL_SOURCE_LABELS ? SIGNAL_SOURCE_LABELS[source] : source}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="signalIdentifier"
                      render={({ field }) => (
                        <FormItem className="ml-2 mb-0">
                          <FormControl>
                            <Input
                              {...field}
                              className="h-6 text-xs py-0 px-2 bg-dark-200 border-dark-300"
                              placeholder="Tanımlayıcı"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Bakiye Bilgisi */}
            <div className="bg-dark-300 p-3 rounded-lg flex items-center">
              <div className="flex-1">
                <div className="flex items-center">
                  <span className="text-xs text-dark-100">Maks. marj kullanımı</span>
                  <HelpCircle className="h-3 w-3 ml-1 text-dark-100" />
                </div>
                <FormField
                  control={form.control}
                  name="totalFunds"
                  render={({ field }) => (
                    <FormItem className="mb-0">
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          className="h-8 bg-dark-400 border-dark-300 text-white mt-1"
                          placeholder="1000"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex-1 pl-2 flex items-end">
                <div className="bg-dark-400 p-2 rounded-lg flex items-center w-full h-8 mt-1">
                  <div className="flex items-center text-xs w-full text-dark-100">
                    <svg className="text-teal-500 h-4 w-4 mr-1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="12" cy="12" r="10" />
                      <path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8" />
                      <path d="M12 18V6" />
                    </svg>
                    <span>% USDT Bot başına</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Ana Sekmeler */}
            <div className="flex border-b border-dark-300 mb-4">
              <button
                type="button"
                className={`px-4 py-2 ${mainTab === 'position' ? 'text-primary border-b-2 border-primary' : 'text-dark-100'}`}
                onClick={() => setMainTab('position')}
              >
                Pozisyon Ayarları
              </button>
              <button
                type="button"
                className={`px-4 py-2 ${mainTab === 'parameters' ? 'text-primary border-b-2 border-primary' : 'text-dark-100'}`}
                onClick={() => setMainTab('parameters')}
              >
                Parametre Ayarları
              </button>
            </div>
            
            {/* Webhook URL bilgisi - kolay kopyalanabilir */}
            <div className="bg-dark-200 p-3 rounded-lg mb-4">
              <div className="flex justify-between items-center">
                <div className="text-sm font-medium">Webhook URL:</div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-6 text-xs" 
                  onClick={() => copyToClipboard(window.location.protocol + "//" + window.location.host + "/api/bots/" + (editBot?.id || "BOT_ID") + "/signal")}
                >
                  <Copy className="h-3.5 w-3.5 mr-1" />
                  Kopyala
                </Button>
              </div>
              <div className="bg-dark-300 p-2 rounded mt-1 text-xs font-mono break-all text-dark-100">
                {window.location.protocol}//{window.location.host}/api/bots/{editBot?.id || "BOT_ID"}/signal
              </div>
              <div className="mt-2 text-xs text-dark-100">
                <span className="text-amber-400">Önemli:</span> Bu URL&apos;yi TradingView uyarısında webhook adresi olarak kullanın.
              </div>
            </div>

            {/* Pozisyon Ayarları */}
            {mainTab === 'position' && (
              <div className="space-y-4">
                {/* Long İşlem Ayarları */}
                <div className="bg-dark-300 p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="text-sm font-medium flex items-center">
                      <span className="w-1 h-5 bg-blue-500 rounded-full mr-2"></span>
                      Long emri ayarları
                    </h3>
                    <div className="flex items-center">
                      <span className="text-xs text-dark-100 mr-2">Video eğitimi</span>
                      <button
                        type="button"
                        className="text-primary"
                      >
                        <ChevronUp className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="mb-3">
                    <FormField
                      control={form.control}
                      name="longEnabled"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="data-[state=checked]:bg-blue-500"
                            />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">
                            <span className="text-blue-500">Giriş Emri</span>
                          </FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-12 gap-3 mb-3">
                    <div className="col-span-5">
                      <label className="text-xs text-dark-100 mb-1 block">Emir başına hacim</label>
                      <div className="flex">
                        <FormField
                          control={form.control}
                          name="longOrderSize"
                          render={({ field }) => (
                            <FormItem className="flex-1 mb-0">
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                  onChange={(e) => field.onChange(parseFloat(e.target.value))}
                                  className="bg-dark-400 border-dark-300 text-white text-xs h-8 rounded-r-none"
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="longOrderUnit"
                          render={({ field }) => (
                            <FormItem className="mb-0">
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="rounded-l-none h-8 w-24 bg-dark-400 border-dark-300 text-white text-xs">
                                    <div className="flex items-center">
                                      <svg viewBox="0 0 24 24" className="h-4 w-4 mr-1 text-teal-500" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
                                        <path d="M16 8H8C7.44772 8 7 8.44772 7 9V11C7 11.5523 7.44772 12 8 12H15C15.5523 12 16 12.4477 16 13V15C16 15.5523 15.5523 16 15 16H7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
                                        <path d="M12 5V8M12 16V19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
                                      </svg>
                                      <SelectValue />
                                    </div>
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent className="bg-dark-300 border-dark-200 text-white">
                                  {ORDER_UNITS.map((unit) => (
                                    <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div className="col-span-7">
                      <label className="text-xs text-dark-100 mb-1 block">Emir türü</label>
                      <div className="grid grid-cols-12 gap-0 h-8">
                        <div className="col-span-4 bg-blue-600 text-white text-xs flex items-center justify-center rounded-l border border-dark-300">
                          Market
                        </div>
                        <div className="col-span-4 bg-dark-400 text-dark-100 text-xs flex items-center justify-center border-t border-b border-dark-300">
                          Limit
                        </div>
                        <div className="col-span-4 bg-dark-400 text-dark-100 text-xs flex items-center justify-center rounded-r border border-dark-300">
                          Stop
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Long webhook mesaj bölümü kaldırıldı */}
                  
                  <div className="mb-3">
                    <h4 className="text-xs text-dark-100 mb-1">Seçenekler</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs">Geçmişdeki aynı emirden fiyat sapması</span>
                          <Checkbox className="data-[state=checked]:bg-blue-500" />
                        </div>
                        <Input 
                          type="number" 
                          className="bg-dark-400 border-dark-300 text-white text-xs h-8" 
                          defaultValue="-1"
                          readOnly 
                        />
                        <div className="text-xs text-right mt-1">%</div>
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs">Ortalama giriş fiyatından fiyat sapması</span>
                          <Checkbox 
                            className="data-[state=checked]:bg-blue-500" 
                            defaultChecked={true} 
                          />
                        </div>
                        <Input 
                          type="number" 
                          className="bg-dark-400 border-dark-300 text-white text-xs h-8" 
                          defaultValue="-1" 
                        />
                        <div className="text-xs text-right mt-1">%</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mt-2 mb-1">
                      <span className="text-xs">Yeni bir SmartTrade için fiyat sapmasını sıfırla</span>
                      <Checkbox className="data-[state=checked]:bg-blue-500" />
                    </div>
                    
                    <div className="text-xs text-dark-100 mt-2">
                      Sinyal ancak bu koşul karşılanırsa alınacaktır
                    </div>
                    
                    <div className="flex items-center justify-between mt-3 mb-1">
                      <span className="text-xs">SmartTrade başına maks. giriş emri sayısı</span>
                      <Checkbox 
                        className="data-[state=checked]:bg-blue-500" 
                        defaultChecked={true} 
                      />
                    </div>
                    <FormField
                      control={form.control}
                      name="maxActiveTrades"
                      render={({ field }) => (
                        <FormItem className="mb-0">
                          <FormControl>
                            <Input
                              type="number"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))}
                              className="bg-dark-400 border-dark-300 text-white text-xs h-8"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {/* Boş bırakıldı - eski market fiyat bölümü kaldırıldı */}
                  
                  {/* Take Profit ve Stop Loss */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          defaultChecked={true}
                          className="data-[state=checked]:bg-green-500"
                        />
                        <span className="text-sm font-normal text-green-500">Take profit</span>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <div className="flex justify-between mb-2">
                        <div className="text-xs text-dark-100">Kâr al emirleri türü</div>
                        <div className="grid grid-cols-2 gap-0 rounded overflow-hidden w-56 h-6">
                          <div className="bg-dark-300 text-white text-xs flex items-center justify-center border border-dark-200">
                            Market
                          </div>
                          <div className="bg-dark-400 text-dark-100 text-xs flex items-center justify-center border-t border-r border-b border-dark-200">
                            Limit
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-dark-400 rounded-lg p-3">
                        <h5 className="text-xs mb-2">Çoklu hedefler</h5>
                        
                        {longTakeProfitLevels.map((level, index) => (
                          <div key={`long-tp-${index}`} className="grid grid-cols-12 gap-2 mb-2">
                            <div className="col-span-6">
                              <label className="text-xs text-dark-100 mb-1 block">Hedef kâr {index+1}</label>
                              <div className="flex">
                                <Input
                                  type="number"
                                  value={level.target}
                                  onChange={(e) => updateTakeProfitLevel('long', index, "target", parseFloat(e.target.value))}
                                  className="bg-dark-300 border-dark-200 text-white text-xs h-8 rounded-r-none w-full"
                                />
                                <div className="bg-dark-300 border border-l-0 border-dark-200 flex items-center justify-center text-dark-100 text-xs h-8 px-2 rounded-r">
                                  %
                                </div>
                              </div>
                            </div>
                            <div className="col-span-5">
                              <label className="text-xs text-dark-100 mb-1 block">Hacim {index+1}</label>
                              <div className="flex">
                                <Input
                                  type="number"
                                  value={level.volume}
                                  onChange={(e) => updateTakeProfitLevel('long', index, "volume", parseFloat(e.target.value))}
                                  className="bg-dark-300 border-dark-200 text-white text-xs h-8 rounded-r-none w-full"
                                />
                                <div className="bg-dark-300 border border-l-0 border-dark-200 flex items-center justify-center text-dark-100 text-xs h-8 px-2 rounded-r">
                                  %
                                </div>
                              </div>
                            </div>
                            <div className="col-span-1 flex items-end justify-end">
                              {longTakeProfitLevels.length > 1 && (
                                <button
                                  type="button"
                                  className="text-dark-100 hover:text-red-500 h-8 w-8 flex items-center justify-center"
                                  onClick={() => removeTakeProfitLevel('long', index)}
                                >
                                  <X className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                        
                        <button
                          type="button"
                          className="text-primary text-xs hover:underline focus:outline-none mt-2"
                          onClick={() => addTakeProfitLevel('long')}
                        >
                          + Hedef ekle
                        </button>
                        
                        <div className="flex items-center justify-between mt-3 mb-1">
                          <span className="text-xs">Son hedef için trailing sapması</span>
                          <FormField
                            control={form.control}
                            name="longTrailingStop"
                            render={({ field }) => (
                              <FormItem className="mb-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                    className="data-[state=checked]:bg-blue-500"
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        </div>
                        <FormField
                          control={form.control}
                          name="longTrailingStopValue"
                          render={({ field }) => (
                            <FormItem className="mb-0">
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                  onChange={(e) => field.onChange(parseFloat(e.target.value))}
                                  className="bg-dark-300 border-dark-200 text-white text-xs h-8"
                                  disabled={!form.watch("longTrailingStop")}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mb-2 mt-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          defaultChecked={true}
                          className="data-[state=checked]:bg-red-500"
                        />
                        <span className="text-sm font-normal text-red-500">Stop loss</span>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <FormField
                        control={form.control}
                        name="longStopLoss"
                        render={({ field }) => (
                          <FormItem className="mb-0">
                            <FormControl>
                              <div className="flex">
                                <Input
                                  type="number"
                                  {...field}
                                  onChange={(e) => field.onChange(parseFloat(e.target.value))}
                                  className="bg-dark-400 border-dark-300 text-white text-xs h-8 rounded-r-none"
                                />
                                <div className="bg-dark-400 border border-l-0 border-dark-300 flex items-center justify-center text-dark-100 text-xs h-8 px-2 rounded-r">
                                  %
                                </div>
                              </div>
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  {/* Long JSON Kodu Bölümü */}
                  <div className="mt-5 border-t border-dark-200 pt-4">
                    <div className="flex justify-between items-center mb-2">
                      <h5 className="text-sm font-medium flex items-center">
                        <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                        LONG (ALIM) JSON
                      </h5>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 text-dark-100 hover:text-primary"
                        onClick={() => copyToClipboard(generateTradingViewWebhook().long)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <Textarea
                      className="font-mono text-xs bg-dark-400 border-dark-200 text-white h-24"
                      value={generateTradingViewWebhook().long}
                      readOnly
                      onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      Bu JSON kodunu TradingView alarmınıza yapıştırın (LONG pozisyonlar için).                      
                    </p>
                  </div>
                </div>
                
                {/* Short İşlem Ayarları */}
                <div className="bg-dark-300 p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="text-sm font-medium flex items-center">
                      <span className="w-1 h-5 bg-red-500 rounded-full mr-2"></span>
                      Short emri ayarları
                    </h3>
                    <div className="flex items-center">
                      <span className="text-xs text-dark-100 mr-2">Video eğitimi</span>
                      <button
                        type="button"
                        className="text-primary"
                      >
                        <ChevronUp className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="mb-3">
                    <FormField
                      control={form.control}
                      name="shortEnabled"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="data-[state=checked]:bg-red-500"
                            />
                          </FormControl>
                          <FormLabel className="text-sm font-normal">
                            <span className="text-red-500">Çıkış Emri</span>
                          </FormLabel>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-12 gap-3 mb-3">
                    <div className="col-span-5">
                      <label className="text-xs text-dark-100 mb-1 block">Emir başına hacim</label>
                      <div className="flex">
                        <FormField
                          control={form.control}
                          name="shortOrderSize"
                          render={({ field }) => (
                            <FormItem className="flex-1 mb-0">
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                  onChange={(e) => field.onChange(parseFloat(e.target.value))}
                                  className="bg-dark-400 border-dark-300 text-white text-xs h-8 rounded-r-none"
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="shortOrderUnit"
                          render={({ field }) => (
                            <FormItem className="mb-0">
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="rounded-l-none h-8 w-24 bg-dark-400 border-dark-300 text-white text-xs">
                                    <div className="flex items-center">
                                      <svg viewBox="0 0 24 24" className="h-4 w-4 mr-1 text-teal-500" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
                                        <path d="M16 8H8C7.44772 8 7 8.44772 7 9V11C7 11.5523 7.44772 12 8 12H15C15.5523 12 16 12.4477 16 13V15C16 15.5523 15.5523 16 15 16H7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
                                        <path d="M12 5V8M12 16V19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
                                      </svg>
                                      <SelectValue />
                                    </div>
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent className="bg-dark-300 border-dark-200 text-white">
                                  {ORDER_UNITS.map((unit) => (
                                    <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div className="col-span-7">
                      <label className="text-xs text-dark-100 mb-1 block">Emir türü</label>
                      <div className="grid grid-cols-12 gap-0 h-8">
                        <div className="col-span-4 bg-red-600 text-white text-xs flex items-center justify-center rounded-l border border-dark-300">
                          Market
                        </div>
                        <div className="col-span-4 bg-dark-400 text-dark-100 text-xs flex items-center justify-center border-t border-b border-dark-300">
                          Limit
                        </div>
                        <div className="col-span-4 bg-dark-400 text-dark-100 text-xs flex items-center justify-center rounded-r border border-dark-300">
                          Stop
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Short webhook mesaj bölümü kaldırıldı */}
                  
                  <div className="mb-3">
                    <h4 className="text-xs text-dark-100 mb-1">Seçenekler</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs">Geçmişdeki aynı emirden fiyat sapması</span>
                          <Checkbox className="data-[state=checked]:bg-red-500" />
                        </div>
                        <Input 
                          type="number" 
                          className="bg-dark-400 border-dark-300 text-white text-xs h-8" 
                          defaultValue="1"
                          readOnly 
                        />
                        <div className="text-xs text-right mt-1">%</div>
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs">Ortalama giriş fiyatından fiyat sapması</span>
                          <Checkbox 
                            className="data-[state=checked]:bg-red-500" 
                            defaultChecked={true} 
                          />
                        </div>
                        <Input 
                          type="number" 
                          className="bg-dark-400 border-dark-300 text-white text-xs h-8" 
                          defaultValue="1" 
                        />
                        <div className="text-xs text-right mt-1">%</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mt-2 mb-1">
                      <span className="text-xs">Yeni bir SmartTrade için fiyat sapmasını sıfırla</span>
                      <Checkbox className="data-[state=checked]:bg-red-500" />
                    </div>
                    
                    <div className="text-xs text-dark-100 mt-2">
                      Sinyal ancak bu koşul karşılanırsa alınacaktır
                    </div>
                    
                    <div className="flex items-center justify-between mt-3 mb-1">
                      <span className="text-xs">SmartTrade başına maks. giriş emri sayısı</span>
                      <Checkbox 
                        className="data-[state=checked]:bg-red-500" 
                        defaultChecked={true} 
                      />
                    </div>
                    <Input
                      type="number"
                      className="bg-dark-400 border-dark-300 text-white text-xs h-8"
                      defaultValue="5"
                      readOnly
                    />
                  </div>
                  
                  {/* Short için market fiyat bölümü kaldırıldı */}
                  
                  {/* Take Profit ve Stop Loss */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          defaultChecked={true}
                          className="data-[state=checked]:bg-green-500"
                        />
                        <span className="text-sm font-normal text-green-500">Take profit</span>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <div className="flex justify-between mb-2">
                        <div className="text-xs text-dark-100">Kâr al emirleri türü</div>
                        <div className="grid grid-cols-2 gap-0 rounded overflow-hidden w-56 h-6">
                          <div className="bg-dark-300 text-white text-xs flex items-center justify-center border border-dark-200">
                            Market
                          </div>
                          <div className="bg-dark-400 text-dark-100 text-xs flex items-center justify-center border-t border-r border-b border-dark-200">
                            Limit
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-dark-400 rounded-lg p-3">
                        <h5 className="text-xs mb-2">Çoklu hedefler</h5>
                        
                        {shortTakeProfitLevels.map((level, index) => (
                          <div key={`short-tp-${index}`} className="grid grid-cols-12 gap-2 mb-2">
                            <div className="col-span-6">
                              <label className="text-xs text-dark-100 mb-1 block">Hedef kâr {index+1}</label>
                              <div className="flex">
                                <Input
                                  type="number"
                                  value={level.target}
                                  onChange={(e) => updateTakeProfitLevel('short', index, "target", parseFloat(e.target.value))}
                                  className="bg-dark-300 border-dark-200 text-white text-xs h-8 rounded-r-none w-full"
                                />
                                <div className="bg-dark-300 border border-l-0 border-dark-200 flex items-center justify-center text-dark-100 text-xs h-8 px-2 rounded-r">
                                  %
                                </div>
                              </div>
                            </div>
                            <div className="col-span-5">
                              <label className="text-xs text-dark-100 mb-1 block">Hacim {index+1}</label>
                              <div className="flex">
                                <Input
                                  type="number"
                                  value={level.volume}
                                  onChange={(e) => updateTakeProfitLevel('short', index, "volume", parseFloat(e.target.value))}
                                  className="bg-dark-300 border-dark-200 text-white text-xs h-8 rounded-r-none w-full"
                                />
                                <div className="bg-dark-300 border border-l-0 border-dark-200 flex items-center justify-center text-dark-100 text-xs h-8 px-2 rounded-r">
                                  %
                                </div>
                              </div>
                            </div>
                            <div className="col-span-1 flex items-end justify-end">
                              {shortTakeProfitLevels.length > 1 && (
                                <button
                                  type="button"
                                  className="text-dark-100 hover:text-red-500 h-8 w-8 flex items-center justify-center"
                                  onClick={() => removeTakeProfitLevel('short', index)}
                                >
                                  <X className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          </div>
                        ))}
                        
                        <button
                          type="button"
                          className="text-primary text-xs hover:underline focus:outline-none mt-2"
                          onClick={() => addTakeProfitLevel('short')}
                        >
                          + Hedef ekle
                        </button>
                        
                        <div className="flex items-center justify-between mt-3 mb-1">
                          <span className="text-xs">Son hedef için trailing sapması</span>
                          <FormField
                            control={form.control}
                            name="shortTrailingStop"
                            render={({ field }) => (
                              <FormItem className="mb-0">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                    className="data-[state=checked]:bg-green-500"
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                        </div>
                        <FormField
                          control={form.control}
                          name="shortTrailingStopValue"
                          render={({ field }) => (
                            <FormItem className="mb-0">
                              <FormControl>
                                <Input
                                  type="number"
                                  {...field}
                                  onChange={(e) => field.onChange(parseFloat(e.target.value))}
                                  className="bg-dark-300 border-dark-200 text-white text-xs h-8"
                                  disabled={!form.watch("shortTrailingStop")}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mb-2 mt-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          defaultChecked={true}
                          className="data-[state=checked]:bg-red-500"
                        />
                        <span className="text-sm font-normal text-red-500">Stop loss</span>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <FormField
                        control={form.control}
                        name="shortStopLoss"
                        render={({ field }) => (
                          <FormItem className="mb-0">
                            <FormControl>
                              <div className="flex">
                                <Input
                                  type="number"
                                  {...field}
                                  onChange={(e) => field.onChange(parseFloat(e.target.value))}
                                  className="bg-dark-400 border-dark-300 text-white text-xs h-8 rounded-r-none"
                                />
                                <div className="bg-dark-400 border border-l-0 border-dark-300 flex items-center justify-center text-dark-100 text-xs h-8 px-2 rounded-r">
                                  %
                                </div>
                              </div>
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  {/* Short JSON Kodu Bölümü */}
                  <div className="mt-5 border-t border-dark-200 pt-4">
                    <div className="flex justify-between items-center mb-2">
                      <h5 className="text-sm font-medium flex items-center">
                        <span className="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                        SHORT (SATIM) JSON
                      </h5>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 text-dark-100 hover:text-primary"
                        onClick={() => copyToClipboard(generateTradingViewWebhook().short)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <Textarea
                      className="font-mono text-xs bg-dark-400 border-dark-200 text-white h-24"
                      value={generateTradingViewWebhook().short}
                      readOnly
                      onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                    />
                    <p className="text-xs text-gray-400 mt-1">
                      Bu JSON kodunu TradingView alarmınıza yapıştırın (SHORT pozisyonlar için).
                    </p>
                  </div>
                </div>
                
                {/* Katlamama Ayarları */}
                <div className="bg-dark-300 p-4 rounded-lg mt-4">
                  <div className="flex justify-between items-center mb-2">
                    <h5 className="text-sm font-medium flex items-center">
                      <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                      AKILLI ALGILAMA MODU (OTOMATİK)
                    </h5>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 text-dark-100 hover:text-primary"
                      onClick={() => copyToClipboard(generateTradingViewWebhook().smart)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <Textarea
                    className="font-mono text-xs bg-dark-400 border-dark-200 text-white h-24"
                    value={generateTradingViewWebhook().smart}
                    readOnly
                    onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                  />
                  <p className="text-xs text-gray-400 mt-2">
                    <span className="text-yellow-500">⚠️ Not:</span> Bu mod TradingView'in "strategy.order.action" değişkenini kullanır. Gelen sinyale göre otomatik olarak LONG/SHORT ayarlarını seçer.
                  </p>
                </div>
                
                <div className="flex items-center justify-between px-2 mt-4">
                  <span className="text-xs">Bot güvenliği</span>
                  <Checkbox className="data-[state=checked]:bg-primary" />
                </div>
              </div>
            )}

            {/* Parametre Ayarları */}
            {mainTab === 'parameters' && (
              <div className="space-y-4">
                <div className="bg-dark-300 p-4 rounded-lg">
                  <h4 className="text-sm font-medium mb-3">Gelişmiş Bot Ayarları</h4>
                  
                  <FormField
                    control={form.control}
                    name="isHedgeMode"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between mb-2">
                        <FormLabel className="text-xs text-dark-100">Hedge modunu etkinleştir</FormLabel>
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="data-[state=checked]:bg-primary"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="cooldownPeriod"
                    render={({ field }) => (
                      <FormItem className="mb-4">
                        <div className="flex justify-between mb-1">
                          <FormLabel className="text-xs text-dark-100">Bekleme süresi (dakika)</FormLabel>
                        </div>
                        <FormControl>
                          <Input
                            type="number"
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value))}
                            className="bg-dark-400 border-dark-300 text-white text-xs h-8"
                            placeholder="örn. 30"
                            min="0"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="enableDCA"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between mb-2">
                        <FormLabel className="text-xs text-dark-100">DCA (Ortalama Maliyet) Etkinleştir</FormLabel>
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="data-[state=checked]:bg-primary"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            )}

            {/* JSON sekmesi kaldırıldı */}

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                className="bg-dark-300 hover:bg-dark-200 text-white"
                onClick={onClose}
              >
                İptal
              </Button>
              <Button type="submit" className="bg-primary hover:bg-primary/90 text-white">
                {editBot ? "Kaydet" : "Oluştur"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}