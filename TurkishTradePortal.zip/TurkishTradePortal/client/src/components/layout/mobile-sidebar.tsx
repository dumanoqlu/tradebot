import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  BarChart2,
  Bot,
  LineChart,
  History,
  Settings,
  Menu,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function MobileSidebar() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const navItems = [
    {
      name: "Sinyal Botları",
      path: "/signal-bots",
      icon: <Bot className="mr-3 h-5 w-5" />,
    },
    {
      name: "Akıllı İşlemler",
      path: "/smart-trades",
      icon: <LineChart className="mr-3 h-5 w-5" />,
    },
    {
      name: "Kontrol Paneli",
      path: "/",
      icon: <BarChart2 className="mr-3 h-5 w-5" />,
    },
    {
      name: "İşlem Geçmişi",
      path: "/trade-history",
      icon: <History className="mr-3 h-5 w-5" />,
    },
    {
      name: "Ayarlar",
      path: "/settings",
      icon: <Settings className="mr-3 h-5 w-5" />,
    },
  ];

  return (
    <div className="lg:hidden fixed top-0 left-0 right-0 bg-dark-500 z-10">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <LineChart className="text-2xl text-primary mr-2 h-6 w-6" />
          <h1 className="text-xl font-bold text-white">CryptoTrade Bot</h1>
        </div>
        <button
          onClick={toggleMenu}
          className="text-white focus:outline-none"
          aria-label={isOpen ? "Close menu" : "Open menu"}
        >
          {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      <div
        className={cn(
          "bg-dark-500 p-4 transition-all duration-300 ease-in-out",
          isOpen ? "block" : "hidden"
        )}
      >
        <nav>
          <ul>
            {navItems.map((item) => (
              <li key={item.path} className="mb-2">
                <Link href={item.path}>
                  <div
                    className={cn(
                      "flex items-center px-4 py-3 rounded-lg cursor-pointer",
                      location === item.path
                        ? "text-white bg-primary"
                        : "text-dark-100 hover:bg-dark-300"
                    )}
                    onClick={() => setIsOpen(false)}
                  >
                    {item.icon}
                    <span>{item.name}</span>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
}
