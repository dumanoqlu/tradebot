import { ReactNode } from "react";
import { Sidebar } from "./sidebar";
import { MobileSidebar } from "./mobile-sidebar";

interface PageLayoutProps {
  children: ReactNode;
}

export function PageLayout({ children }: PageLayoutProps) {
  return (
    <div className="flex min-h-screen bg-dark-400">
      <Sidebar />
      <MobileSidebar />
      <div className="flex-1 lg:ml-64 mt-16 lg:mt-0">{children}</div>
    </div>
  );
}
