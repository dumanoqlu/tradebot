import { Link, useLocation } from "wouter";
import {
  BarChart2,
  Bot,
  LineChart,
  History,
  Settings,
  ExternalLink,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    {
      name: "Sinyal Botları",
      path: "/signal-bots",
      icon: <Bot className="mr-3 h-5 w-5" />,
    },
    {
      name: "Akıllı İşlemler",
      path: "/smart-trades",
      icon: <LineChart className="mr-3 h-5 w-5" />,
    },
    {
      name: "Kontrol Paneli",
      path: "/",
      icon: <BarChart2 className="mr-3 h-5 w-5" />,
    },
    {
      name: "İşlem Geçmişi",
      path: "/trade-history",
      icon: <History className="mr-3 h-5 w-5" />,
    },
    {
      name: "Ayarlar",
      path: "/settings",
      icon: <Settings className="mr-3 h-5 w-5" />,
    },
  ];

  return (
    <div className="hidden lg:flex flex-col bg-dark-500 w-64 p-4 fixed h-full">
      <div className="flex items-center mb-8 px-2">
        <LineChart className="text-2xl text-primary mr-2 h-6 w-6" />
        <h1 className="text-xl font-bold text-white">CryptoTrade Bot</h1>
      </div>

      <nav>
        <ul>
          {navItems.map((item) => (
            <li key={item.path} className="mb-1">
              <Link href={item.path}>
                <div
                  className={cn(
                    "flex items-center px-4 py-3 rounded-lg cursor-pointer",
                    location === item.path
                      ? "text-white bg-primary"
                      : "text-dark-100 hover:bg-dark-300"
                  )}
                >
                  {item.icon}
                  <span>{item.name}</span>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      <div className="mt-auto">
        <div className="bg-dark-300 p-4 rounded-lg">
          <div className="flex items-center mb-2">
            <div className="w-3 h-3 bg-secondary rounded-full mr-2"></div>
            <span className="text-sm text-white">API Connected</span>
          </div>
          <div className="text-xs text-dark-100">Binance API: ****...fJ7K</div>
        </div>
      </div>
    </div>
  );
}
