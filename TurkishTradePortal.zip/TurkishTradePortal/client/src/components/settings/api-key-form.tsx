import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { testOkxConnection } from "@/lib/okx-api";
import { Loader2 } from "lucide-react";

const apiKeySchema = z.object({
  name: z.string().default("OKX API"),
  apiKey: z.string().min(1, "API Anahtarı gereklidir"),
  apiSecret: z.string().min(1, "API Gizli Anahtarı gereklidir"),
  passphrase: z.string().min(1, "Passphrase gereklidir"),
  isActive: z.boolean().default(true),
});

type FormValues = z.infer<typeof apiKeySchema>;

export function ApiKeyForm() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isTesting, setIsTesting] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(apiKeySchema),
    defaultValues: {
      name: "OKX API",
      apiKey: "",
      apiSecret: "",
      passphrase: "",
      isActive: true,
    },
  });

  const onSubmit = async (data: FormValues) => {
    try {
      setIsSubmitting(true);
      
      console.log("Submitting API key:", data.apiKey.substring(0, 4) + '...' + data.apiKey.slice(-4));
      
      // Direkt kaydet - test yapmadan
      const saveResult = await apiRequest("POST", "/api/keys", data);
      console.log("API key save result:", saveResult);
      
      toast({
        title: "API anahtarı eklendi",
        description: "OKX API anahtarınız başarıyla eklendi.",
      });
      
      // Reset the form
      form.reset();
      
      // Refresh the API keys list
      queryClient.invalidateQueries({ queryKey: ['/api/keys'] });
    } catch (error) {
      console.error("Error adding API key:", error);
      toast({
        title: "Hata",
        description: "API anahtarı eklenirken bir hata oluştu. Lütfen tekrar deneyin.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const testConnection = async () => {
    try {
      setIsTesting(true);
      
      const data = form.getValues();
      
      if (!data.apiKey || !data.apiSecret || !data.passphrase) {
        toast({
          title: "Eksik bilgiler",
          description: "Lütfen API Anahtarı, Gizli Anahtar ve Passphrase alanlarını doldurun.",
          variant: "destructive",
        });
        return;
      }
      
      console.log("Testing connection with API key:", data.apiKey.substring(0, 4) + '...' + data.apiKey.slice(-4));
      const result = await testOkxConnection(data.apiKey, data.apiSecret, data.passphrase);
      console.log("Test connection result:", result);
      
      if (result.success) {
        toast({
          title: "Bağlantı başarılı",
          description: "OKX API'ye başarıyla bağlandı.",
        });
      } else {
        // Daha detaylı hata mesajı göster
        const errorMsg = result.message || result.error || "Verilen API bilgileriyle OKX'e bağlanılamadı.";
        console.error("API connection error details:", errorMsg);
        
        toast({
          title: "Bağlantı başarısız",
          description: errorMsg,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error testing connection:", error);
      toast({
        title: "Hata",
        description: "Bağlantı testi sırasında bir hata oluştu. Lütfen tekrar deneyin.",
        variant: "destructive",
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input
                  {...field}
                  className="bg-dark-300 border-dark-200 text-white"
                  placeholder="e.g. Binance Main Account"
                  disabled={isSubmitting || isTesting}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="grid grid-cols-1 gap-4">
          <FormField
            control={form.control}
            name="apiKey"
            render={({ field }) => (
              <FormItem>
                <FormLabel>API Key</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="password"
                    className="bg-dark-300 border-dark-200 text-white"
                    placeholder="OKX API Key"
                    disabled={isSubmitting || isTesting}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="apiSecret"
            render={({ field }) => (
              <FormItem>
                <FormLabel>API Secret</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="password"
                    className="bg-dark-300 border-dark-200 text-white"
                    placeholder="OKX API Secret"
                    disabled={isSubmitting || isTesting}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="passphrase"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Passphrase</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="password"
                    className="bg-dark-300 border-dark-200 text-white"
                    placeholder="OKX API Passphrase"
                    disabled={isSubmitting || isTesting}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="isActive"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border border-dark-300 p-3 shadow-sm">
              <div className="space-y-0.5">
                <FormLabel>Activate API Key</FormLabel>
                <div className="text-dark-100 text-sm">
                  Use this API key for trading operations
                </div>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                  disabled={isSubmitting || isTesting}
                  className="data-[state=checked]:bg-primary"
                />
              </FormControl>
            </FormItem>
          )}
        />
        
        <div className="flex space-x-2 justify-end pt-2">
          <Button 
            type="button"
            variant="outline"
            className="border-primary hover:bg-primary/10"
            onClick={testConnection}
            disabled={isSubmitting || isTesting}
          >
            {isTesting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Test Ediliyor...
              </>
            ) : (
              "Bağlantıyı Test Et"
            )}
          </Button>
          <Button 
            type="submit" 
            className="bg-primary hover:bg-primary/90 text-white"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Ekleniyor...
              </>
            ) : (
              "API Anahtarı Ekle"
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}
