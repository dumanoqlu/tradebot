import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Trade } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import { Edit, CircleOff, ChevronDown, ChevronUp, AlertTriangle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";

interface SmartTradeCardProps {
  trade: Trade;
  isCompleted?: boolean;
}

export function SmartTradeCard({ trade, isCompleted = false }: SmartTradeCardProps) {
  const { toast } = useToast();
  const [isUpdating, setIsUpdating] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [showCloseDialog, setShowCloseDialog] = useState(false);

  const confirmCloseTrade = () => {
    setShowCloseDialog(true);
  };

  const closeTrade = async () => {
    try {
      setIsUpdating(true);
      setShowCloseDialog(false);
      
      console.log("İşlem kapatılıyor:", trade.id);
      
      // Debug için daha fazla bilgi gönder
      const request = {
        status: "CLOSED", 
        closedAt: new Date().toISOString(),
        notes: JSON.stringify({
          takeProfitLevels,
          stopLoss: stopLossValue,
          closeRequestTime: new Date().toISOString(),
          manualClose: true
        }, null, 2)  
      };
      
      console.log("Gönderilen veri:", request);
      
      const response = await apiRequest(
        "PUT",
        `/api/trades/${trade.id}`,
        request
      );
      
      console.log("Kapatma yanıtı:", response);
      
      // Veriyi yeniden yükle
      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
      
      toast({
        title: "İşlem kapatıldı",
        description: `${trade.tradingPair} işlemi başarıyla kapatıldı.`,
      });
    } catch (error) {
      console.error("İşlem kapatma hatası:", error);
      toast({
        title: "Hata",
        description: "İşlem kapatılırken bir sorun oluştu.",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  // Format dates and calculate time ago
  const openDate = trade.openedAt ? new Date(trade.openedAt) : new Date();
  const formattedOpenDate = openDate.toISOString().split('T')[0];
  const timeAgo = formatDistanceToNow(openDate, { addSuffix: true });
  
  // Format close date if available
  const formattedCloseDate = trade.closedAt 
    ? new Date(trade.closedAt).toISOString().split('T')[0]
    : '';
  
  // Determine if this is a profitable trade (trade.profit can be null)
  const profit = trade.profit || 0;
  const isProfitable = profit > 0;
  
  // Parse takeProfitLevels and stopLoss from notes JSON if available
  let takeProfitLevels: Array<{target: number, volume: number, status: string}> = [];
  let stopLossValue: number | null = null;
  
  try {
    if (trade.notes) {
      // Try to parse JSON from notes if it exists
      if (trade.notes.includes("takeProfitLevels") || trade.notes.includes("stopLoss")) {
        const notesObj = JSON.parse(trade.notes);
        if (notesObj.takeProfitLevels) {
          takeProfitLevels = notesObj.takeProfitLevels.map((tp: any) => ({
            target: tp.target,
            volume: tp.volume,
            status: 'ACTIVE' // Default to active
          }));
        }
        if (notesObj.stopLoss) {
          stopLossValue = notesObj.stopLoss;
        }
      }
    }
  } catch (e) {
    console.log("Notes parsing error:", e);
  }

  // Fallback to default values if parsing failed
  if (takeProfitLevels.length === 0) {
    takeProfitLevels = [
      { target: 1.5, volume: 25, status: 'ACTIVE' },
      { target: 2.5, volume: 25, status: 'ACTIVE' },
      { target: 4.0, volume: 25, status: 'ACTIVE' },
      { target: 6.0, volume: 25, status: 'ACTIVE' },
    ];
  }
  
  if (stopLossValue === null) {
    stopLossValue = 3.0;
  }
  
  return (
    <div className="p-4 border-b border-dark-300 last:border-0">
      <div className="flex flex-col md:flex-row justify-between">
        <div className="mb-4 md:mb-0">
          <div className="flex items-center mb-2">
            <div className={`w-3 h-3 ${isCompleted ? (isProfitable ? 'bg-secondary' : 'bg-danger') : 'bg-primary'} rounded-full mr-2`}></div>
            <h3 className="font-medium">{trade.tradingPair} {trade.type}</h3>
            <span className="ml-2 bg-dark-300 text-xs px-2 py-1 rounded-full text-dark-100">
              {isCompleted ? 'Tamamlandı' : 'Aktif'}
            </span>
          </div>
          <div className="text-dark-100 text-sm mb-2">
            Açılış: {formattedOpenDate} ({timeAgo})
            {isCompleted && formattedCloseDate && (
              <> • Kapanış: {formattedCloseDate}</>
            )}
          </div>
          <div className="text-dark-100 text-sm">
            <span className="mr-4">Fiyat: ${trade.price.toFixed(2)}</span>
            <span className="mr-4">Miktar: {trade.amount} {trade.tradingPair.split('/')[0]}</span>
            <button 
              onClick={() => setShowDetails(!showDetails)}
              className="text-primary text-xs flex items-center"
            >
              {showDetails ? 'Detayları Gizle' : 'Detayları Göster'}
              {showDetails ? <ChevronUp className="ml-1 h-3 w-3" /> : <ChevronDown className="ml-1 h-3 w-3" />}
            </button>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <div className="text-center mr-6 hidden md:block">
            <div className={`text-xl font-bold ${isProfitable ? 'text-secondary' : 'text-danger'}`}>
              {isProfitable ? '+' : ''}{isProfitable ? '$' + profit.toFixed(2) : '-$' + Math.abs(profit).toFixed(2)}
            </div>
            <div className="text-dark-100 text-xs">
              {isCompleted ? 'Toplam Kazanç' : 'Anlık Kazanç'}
            </div>
          </div>
          
          {!isCompleted && (
            <>
              <Button
                variant="secondary"
                size="sm"
                className="bg-dark-300 hover:bg-dark-200 text-white"
              >
                <Edit className="mr-1 h-4 w-4" />
                Düzenle
              </Button>
              <Button
                variant="destructive"
                size="sm"
                className="bg-danger/20 hover:bg-danger/30 text-danger"
                onClick={confirmCloseTrade}
                disabled={isUpdating}
              >
                <CircleOff className="mr-1 h-4 w-4" />
                İşlemi Kapat
              </Button>
            </>
          )}
        </div>
      </div>
      
      {/* Expanded details */}
      {showDetails && (
        <div className="mt-4 bg-dark-300 rounded-lg p-4">
          <h4 className="text-sm font-medium mb-2">Take Profit Levels</h4>
          <div className="grid grid-cols-4 gap-4 mb-4 text-xs text-dark-100">
            <div>Level</div>
            <div>Target</div>
            <div>Amount</div>
            <div>Status</div>
          </div>
          {takeProfitLevels.map((level: {target: number, volume: number, status: string}, index: number) => (
            <div key={index} className="grid grid-cols-4 gap-4 text-sm py-1 border-t border-dark-400">
              <div>TP {index + 1}</div>
              <div>+{level.target}%</div>
              <div>{level.volume}%</div>
              <div className={level.status === 'EXECUTED' ? 'text-secondary' : 'text-dark-100'}>
                {level.status}
              </div>
            </div>
          ))}
          
          <div className="mt-4 border-t border-dark-400 pt-4">
            <h4 className="text-sm font-medium mb-2">Stop Loss</h4>
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div>Level: -{stopLossValue}%</div>
              <div>Amount: 100%</div>
              <div className="text-dark-100">Status: ACTIVE</div>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Dialog */}
      <Dialog open={showCloseDialog} onOpenChange={setShowCloseDialog}>
        <DialogContent className="bg-dark-400 border-dark-300">
          <DialogHeader>
            <DialogTitle>İşlemi Kapat</DialogTitle>
            <DialogDescription className="text-dark-100">
              {trade.tradingPair} {trade.type} işlemini kapatmak istediğinize emin misiniz?
              Bu işlem piyasadan çıkış yapacak ve tüm emirleri iptal edecektir.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:gap-0 mt-4">
            <div className="flex-1 flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-warning" />
              <span className="text-xs text-warning">Bu işlem geri alınamaz!</span>
            </div>
            <div className="flex gap-2 ml-auto">
              <Button
                variant="outline"
                className="bg-dark-300 hover:bg-dark-200"
                onClick={() => setShowCloseDialog(false)}
              >
                İptal
              </Button>
              <Button
                variant="destructive"
                className="bg-danger hover:bg-danger/90"
                onClick={closeTrade}
                disabled={isUpdating}
              >
                {isUpdating ? "Kapatılıyor..." : "İşlemi Kapat"}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
