import { ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";

interface StatCardProps {
  title: string;
  value: string | number;
  change?: string | number;
  changeText?: string;
  icon: ReactNode;
  positive?: boolean;
}

export function StatCard({
  title,
  value,
  change,
  changeText,
  icon,
  positive = true,
}: StatCardProps) {
  return (
    <Card className="bg-dark-300 border-none">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-dark-100 text-sm">{title}</span>
          <div className="text-primary">{icon}</div>
        </div>
        <div className="text-2xl font-bold">{value}</div>
        {change && (
          <div className="flex items-center text-xs mt-2">
            <span className={positive ? "text-secondary" : "text-danger"} aria-label={positive ? "Increase" : "Decrease"}>
              {positive ? "+" : ""}{change}
            </span>
            {changeText && <span className="text-dark-100 ml-1">{changeText}</span>}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
