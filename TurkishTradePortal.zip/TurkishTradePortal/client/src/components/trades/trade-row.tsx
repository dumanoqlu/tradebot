import { formatDistanceToNow } from "date-fns";
import { Trade, Bot } from "@shared/schema";

interface TradeRowProps {
  trade: Trade;
  bot?: Bot;
}

export function TradeRow({ trade, bot }: TradeRowProps) {
  const formattedDate = new Date(trade.openedAt).toISOString().replace("T", " ").substring(0, 16);
  
  // Calculate time ago string
  const timeAgo = formatDistanceToNow(new Date(trade.openedAt), { addSuffix: true });
  
  // Determine if this is a profitable trade
  const isProfitable = trade.profit > 0;

  return (
    <tr className="border-b border-dark-300">
      <td className="px-4 py-3" title={timeAgo}>
        {formattedDate}
      </td>
      <td className="px-4 py-3">
        {bot?.name || `Bot #${trade.botId}`}
      </td>
      <td className="px-4 py-3">{trade.tradingPair}</td>
      <td className="px-4 py-3">
        <span className={trade.type === "BUY" ? "text-secondary" : "text-danger"}>
          {trade.type}
        </span>
      </td>
      <td className="px-4 py-3">${trade.price.toFixed(2)}</td>
      <td className="px-4 py-3">
        {trade.amount} {trade.tradingPair.split("/")[0]}
      </td>
      <td className="px-4 py-3">
        <span className={isProfitable ? "text-secondary" : "text-danger"}>
          {isProfitable ? "+" : ""}{isProfitable ? "$" + trade.profit.toFixed(2) : "-$" + Math.abs(trade.profit).toFixed(2)}
        </span>
      </td>
    </tr>
  );
}
