import { useState } from "react";
import { Bot, Trade } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface TradesTableProps {
  trades: Trade[];
  bots: Bot[];
  isLoading: boolean;
}

export function TradesTable({ trades, bots, isLoading }: TradesTableProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  // Calculate pagination
  const totalPages = Math.ceil(trades.length / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentTrades = trades.slice(indexOfFirstItem, indexOfLastItem);
  
  // Handle page change
  const goToPage = (pageNumber: number) => {
    setCurrentPage(Math.max(1, Math.min(pageNumber, totalPages)));
  };
  
  // Get bot name by ID
  const getBotName = (botId: number) => {
    const bot = bots.find(b => b.id === botId);
    return bot ? bot.name : `Bot #${botId}`;
  };
  
  // Format date and time
  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  };
  
  // Get time ago string
  const getTimeAgo = (dateString: string) => {
    return formatDistanceToNow(new Date(dateString), { addSuffix: true });
  };

  return (
    <div>
      <div className="rounded-md border-dark-300 overflow-hidden">
        <Table>
          <TableHeader className="bg-dark-300">
            <TableRow className="hover:bg-dark-300/50 border-dark-300">
              <TableHead className="text-dark-100">Date</TableHead>
              <TableHead className="text-dark-100">Bot</TableHead>
              <TableHead className="text-dark-100">Pair</TableHead>
              <TableHead className="text-dark-100">Type</TableHead>
              <TableHead className="text-dark-100">Price</TableHead>
              <TableHead className="text-dark-100">Amount</TableHead>
              <TableHead className="text-dark-100">Status</TableHead>
              <TableHead className="text-dark-100">Profit</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-6">
                  Loading trades...
                </TableCell>
              </TableRow>
            ) : currentTrades.length > 0 ? (
              currentTrades.map((trade) => {
                const isProfitable = trade.profit > 0;
                return (
                  <TableRow key={trade.id} className="hover:bg-dark-300/50 border-dark-300">
                    <TableCell title={getTimeAgo(trade.openedAt)}>
                      {formatDateTime(trade.openedAt)}
                    </TableCell>
                    <TableCell>{getBotName(trade.botId)}</TableCell>
                    <TableCell>{trade.tradingPair}</TableCell>
                    <TableCell>
                      <span className={trade.type === "BUY" ? "text-secondary" : "text-danger"}>
                        {trade.type}
                      </span>
                    </TableCell>
                    <TableCell>${trade.price.toFixed(2)}</TableCell>
                    <TableCell>
                      {trade.amount} {trade.tradingPair.split("/")[0]}
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        trade.status === "OPEN" 
                          ? "bg-primary/20 text-primary" 
                          : trade.status === "CLOSED" 
                            ? "bg-secondary/20 text-secondary"
                            : "bg-danger/20 text-danger"
                      }`}>
                        {trade.status}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={isProfitable ? "text-secondary" : "text-danger"}>
                        {isProfitable ? "+" : ""}{isProfitable ? "$" + trade.profit.toFixed(2) : "-$" + Math.abs(trade.profit).toFixed(2)}
                      </span>
                    </TableCell>
                  </TableRow>
                );
              })
            ) : (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-6">
                  No trades found matching your filters
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      
      {/* Pagination */}
      {trades.length > 0 && (
        <div className="flex items-center justify-between p-4">
          <div className="text-sm text-dark-100">
            Showing {indexOfFirstItem + 1}-{Math.min(indexOfLastItem, trades.length)} of {trades.length} trades
          </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              className="bg-dark-300 hover:bg-dark-200 text-white border-dark-300"
              onClick={() => goToPage(currentPage - 1)}
              disabled={currentPage === 1}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="bg-dark-300 hover:bg-dark-200 text-white border-dark-300"
              onClick={() => goToPage(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
