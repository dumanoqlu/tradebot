import { apiRequest } from "./queryClient";
import { Signal, TakeProfitLevel } from "@shared/schema";

export async function testBinanceConnection(apiKey: string, apiSecret: string) {
  console.log("Frontend: Testing Binance connection");
  
  try {
    // API anahtarı formatını kontrol et
    if (!apiKey || apiKey.length < 10) {
      console.error("Invalid API key format");
      return { success: false, error: "API anahtarı geçersiz formatta" };
    }
    
    // API Secret formatını kontrol et
    if (!apiSecret || apiSecret.length < 10) {
      console.error("Invalid API secret format");
      return { success: false, error: "API gizli anahtarı geçersiz formatta" };
    }
    
    console.log(`Sending test request with API key: ${apiKey.substring(0, 4)}...${apiKey.slice(-4)}`);
    
    // İstek gönderiliyor
    const response = await apiRequest('POST', '/api/binance/test', { 
      apiKey, 
      apiSecret 
    });
    
    // Yanıt alındı
    console.log("Got Binance test response:", response.status);
    
    // JSON yanıtını çözümle
    const data = await response.json();
    console.log("Binance connection test result:", data);
    
    return data;
  } catch (error: any) {
    console.error("Error testing Binance connection:", error);
    
    // Farklı hata durumlarını ele al
    if (error.message && error.message.includes('Failed to fetch')) {
      return { 
        success: false, 
        error: "Sunucu bağlantısı kurulamadı. Lütfen internet bağlantınızı kontrol edin." 
      };
    }
    
    // Genel hata durumu
    return { 
      success: false, 
      error: error.message || "Bağlantı hatası" 
    };
  }
}

export async function getBinanceAccountInfo() {
  const response = await apiRequest('GET', '/api/binance/account');
  return response.json();
}

export async function getBinancePrice(symbol: string) {
  const response = await apiRequest('GET', `/api/binance/price/${symbol}`);
  return response.json();
}

export async function processSignal(botId: number, signal: Signal) {
  const response = await apiRequest('POST', `/api/bots/${botId}/signal`, signal);
  return response.json();
}

export function formatPair(symbol: string): string {
  // Convert Binance format like "BTCUSDT" to "BTC/USDT"
  // This makes it more readable for the UI
  
  // Common quote currencies
  const quotes = ['USDT', 'BUSD', 'BTC', 'ETH', 'BNB'];
  
  for (const quote of quotes) {
    if (symbol.endsWith(quote)) {
      return `${symbol.slice(0, -quote.length)}/${quote}`;
    }
  }
  
  // Default fallback if no known quote currency is found
  return symbol;
}

export function parseSymbol(pair: string): string {
  // Convert from UI display format "BTC/USDT" to Binance API format "BTCUSDT"
  return pair.replace('/', '');
}

// Calculate potential profit for take profit levels
export function calculateTakeProfitValues(
  entryPrice: number,
  orderSize: number,
  takeProfitLevels: TakeProfitLevel[]
) {
  return takeProfitLevels.map(level => {
    const targetPrice = entryPrice * (1 + level.target / 100);
    const quantityForLevel = orderSize * (level.volume / 100);
    const profitForLevel = (targetPrice - entryPrice) * quantityForLevel;
    
    // Leverage değeri ile çarpım (varsayılan olarak 1x)
    const leveragedProfitForLevel = profitForLevel;
    
    // Veri yapısını döndür
    return {
      ...level,
      price: targetPrice.toFixed(2), // Gerçek fiyat (UI'da gösterilecek)
      targetPrice,
      quantityForLevel,
      profitForLevel: leveragedProfitForLevel, // Kâr değeri
    };
  });
}

// Calculate stop loss values
export function calculateStopLoss(
  entryPrice: number,
  orderSize: number,
  stopLossPercentage: number
) {
  const stopPrice = entryPrice * (1 - stopLossPercentage / 100);
  const potentialLoss = (entryPrice - stopPrice) * orderSize;
  
  // Fiyat hesaplamalarını daha kullanışlı formatta döndür
  return {
    price: stopPrice.toFixed(2), // Gerçek fiyat (UI'da gösterilecek)
    stopPrice,
    potentialLoss
  };
}
