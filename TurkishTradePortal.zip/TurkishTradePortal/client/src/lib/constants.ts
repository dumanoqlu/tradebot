export const TRADING_PAIRS = [
  'BTC/USDT',
  'ETH/USDT',
  'SOL/USDT',
  'DOGE/USDT',
  'ADA/USDT',
  'XRP/USDT',
  'BNB/USDT',
  'DOT/USDT',
  'LINK/USDT',
  'LTC/USDT',
  'AVAX/USDT',
  'MATIC/USDT',
];

export const SIGNAL_SOURCES = [
  'tradingview'
];

export const SIGNAL_SOURCE_LABELS: Record<string, string> = {
  'tradingview': 'TradingView'
};

export const INDICATORS = [
  { value: 'rsi', label: 'RSI (Relative Strength Index)' },
  { value: 'macd', label: 'MACD (Moving Average Convergence Divergence)' },
  { value: 'bollinger', label: 'Bollinger Bands' },
  { value: 'ema', label: 'EMA (Exponential Moving Average)' },
  { value: 'ichimoku', label: 'Ichimoku Cloud' },
  { value: 'stochastic', label: 'Stochastic Oscillator' },
  { value: 'adx', label: 'ADX (Average Directional Index)' },
  { value: 'momentum', label: 'Momentum' },
];

export const DEFAULT_TP_LEVELS = [
  { target: 1.5, volume: 25 },
  { target: 2.5, volume: 25 },
  { target: 4.0, volume: 25 },
  { target: 6.0, volume: 25 },
];

export const ORDER_UNITS = [
  'USDT',
  'BTC',
  'ETH',
  '%',
];
