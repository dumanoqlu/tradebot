/**
 * This file contains utility functions for technical indicators
 * Used for visualizations and explanations in the UI
 */

// RSI (Relative Strength Index)
export function describeRSI(period: number = 14) {
  return {
    name: "Relative Strength Index",
    shortName: "RSI",
    description: `RSI is a momentum oscillator that measures the speed and change of price movements. 
                 RSI oscillates between 0 and 100. Traditionally, RSI is considered overbought when above 70 
                 and oversold when below 30. Buy signals occur when RSI crosses above 30, and sell signals 
                 occur when RSI crosses below 70.`,
    period,
    buyCondition: `RSI(${period}) crosses above 30`,
    sellCondition: `RSI(${period}) crosses below 70`,
    tradingViewPineScript: `
      //@version=4
      study("RSI Signal Bot", overlay=false)
      rsiLength = input(${period}, "RSI Length")
      rsiValue = rsi(close, rsiLength)
      buySignal = crossover(rsiValue, 30)
      sellSignal = crossunder(rsiValue, 70)
      plot(rsiValue, "RSI", color=color.blue)
      hline(70, "Overbought", color=color.red)
      hline(30, "Oversold", color=color.green)
      plotshape(buySignal, "Buy", shape.triangleup, location.bottom, color.green, size=size.small)
      plotshape(sellSignal, "Sell", shape.triangledown, location.top, color.red, size=size.small)
      alert(buySignal, "RSI Buy Signal", alert.freq_once_per_bar)
      alert(sellSignal, "RSI Sell Signal", alert.freq_once_per_bar)
    `
  };
}

// MACD (Moving Average Convergence Divergence)
export function describeMACD(fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9) {
  return {
    name: "Moving Average Convergence Divergence",
    shortName: "MACD",
    description: `MACD is a trend-following momentum indicator that shows the relationship between two moving averages of a security's price.
                 The MACD is calculated by subtracting the ${slowPeriod}-period EMA from the ${fastPeriod}-period EMA. The signal line is a ${signalPeriod}-period EMA of the MACD line.
                 Buy signals occur when the MACD line crosses above the signal line, and sell signals occur when the MACD line crosses below the signal line.`,
    fastPeriod,
    slowPeriod,
    signalPeriod,
    buyCondition: `MACD line crosses above signal line`,
    sellCondition: `MACD line crosses below signal line`,
    tradingViewPineScript: `
      //@version=4
      study("MACD Signal Bot", overlay=false)
      fastLength = input(${fastPeriod}, "Fast Length")
      slowLength = input(${slowPeriod}, "Slow Length")
      signalLength = input(${signalPeriod}, "Signal Length")
      [macdLine, signalLine, histLine] = macd(close, fastLength, slowLength, signalLength)
      buySignal = crossover(macdLine, signalLine)
      sellSignal = crossunder(macdLine, signalLine)
      plot(macdLine, "MACD", color=color.blue)
      plot(signalLine, "Signal", color=color.orange)
      plot(histLine, "Histogram", color=histLine >= 0 ? color.green : color.red, style=plot.style_histogram)
      plotshape(buySignal, "Buy", shape.triangleup, location.bottom, color.green, size=size.small)
      plotshape(sellSignal, "Sell", shape.triangledown, location.top, color.red, size=size.small)
      alert(buySignal, "MACD Buy Signal", alert.freq_once_per_bar)
      alert(sellSignal, "MACD Sell Signal", alert.freq_once_per_bar)
    `
  };
}

// Bollinger Bands
export function describeBollingerBands(period: number = 20, stdDev: number = 2) {
  return {
    name: "Bollinger Bands",
    shortName: "BB",
    description: `Bollinger Bands consist of a middle band (an SMA) with two outer bands that are standard deviations away from the middle band.
                 The bands widen during periods of high volatility and contract during periods of low volatility.
                 Buy signals typically occur when the price crosses above the lower band after being below it, and sell signals occur when the price crosses below the upper band after being above it.`,
    period,
    stdDev,
    buyCondition: `Price crosses above lower band after being below it`,
    sellCondition: `Price crosses below upper band after being above it`,
    tradingViewPineScript: `
      //@version=4
      study("Bollinger Bands Signal Bot", overlay=true)
      bbLength = input(${period}, "BB Length")
      bbMult = input(${stdDev}, "BB StdDev")
      [middle, upper, lower] = bb(close, bbLength, bbMult)
      belowLower = close < lower
      aboveUpper = close > upper
      crossAboveLower = crossover(close, lower)
      crossBelowUpper = crossunder(close, upper)
      buySignal = belowLower[1] and crossAboveLower
      sellSignal = aboveUpper[1] and crossBelowUpper
      plot(middle, "Middle", color=color.blue)
      plot(upper, "Upper", color=color.red)
      plot(lower, "Lower", color=color.green)
      plotshape(buySignal, "Buy", shape.triangleup, location.belowbar, color.green, size=size.small)
      plotshape(sellSignal, "Sell", shape.triangledown, location.abovebar, color.red, size=size.small)
      alert(buySignal, "BB Buy Signal", alert.freq_once_per_bar)
      alert(sellSignal, "BB Sell Signal", alert.freq_once_per_bar)
    `
  };
}

// Stochastic Oscillator
export function describeStochastic(kPeriod: number = 14, dPeriod: number = 3, smooth: number = 3) {
  return {
    name: "Stochastic Oscillator",
    shortName: "STOCH",
    description: `The Stochastic Oscillator is a momentum indicator that shows the location of the close relative to the high-low range over a set number of periods.
                 The indicator ranges from 0 to 100. Buy signals occur when the %K line crosses above the %D line in the oversold region (below 20),
                 and sell signals occur when the %K line crosses below the %D line in the overbought region (above 80).`,
    kPeriod,
    dPeriod,
    smooth,
    buyCondition: `%K crosses above %D while below 20`,
    sellCondition: `%K crosses below %D while above 80`,
    tradingViewPineScript: `
      //@version=4
      study("Stochastic Signal Bot", overlay=false)
      kLength = input(${kPeriod}, "K Length")
      dLength = input(${dPeriod}, "D Length")
      smoothK = input(${smooth}, "K Smoothing")
      k = sma(stoch(close, high, low, kLength), smoothK)
      d = sma(k, dLength)
      oversold = 20
      overbought = 80
      buySignal = crossover(k, d) and k < oversold
      sellSignal = crossunder(k, d) and k > overbought
      plot(k, "%K", color=color.blue)
      plot(d, "%D", color=color.orange)
      hline(overbought, "Overbought", color=color.red)
      hline(oversold, "Oversold", color=color.green)
      plotshape(buySignal, "Buy", shape.triangleup, location.bottom, color.green, size=size.small)
      plotshape(sellSignal, "Sell", shape.triangledown, location.top, color.red, size=size.small)
      alert(buySignal, "Stochastic Buy Signal", alert.freq_once_per_bar)
      alert(sellSignal, "Stochastic Sell Signal", alert.freq_once_per_bar)
    `
  };
}
