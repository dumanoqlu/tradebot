export async function testOkxConnection(apiKey: string, apiSecret: string, passphrase: string) {
  try {
    const response = await fetch("/api/okx/test", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ apiKey, apiSecret, passphrase }),
    });

    return await response.json();
  } catch (error) {
    console.error("Error testing OKX API connection:", error);
    return {
      success: false,
      message: "API bağlantı testi sırasında bir hata oluştu.",
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

export async function getOkxAccountInfo() {
  try {
    const response = await fetch("/api/okx/account");
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error("Error fetching OKX account info:", error);
    throw error;
  }
}

export async function getOkxPrice(symbol: string) {
  try {
    const response = await fetch(`/api/okx/price/${symbol}`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error("Error fetching OKX price:", error);
    throw error;
  }
}

export function formatPair(symbol: string): string {
  // Format pair for OKX (e.g., BTC/USDT -> BTC-USDT-SWAP)
  return symbol.replace("/", "-") + "-SWAP";
}

export function parseSymbol(pair: string): string {
  // Parse OKX instrument ID to standard format (e.g., BTC-USDT-SWAP -> BTC/USDT)
  return pair.replace("-SWAP", "").replace("-", "/");
}