import { useQuery } from "@tanstack/react-query";
import {
  BarChart2,
  LineChart,
  ExternalLink,
  Percent,
  Wallet,
  Coins
} from "lucide-react";
import { PageLayout } from "@/components/layout/page-layout";
import { StatCard } from "@/components/stats/stat-card";
import { TradeRow } from "@/components/trades/trade-row";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trade, Bot } from "@shared/schema";

export default function Dashboard() {
  // Fetch bots
  const { data: bots, isLoading: isLoadingBots } = useQuery<Bot[]>({
    queryKey: ['/api/bots'],
  });

  // Fetch trades
  const { data: trades, isLoading: isLoadingTrades } = useQuery<Trade[]>({
    queryKey: ['/api/trades'],
  });
  
  // Fetch account info directly from OKX API
  const { data: accountInfo, isLoading: isLoadingAccount, error: accountError } = useQuery({
    queryKey: ['/api/okx/account'],
    // 1 dakika aralıklarla yenile
    refetchInterval: 60000
  });

  // Calculate stats
  const activeBots = bots?.filter(bot => bot.isActive)?.length || 0;
  const totalTrades = trades?.length || 0;
  
  // Calculate total profit
  const totalProfit = trades?.reduce((sum, trade) => sum + (Number(trade.profit) || 0), 0) || 0;
  
  // Calculate win rate
  const profitableTrades = trades?.filter(trade => (Number(trade.profit) || 0) > 0)?.length || 0;
  const winRate = totalTrades > 0 ? (profitableTrades / totalTrades) * 100 : 0;
  
  // Hesap bakiyelerini hazırla
  const getBalances = () => {
    // accountInfo tipini kontrol et ve düzgün bir şekilde balances dizisini al
    if (!accountInfo) return [];
    
    // Tip güvenliği için açık bir tip dönüşümü yapalım
    const accountData = accountInfo as any;
    
    // OKX API yanıtını işleme
    if (Array.isArray(accountData)) {
      // Ana hesap bilgilerini ayrıştır (OKX formatı)
      // OKX'de 'details' dizisi para birimlerini içerir
      const details = accountData[0]?.details;
      
      if (!Array.isArray(details)) return [];
      
      // Para birimlerini filtrele ve formatlı bir şekilde geri döndür
      return details
        .filter((b: any) => parseFloat(b.availBal) > 0 || parseFloat(b.frozenBal) > 0)
        .sort((a: any, b: any) => {
          // USDT, BTC, ETH gibi ana varlıkları üstte göster
          const mainAssets = ['USDT', 'BTC', 'ETH', 'USDC'];
          const aIndex = mainAssets.indexOf(a.ccy);
          const bIndex = mainAssets.indexOf(b.ccy);
          
          if (aIndex !== -1 && bIndex !== -1) return aIndex - bIndex;
          if (aIndex !== -1) return -1;
          if (bIndex !== -1) return 1;
          
          // Daha sonra bakiyesi büyük olanları göster
          const aTotal = parseFloat(a.availBal) + parseFloat(a.frozenBal);
          const bTotal = parseFloat(b.availBal) + parseFloat(b.frozenBal);
          return bTotal - aTotal;
        })
        .map((b: any) => ({
          asset: b.ccy,
          free: b.availBal,
          locked: b.frozenBal,
          total: parseFloat(b.availBal) + parseFloat(b.frozenBal)
        }))
        .slice(0, 10); // Sadece ilk 10 varlığı göster
    }
    
    // Eski Binance formatını destekle (API geçişi için)
    if (accountData?.balances && Array.isArray(accountData.balances)) {
      return accountData.balances
        .filter((b: any) => parseFloat(b.free) > 0 || parseFloat(b.locked) > 0)
        .sort((a: any, b: any) => {
          // USDT, BTC, ETH gibi ana varlıkları üstte göster
          const mainAssets = ['USDT', 'BTC', 'ETH', 'BNB'];
          const aIndex = mainAssets.indexOf(a.asset);
          const bIndex = mainAssets.indexOf(b.asset);
          
          if (aIndex !== -1 && bIndex !== -1) return aIndex - bIndex;
          if (aIndex !== -1) return -1;
          if (bIndex !== -1) return 1;
          
          // Daha sonra bakiyesi büyük olanları göster
          const aTotal = parseFloat(a.free) + parseFloat(a.locked);
          const bTotal = parseFloat(b.free) + parseFloat(b.locked);
          return bTotal - aTotal;
        })
        .slice(0, 10); // Sadece ilk 10 varlığı göster
    }
    
    return [];
  };

  return (
    <PageLayout>
      <div className="p-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Kontrol Paneli</h1>
            <p className="text-dark-100">İşlem performansınızın genel görünümü</p>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard
            title="Aktif Botlar"
            value={activeBots}
            change={1}
            changeText="dünden beri"
            icon={<Robot className="h-5 w-5" />}
          />
          
          <StatCard
            title="Toplam Kar"
            value={`$${totalProfit.toFixed(2)}`}
            change="2.4%"
            changeText="7 günlük performans"
            icon={<LineChart className="h-5 w-5" />}
          />
          
          <StatCard
            title="Toplam İşlemler"
            value={totalTrades}
            change={Math.min(totalTrades, 12)}
            changeText="bugün yeni işlem"
            icon={<ExternalLink className="h-5 w-5" />}
          />
          
          <StatCard
            title="Kazanç Oranı"
            value={`${winRate.toFixed(0)}%`}
            change="3%"
            changeText="geçen haftaya göre"
            icon={<Percent className="h-5 w-5" />}
          />
        </div>

        {/* Account Balance Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Total Balance Card */}
          <Card className="bg-dark-400 border-none overflow-hidden h-full">
            <CardHeader className="border-b border-dark-300 px-4 py-3">
              <CardTitle className="text-lg font-semibold">Toplam Bakiye</CardTitle>
            </CardHeader>
            <CardContent className="p-4 flex items-center justify-center">
              {isLoadingAccount ? (
                <div className="flex items-center justify-center h-48">
                  <p>Bilgiler yükleniyor...</p>
                </div>
              ) : !accountInfo ? (
                <div className="flex flex-col gap-4 items-center justify-center py-10 h-48">
                  <Wallet className="h-12 w-12 text-dark-100" />
                  <p className="text-center text-dark-100">
                    API anahtarı yapılandırılmamış
                  </p>
                  <Button 
                    size="sm" 
                    onClick={() => window.location.href = "/settings"}
                  >
                    Ayarlara Git
                  </Button>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 h-48">
                  <div className="text-dark-100 text-sm mb-1">Toplam Değer</div>
                  <div className="text-3xl font-bold text-white mb-4">
                    ${parseFloat(
                      accountInfo?.success ? accountInfo.totalEq : "0"
                    ).toFixed(2)}
                  </div>
                  <div className="text-dark-100 text-sm mb-1">Kullanılabilir</div>
                  <div className="text-xl font-medium text-white">
                    ${parseFloat(
                      accountInfo?.success ? accountInfo.availableEq : "0"
                    ).toFixed(2)}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Assets Card */}
          <Card className="bg-dark-400 border-none overflow-auto h-full">
            <CardHeader className="border-b border-dark-300 px-4 py-3">
              <CardTitle className="text-lg font-semibold">Varlıklar</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              {isLoadingAccount ? (
                <div className="flex items-center justify-center h-full">
                  <p>Varlıklar yükleniyor...</p>
                </div>
              ) : !accountInfo ? (
                <div className="flex flex-col gap-4 items-center justify-center py-10">
                  <p className="text-center text-dark-100 text-xs">
                    Lütfen Ayarlar sayfasından geçerli bir OKX API anahtarı ekleyin ve etkinleştirin
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-white">Varlık</p>
                    <p className="font-medium text-white">Bakiye</p>
                  </div>
                  <div className="divide-y divide-dark-300 max-h-48 overflow-y-auto">
                    {getBalances().map((balance: any) => (
                      <div 
                        key={balance.asset} 
                        className="py-3 flex items-center justify-between"
                      >
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-dark-300 flex items-center justify-center mr-3">
                            <Coins className="h-4 w-4" />
                          </div>
                          <div>
                            <p className="font-medium text-white">{balance.asset}</p>
                            {parseFloat(balance.locked) > 0 && (
                              <Badge variant="outline" className="ml-1 text-xs">
                                {parseFloat(balance.locked).toFixed(6)} kilitli
                              </Badge>
                            )}
                          </div>
                        </div>
                        <p className="font-medium text-white">
                          {parseFloat(balance.free).toFixed(
                            balance.asset === "USDT" ? 2 : 6
                          )}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent Trades */}
        <Card className="bg-dark-400 border-none overflow-hidden">
          <CardHeader className="flex flex-row justify-between items-center border-b border-dark-300 px-4 py-3">
            <CardTitle className="text-lg font-semibold">Son İşlemler</CardTitle>
            <Button variant="link" className="text-primary text-sm h-auto p-0">
              Tümünü Gör
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="bg-dark-300 text-dark-100 text-xs uppercase">
                    <th className="px-4 py-3 text-left">Tarih</th>
                    <th className="px-4 py-3 text-left">Bot</th>
                    <th className="px-4 py-3 text-left">Çift</th>
                    <th className="px-4 py-3 text-left">Tür</th>
                    <th className="px-4 py-3 text-left">Fiyat</th>
                    <th className="px-4 py-3 text-left">Miktar</th>
                    <th className="px-4 py-3 text-left">Kar</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {isLoadingTrades ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-3 text-center">
                        İşlemler yükleniyor...
                      </td>
                    </tr>
                  ) : trades && trades.length > 0 ? (
                    trades.slice(0, 5).map((trade) => (
                      <TradeRow 
                        key={trade.id} 
                        trade={trade} 
                        bot={bots?.find(b => b.id === trade.botId)} 
                      />
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="px-4 py-3 text-center">
                        İşlem bulunamadı
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  );
}

function Robot(props: any) {
  return <BarChart2 {...props} />;
}
