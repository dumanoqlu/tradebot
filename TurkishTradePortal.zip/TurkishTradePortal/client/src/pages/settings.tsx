import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PageLayout } from "@/components/layout/page-layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ApiKeyForm } from "@/components/settings/api-key-form";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ApiKey } from "@shared/schema";
import { Shield, Key, Bell, User, HelpCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Settings() {
  const [activeTab, setActiveTab] = useState("api-keys");
  const { toast } = useToast();
  
  // API anahtarını etkinleştir/devre dışı bırak
  const toggleApiKeyActive = (apiKey: ApiKey) => {
    apiRequest('PUT', `/api/keys/${apiKey.id}`, {
      isActive: !apiKey.isActive
    }).then(() => {
      // Verileri yeniden yükle
      queryClient.invalidateQueries({ queryKey: ['/api/keys'] });
      
      toast({
        title: apiKey.isActive ? "API anahtarı devre dışı bırakıldı" : "API anahtarı etkinleştirildi",
        description: apiKey.isActive 
          ? "API anahtarı başarıyla devre dışı bırakıldı." 
          : "API anahtarı başarıyla etkinleştirildi."
      });
    }).catch(error => {
      console.error("API anahtarı güncellenirken hata:", error);
      toast({
        title: "Hata",
        description: "API anahtarı güncellenirken bir hata oluştu.",
        variant: "destructive"
      });
    });
  };
  
  // API anahtarını sil
  const deleteApiKey = (apiKey: ApiKey) => {
    if (window.confirm("Bu API anahtarını silmek istediğinizden emin misiniz?")) {
      apiRequest('DELETE', `/api/keys/${apiKey.id}`).then(() => {
        // Verileri yeniden yükle
        queryClient.invalidateQueries({ queryKey: ['/api/keys'] });
        
        toast({
          title: "API anahtarı silindi",
          description: "API anahtarı başarıyla silindi."
        });
      }).catch(error => {
        console.error("API anahtarı silinirken hata:", error);
        toast({
          title: "Hata",
          description: "API anahtarı silinirken bir hata oluştu.",
          variant: "destructive"
        });
      });
    }
  };
  
  // Fetch API keys
  const { data: apiKeys, isLoading } = useQuery<ApiKey[]>({
    queryKey: ['/api/keys'],
  });

  return (
    <PageLayout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white mb-2">Ayarlar</h1>
          <p className="text-dark-100">Hesabınızı ve platform tercihlerinizi yapılandırın</p>
        </div>

        {/* Settings Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-dark-300 border-dark-300 p-1">
            <TabsTrigger
              value="api-keys"
              className="data-[state=active]:bg-primary data-[state=active]:text-white"
            >
              <Key className="mr-2 h-4 w-4" />
              API Anahtarları
            </TabsTrigger>
            <TabsTrigger
              value="security"
              className="data-[state=active]:bg-primary data-[state=active]:text-white"
            >
              <Shield className="mr-2 h-4 w-4" />
              Güvenlik
            </TabsTrigger>
            <TabsTrigger
              value="notifications"
              className="data-[state=active]:bg-primary data-[state=active]:text-white"
            >
              <Bell className="mr-2 h-4 w-4" />
              Bildirimler
            </TabsTrigger>
            <TabsTrigger
              value="profile"
              className="data-[state=active]:bg-primary data-[state=active]:text-white"
            >
              <User className="mr-2 h-4 w-4" />
              Profil
            </TabsTrigger>
          </TabsList>

          {/* API Keys Tab */}
          <TabsContent value="api-keys" className="space-y-4">
            <Card className="bg-dark-400 border-dark-300">
              <CardHeader>
                <CardTitle>Borsa API Anahtarları</CardTitle>
                <CardDescription className="text-dark-100">
                  Otomatik işlem yapmak için OKX demo hesabınızı bağlayın
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="text-center py-4">API anahtarları yükleniyor...</div>
                ) : (
                  <>
                    {/* List existing API keys */}
                    {apiKeys && apiKeys.length > 0 ? (
                      <div className="space-y-4 mb-6">
                        {apiKeys.map((apiKey) => (
                          <div
                            key={apiKey.id}
                            className="flex items-center justify-between p-4 bg-dark-300 rounded-lg"
                          >
                            <div>
                              <h3 className="font-medium">{apiKey.name}</h3>
                              <p className="text-sm text-dark-100">
                                API Key: {apiKey.apiKey}
                              </p>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="bg-dark-300 hover:bg-dark-200 text-white border-dark-200"
                                onClick={() => toggleApiKeyActive(apiKey)}
                              >
                                {apiKey.isActive ? "Devre Dışı Bırak" : "Etkinleştir"}
                              </Button>
                              <Button
                                variant="destructive"
                                size="sm"
                                className="bg-danger/20 hover:bg-danger/30 text-danger"
                                onClick={() => deleteApiKey(apiKey)}
                              >
                                Sil
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-4 mb-6">
                        <p className="text-dark-100 mb-4">Henüz API anahtarı eklenmedi</p>
                      </div>
                    )}

                    {/* API Key Form */}
                    <ApiKeyForm />
                  </>
                )}
              </CardContent>
            </Card>

            <Card className="bg-dark-400 border-dark-300">
              <CardHeader>
                <CardTitle>OKX API Kurulum Talimatları</CardTitle>
                <CardDescription className="text-dark-100">
                  OKX API anahtarlarınızı güvenli bir şekilde nasıl oluşturur ve yapılandırırsınız
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="item-1" className="border-dark-300">
                    <AccordionTrigger className="text-white">
                      OKX API anahtarı nasıl oluşturulur
                    </AccordionTrigger>
                    <AccordionContent className="text-dark-100">
                      <ol className="list-decimal pl-5 space-y-2">
                        <li>OKX hesabınıza giriş yapın</li>
                        <li>Sağ üst köşedeki profil simgesine tıklayın ve "API" seçeneğini seçin</li>
                        <li>"Yeni API Oluştur"a tıklayın</li>
                        <li>Güvenlik doğrulamasını tamamlayın</li>
                        <li>API anahtarınıza bir isim verin ve bir Passphrase oluşturun</li>
                        <li>İşlem izinlerini seçin ve "Devam"a tıklayın</li>
                        <li>API Key, Secret Key ve Passphrase bilgilerini güvenli şekilde saklayın</li>
                      </ol>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="item-2" className="border-dark-300">
                    <AccordionTrigger className="text-white">
                      Gerekli API izinleri
                    </AccordionTrigger>
                    <AccordionContent className="text-dark-100">
                      <p className="mb-2">Tam işlevsellik için, bu izinleri etkinleştirin:</p>
                      <ul className="list-disc pl-5 space-y-1">
                        <li>Okuma İzni (Read)</li>
                        <li>Ticaret İzni (Trade)</li>
                        <li>Marjin İşlemler, Türev İşlemler veya Vadeli İşlemler (kullanacağınız hesap türüne göre)</li>
                      </ul>
                      <p className="mt-2 text-destructive">Güvenlik nedeniyle para çekme (Withdraw) izinlerini ETKİNLEŞTİRMEYİN!</p>
                    </AccordionContent>
                  </AccordionItem>

                  <AccordionItem value="item-3" className="border-dark-300">
                    <AccordionTrigger className="text-white">
                      Güvenlik en iyi uygulamaları
                    </AccordionTrigger>
                    <AccordionContent className="text-dark-100">
                      <ul className="list-disc pl-5 space-y-1">
                        <li>API Secret Key ve Passphrase asla paylaşmayın</li>
                        <li>OKX API ayarlarında IP kısıtlamalarını etkinleştirin</li>
                        <li>Demo hesabı için ayrı API anahtarları oluşturun</li>
                        <li>API anahtarlarınızı düzenli olarak gözden geçirin ve denetleyin</li>
                        <li>Şüpheli bir durumda API anahtarınızı hemen devre dışı bırakın</li>
                        <li>OKX Demo hesabında işlem yapmak için API oluştururken "Demo Trading" seçeneğini etkinleştirin</li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-4" className="border-dark-300">
                    <AccordionTrigger className="text-white">
                      OKX Demo Hesabı Kullanımı
                    </AccordionTrigger>
                    <AccordionContent className="text-dark-100">
                      <p className="mb-2">OKX ile güvenli şekilde çalışmak için Demo hesabı kullanabilirsiniz:</p>
                      <ol className="list-decimal pl-5 space-y-2">
                        <li>OKX'te oturum açtıktan sonra, "Ticaret" bölümünde "Demo Ticaret" seçeneğine tıklayın</li>
                        <li>Demo hesabınızı oluşturun ve etkinleştirin</li>
                        <li>Demo hesabınız için API anahtarları oluşturun - "Demo Trading" seçeneğini işaretlemeyi unutmayın</li>
                        <li>Bu API anahtarlarını gerçek fonları riske atmadan trading bot'unuzla test edebilirsiniz</li>
                      </ol>
                      <p className="mt-2 text-warning">Not: Demo hesabı, gerçek hesapla aynı işlevselliğe sahiptir ancak gerçek para kullanılmaz.</p>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other Tabs (Placeholders) */}
          <TabsContent value="security">
            <Card className="bg-dark-400 border-dark-300">
              <CardHeader>
                <CardTitle>Güvenlik Ayarları</CardTitle>
                <CardDescription className="text-dark-100">
                  Hesap güvenlik tercihlerinizi yapılandırın
                </CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center items-center py-8">
                <div className="text-center">
                  <HelpCircle className="mx-auto h-12 w-12 text-dark-200 mb-3" />
                  <p className="text-dark-100">Güvenlik ayarları gelecekteki bir güncellemede kullanılabilir olacak</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="notifications">
            <Card className="bg-dark-400 border-dark-300">
              <CardHeader>
                <CardTitle>Bildirim Ayarları</CardTitle>
                <CardDescription className="text-dark-100">
                  Bildirim tercihlerinizi yapılandırın
                </CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center items-center py-8">
                <div className="text-center">
                  <HelpCircle className="mx-auto h-12 w-12 text-dark-200 mb-3" />
                  <p className="text-dark-100">Bildirim ayarları gelecekteki bir güncellemede kullanılabilir olacak</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="profile">
            <Card className="bg-dark-400 border-dark-300">
              <CardHeader>
                <CardTitle>Profil Ayarları</CardTitle>
                <CardDescription className="text-dark-100">
                  Profil bilgilerinizi güncelleyin
                </CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center items-center py-8">
                <div className="text-center">
                  <HelpCircle className="mx-auto h-12 w-12 text-dark-200 mb-3" />
                  <p className="text-dark-100">Profil ayarları gelecekteki bir güncellemede kullanılabilir olacak</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageLayout>
  );
}
