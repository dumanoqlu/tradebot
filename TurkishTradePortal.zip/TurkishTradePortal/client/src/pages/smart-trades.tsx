import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Plus, LineChart, ArrowRightLeft, Sliders, BarChart4, Wallet, RefreshCw, CircleOff, AlertTriangle } from "lucide-react";
import { PageLayout } from "@/components/layout/page-layout";
import { StatCard } from "@/components/stats/stat-card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CreateSmartTradeModal } from "@/components/smart-trades/create-smart-trade-modal";
import { SmartTradeCard } from "@/components/smart-trades/smart-trade-card";
import { Card, CardContent } from "@/components/ui/card";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Trade } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";

export default function SmartTrades() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isCloseAllDialogOpen, setIsCloseAllDialogOpen] = useState(false);
  const [isClosingAll, setIsClosingAll] = useState(false);
  const { toast } = useToast();

  // Fetch account info from OKX
  const { data: accountInfo, isLoading: isLoadingAccount } = useQuery({
    queryKey: ['/api/okx/account'],
    refetchInterval: 60000
  });
  
  // Function to close all trades
  const closeAllTrades = async () => {
    if (!smartTrades || smartTrades.length === 0) return;
    
    try {
      setIsClosingAll(true);
      const now = new Date().toISOString();
      
      // Parallel processing of all trade closures
      const results = await Promise.all(smartTrades.map(async (trade) => {
        try {
          // Create notes with TP/SL info if available
          let takeProfitLevels = [];
          let stopLoss = 3.0; // Default
          
          try {
            if (trade.notes && (trade.notes.includes("takeProfitLevels") || trade.notes.includes("stopLoss"))) {
              const notesObj = JSON.parse(trade.notes);
              if (notesObj.takeProfitLevels) {
                takeProfitLevels = notesObj.takeProfitLevels;
              }
              if (notesObj.stopLoss) {
                stopLoss = notesObj.stopLoss;
              }
            }
          } catch (e) {
            console.error("Error parsing notes:", e);
          }
          
          // Update trade to closed status
          const response = await apiRequest(
            "PUT",
            `/api/trades/${trade.id}`,
            {
              status: "CLOSED",
              closedAt: now,
              notes: JSON.stringify({
                takeProfitLevels,
                stopLoss,
                closeRequestTime: now,
                manualClose: true,
                batchClose: true
              }, null, 2)
            }
          );
          
          return {
            success: true,
            trade: response,
            id: trade.id
          };
        } catch (error) {
          console.error(`Error closing trade ${trade.id}:`, error);
          return {
            success: false,
            error: error instanceof Error ? error.message : String(error),
            id: trade.id
          };
        }
      }));
      
      // Count successful/failed operations
      const successful = results.filter(r => r.success).length;
      const failed = results.length - successful;
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/trades"] });
      
      // Show result notification
      toast({
        title: "İşlemler kapatıldı",
        description: `${successful} işlem başarıyla kapatıldı${failed > 0 ? `, ${failed} işlem kapatılamadı` : ""}`,
        variant: failed > 0 ? "destructive" : "default"
      });
      
    } catch (error) {
      console.error("Batch close error:", error);
      toast({
        title: "Hata",
        description: "İşlemler kapatılırken bir sorun oluştu",
        variant: "destructive"
      });
    } finally {
      setIsClosingAll(false);
      setIsCloseAllDialogOpen(false);
    }
  };

  // Fetch trades
  const { data: trades, isLoading } = useQuery<Trade[]>({
    queryKey: ['/api/trades'],
  });

  // In a real implementation, we would have a separate smart trades table
  // For this demo, we'll use the trades data to simulate smart trades
  const smartTrades = trades?.filter(trade => trade.status === 'OPEN') || [];
  const completedTrades = trades?.filter(trade => trade.status === 'CLOSED') || [];

  // Calculate stats
  const activeTrades = smartTrades.length;
  const totalCompletedTrades = completedTrades.length;
  
  // Calculate total profit from completed trades
  const totalProfit = completedTrades.reduce((sum, trade) => sum + (trade.profit || 0), 0);
  
  // Calculate win rate
  const profitableTrades = completedTrades.filter(trade => (trade.profit || 0) > 0).length;
  const winRate = totalCompletedTrades > 0 ? (profitableTrades / totalCompletedTrades) * 100 : 0;

  return (
    <PageLayout>
      <div className="p-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Akıllı İşlemler</h1>
            <p className="text-dark-100">Akıllı özelliklerle manuel işlemleri oluşturun ve yönetin</p>
          </div>
          <div className="mt-4 lg:mt-0">
            <Button
              onClick={() => setIsCreateModalOpen(true)}
              className="bg-primary hover:bg-primary/90 text-white"
            >
              <Plus className="mr-2 h-4 w-4" />
              Yeni Akıllı İşlem
            </Button>
          </div>
        </div>

        {/* OKX Account Balance */}
        <div className="mb-6">
          <Card className="bg-dark-400 border-none">
            <CardContent className="p-4">
              {isLoadingAccount ? (
                <div className="flex items-center justify-center py-2">
                  <p>Hesap bilgileri yükleniyor...</p>
                </div>
              ) : !accountInfo ? (
                <Alert className="bg-dark-300 border-primary text-white">
                  <Wallet className="h-4 w-4 mr-2" />
                  <AlertDescription>
                    OKX API bağlantısı yapılandırılmamış. Lütfen <a href="/settings" className="text-primary underline">Ayarlar</a> sayfasından API anahtarınızı ekleyin.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
                  <div className="flex items-center space-x-4 mb-2 sm:mb-0">
                    <Wallet className="h-5 w-5 text-primary" />
                    <div>
                      <p className="text-sm text-dark-100">OKX Demo Hesap Bakiyesi</p>
                      <p className="text-xl font-bold text-white">
                        ${typeof accountInfo === 'object' && Array.isArray(accountInfo) && accountInfo.length > 0 ? (accountInfo[0] as any)?.totalEq || "0.00" : "0.00"}
                      </p>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        queryClient.invalidateQueries({ queryKey: ['/api/okx/account'] });
                        toast({
                          title: "Bakiye Güncellendi",
                          description: "Hesap bakiyesi bilgileri güncellendi.",
                        });
                      }}
                      className="ml-2 bg-dark-300 hover:bg-dark-200 text-white"
                    >
                      <RefreshCw className="h-4 w-4 mr-1" />
                      Yenile
                    </Button>
                  </div>
                  <Button
                    onClick={() => setIsCreateModalOpen(true)}
                    className="bg-primary hover:bg-primary/90 text-white w-full sm:w-auto"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Yeni Akıllı İşlem
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Account Balance Panel */}
        {accountInfo && (
          <div className="bg-dark-400 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <Wallet className="text-primary mr-2 h-5 w-5" />
                <h3 className="text-lg font-medium">OKX Demo Hesap Bakiyesi</h3>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  queryClient.invalidateQueries({ queryKey: ['/api/okx/account'] });
                  toast({
                    title: "Bakiye Güncellendi",
                    description: "Hesap bakiyesi bilgileri güncellendi.",
                  });
                }}
                className="bg-dark-300 hover:bg-dark-200 text-white"
              >
                <RefreshCw className="h-4 w-4 mr-1" />
                Bakiyeyi Yenile
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-dark-300 p-3 rounded-lg">
                <p className="text-sm text-dark-100">Toplam Bakiye</p>
                <p className="text-xl font-bold">${typeof accountInfo === 'object' && accountInfo !== null && 'totalEq' in accountInfo ? (accountInfo as any).totalEq : "0.00"}</p>
              </div>
              <div className="bg-dark-300 p-3 rounded-lg">
                <p className="text-sm text-dark-100">USDT Bakiyesi</p>
                <p className="text-xl font-bold">
                  {typeof accountInfo === 'object' && accountInfo !== null && 'details' in accountInfo ? 
                    ((accountInfo as any).details?.find?.((d: any) => d.ccy === "USDT")?.availBal) || "0.00" : "0.00"} USDT
                </p>
              </div>
              <div className="bg-dark-300 p-3 rounded-lg">
                <p className="text-sm text-dark-100">BTC Bakiyesi</p>
                <p className="text-xl font-bold">
                  {typeof accountInfo === 'object' && accountInfo !== null && 'details' in accountInfo ? 
                    ((accountInfo as any).details?.find?.((d: any) => d.ccy === "BTC")?.availBal) || "0.00" : "0.00"} BTC
                </p>
              </div>
              <div className="bg-dark-300 p-3 rounded-lg">
                <p className="text-sm text-dark-100">ETH Bakiyesi</p>
                <p className="text-xl font-bold">
                  {typeof accountInfo === 'object' && accountInfo !== null && 'details' in accountInfo ? 
                    ((accountInfo as any).details?.find?.((d: any) => d.ccy === "ETH")?.availBal) || "0.00" : "0.00"} ETH
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard
            title="Aktif İşlemler"
            value={activeTrades}
            change={activeTrades > 0 ? 1 : 0}
            changeText="bugün yeni"
            icon={<LineChart className="h-5 w-5" />}
          />
          
          <StatCard
            title="Toplam Kar"
            value={`$${totalProfit.toFixed(2)}`}
            change="3.2%"
            changeText="geçen haftaya göre"
            icon={<ArrowRightLeft className="h-5 w-5" />}
          />
          
          <StatCard
            title="Tamamlanan İşlemler"
            value={totalCompletedTrades}
            change={5}
            changeText="bu hafta"
            icon={<Sliders className="h-5 w-5" />}
          />
          
          <StatCard
            title="Kazanç Oranı"
            value={`${winRate.toFixed(0)}%`}
            change="2%"
            changeText="geçen aya göre"
            icon={<BarChart4 className="h-5 w-5" />}
          />
        </div>

        {/* Active Smart Trades */}
        <div className="bg-dark-400 rounded-lg overflow-hidden mb-6">
          <div className="flex justify-between items-center p-4 border-b border-dark-300">
            <h2 className="text-lg font-semibold">Aktif Akıllı İşlemler</h2>
            <div className="flex items-center gap-2">
              {smartTrades.length > 0 && (
                <Button
                  variant="destructive"
                  size="sm"
                  className="bg-danger/20 hover:bg-danger/30 text-danger"
                  onClick={() => setIsCloseAllDialogOpen(true)}
                  disabled={isClosingAll}
                >
                  <CircleOff className="mr-1 h-4 w-4" />
                  Tümünü Kapat
                </Button>
              )}
              <Button
                variant="outline"
                size="sm"
                className="bg-dark-300 hover:bg-dark-200 text-white border-dark-300"
                onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/trades"] })}
              >
                <RefreshCw className="mr-1 h-4 w-4" />
                Yenile
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="p-6 text-center">İşlemler yükleniyor...</div>
          ) : smartTrades.length > 0 ? (
            smartTrades.map((trade) => (
              <SmartTradeCard key={trade.id} trade={trade} />
            ))
          ) : (
            <div className="p-6 text-center">
              <p className="mb-4">Aktif akıllı işlem bulunamadı.</p>
              <Button
                onClick={() => setIsCreateModalOpen(true)}
                className="bg-primary hover:bg-primary/90 text-white"
              >
                <Plus className="mr-2 h-4 w-4" />
                Akıllı İşlem Oluştur
              </Button>
            </div>
          )}
        </div>

        {/* Recently Completed Trades */}
        <div className="bg-dark-400 rounded-lg overflow-hidden">
          <div className="flex justify-between items-center p-4 border-b border-dark-300">
            <h2 className="text-lg font-semibold">Son Tamamlananlar</h2>
            <Button
              variant="link"
              className="text-primary text-sm p-0 h-auto"
              onClick={() => window.location.href = '/trade-history'}
            >
              Tümünü Gör
            </Button>
          </div>

          {isLoading ? (
            <div className="p-6 text-center">Tamamlanan işlemler yükleniyor...</div>
          ) : completedTrades.length > 0 ? (
            completedTrades.slice(0, 3).map((trade) => (
              <SmartTradeCard key={trade.id} trade={trade} isCompleted={true} />
            ))
          ) : (
            <div className="p-6 text-center">Tamamlanan işlem bulunamadı.</div>
          )}
        </div>
      </div>

      <CreateSmartTradeModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        accountInfo={accountInfo}
      />

      {/* Close All Dialog */}
      <Dialog open={isCloseAllDialogOpen} onOpenChange={setIsCloseAllDialogOpen}>
        <DialogContent className="bg-dark-400 border-dark-300">
          <DialogHeader>
            <DialogTitle>Tüm İşlemleri Kapat</DialogTitle>
            <DialogDescription className="text-dark-100">
              Aktif {smartTrades.length} adet akıllı işlemin tümünü kapatmak istediğinize emin misiniz?
              Bu işlem tüm pozisyonları piyasadan çıkış yapacak ve tüm emirleri iptal edecektir.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:gap-0 mt-4">
            <div className="flex-1 flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-warning" />
              <span className="text-xs text-warning">Bu işlem geri alınamaz!</span>
            </div>
            <div className="flex gap-2 ml-auto">
              <Button
                variant="outline"
                className="bg-dark-300 hover:bg-dark-200"
                onClick={() => setIsCloseAllDialogOpen(false)}
                disabled={isClosingAll}
              >
                İptal
              </Button>
              <Button
                variant="destructive"
                className="bg-danger hover:bg-danger/90"
                onClick={closeAllTrades}
                disabled={isClosingAll}
              >
                {isClosingAll ? "Kapatılıyor..." : "Tüm İşlemleri Kapat"}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageLayout>
  );
}
