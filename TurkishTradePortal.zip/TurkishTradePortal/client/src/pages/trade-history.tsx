import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Filter, Download } from "lucide-react";
import { PageLayout } from "@/components/layout/page-layout";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { TradesTable } from "@/components/trades/trades-table";
import { Bot, Trade } from "@shared/schema";

export default function TradeHistory() {
  const [tradingPair, setTradingPair] = useState<string>("all");
  const [tradeType, setTradeType] = useState<string>("all");
  const [dateRange, setDateRange] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState<string>("");

  // Fetch trades
  const { data: trades, isLoading: isLoadingTrades } = useQuery<Trade[]>({
    queryKey: ['/api/trades'],
  });

  // Fetch bots to get their names
  const { data: bots } = useQuery<Bot[]>({
    queryKey: ['/api/bots'],
  });

  // Filter trades based on selected filters
  const filteredTrades = trades?.filter(trade => {
    // Apply trading pair filter
    if (tradingPair !== "all" && trade.tradingPair !== tradingPair) {
      return false;
    }

    // Apply trade type filter
    if (tradeType !== "all" && trade.type !== tradeType) {
      return false;
    }

    // Apply date range filter
    if (dateRange !== "all") {
      const tradeDate = new Date(trade.openedAt);
      const now = new Date();
      const daysDiff = (now.getTime() - tradeDate.getTime()) / (1000 * 60 * 60 * 24);

      if (dateRange === "today" && daysDiff > 1) {
        return false;
      } else if (dateRange === "week" && daysDiff > 7) {
        return false;
      } else if (dateRange === "month" && daysDiff > 30) {
        return false;
      }
    }

    // Apply search term filter
    if (searchTerm) {
      const botName = bots?.find(b => b.id === trade.botId)?.name || "";
      const searchTermLower = searchTerm.toLowerCase();
      
      return (
        trade.tradingPair.toLowerCase().includes(searchTermLower) ||
        botName.toLowerCase().includes(searchTermLower)
      );
    }

    return true;
  });

  // Get unique trading pairs for filter
  const uniqueTradingPairs = Array.from(new Set(trades?.map(trade => trade.tradingPair) || []));

  return (
    <PageLayout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white mb-2">İşlem Geçmişi</h1>
          <p className="text-dark-100">Geçmiş işlem aktivitelerinizi görüntüleyin ve analiz edin</p>
        </div>

        {/* Filters */}
        <div className="bg-dark-400 rounded-lg p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 space-y-2">
              <label className="text-sm text-dark-100">İşlem Çifti</label>
              <Select
                value={tradingPair}
                onValueChange={setTradingPair}
              >
                <SelectTrigger className="bg-dark-300 border-dark-300 text-white">
                  <SelectValue placeholder="Tüm Çiftler" />
                </SelectTrigger>
                <SelectContent className="bg-dark-300 border-dark-300 text-white">
                  <SelectItem value="all">Tüm Çiftler</SelectItem>
                  {uniqueTradingPairs.map(pair => (
                    <SelectItem key={pair} value={pair}>{pair}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 space-y-2">
              <label className="text-sm text-dark-100">İşlem Tipi</label>
              <Select
                value={tradeType}
                onValueChange={setTradeType}
              >
                <SelectTrigger className="bg-dark-300 border-dark-300 text-white">
                  <SelectValue placeholder="Tüm Tipler" />
                </SelectTrigger>
                <SelectContent className="bg-dark-300 border-dark-300 text-white">
                  <SelectItem value="all">Tüm Tipler</SelectItem>
                  <SelectItem value="BUY">Alış</SelectItem>
                  <SelectItem value="SELL">Satış</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 space-y-2">
              <label className="text-sm text-dark-100">Tarih Aralığı</label>
              <Select
                value={dateRange}
                onValueChange={setDateRange}
              >
                <SelectTrigger className="bg-dark-300 border-dark-300 text-white">
                  <SelectValue placeholder="Tüm Zamanlar" />
                </SelectTrigger>
                <SelectContent className="bg-dark-300 border-dark-300 text-white">
                  <SelectItem value="all">Tüm Zamanlar</SelectItem>
                  <SelectItem value="today">Bugün</SelectItem>
                  <SelectItem value="week">Son 7 Gün</SelectItem>
                  <SelectItem value="month">Son 30 Gün</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 space-y-2">
              <label className="text-sm text-dark-100">Arama</label>
              <div className="relative">
                <Input
                  type="text"
                  placeholder="İşlem çiftleri, botlar ara..."
                  className="bg-dark-300 border-dark-300 text-white pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="absolute left-3 top-3 text-dark-100">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="11" cy="11" r="8"/>
                    <path d="m21 21-4.3-4.3"/>
                  </svg>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-between mt-4">
            <Button
              variant="outline"
              size="sm"
              className="text-dark-100 border-dark-300 bg-dark-300 hover:bg-dark-200"
            >
              <Filter className="mr-2 h-4 w-4" />
              Daha Fazla Filtre
            </Button>

            <Button
              variant="outline"
              size="sm"
              className="text-dark-100 border-dark-300 bg-dark-300 hover:bg-dark-200"
            >
              <Download className="mr-2 h-4 w-4" />
              CSV Olarak Dışa Aktar
            </Button>
          </div>
        </div>

        {/* Trades Table */}
        <div className="bg-dark-400 rounded-lg overflow-hidden">
          <div className="p-4 border-b border-dark-300">
            <h2 className="text-lg font-semibold">İşlem Geçmişi</h2>
          </div>
          
          <TradesTable
            trades={filteredTrades || []}
            bots={bots || []}
            isLoading={isLoadingTrades}
          />
        </div>
      </div>
    </PageLayout>
  );
}
