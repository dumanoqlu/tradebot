import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Statik dosyaları sunmak için
app.use(express.static('public'));

// Ana dizinde hangi dosyaların olduğunu kontrol et
app.get('/api/files', (req, res) => {
  const rootDir = path.join(__dirname, 'public');
  
  try {
    if (!fs.existsSync(rootDir)) {
      return res.json({ 
        error: true, 
        message: 'Public klasörü bulunamadı. Lütfen dosyalarınızı public klasörüne yükleyin.' 
      });
    }
    
    const files = fs.readdirSync(rootDir);
    res.json({ files });
  } catch (error) {
    res.status(500).json({ error: true, message: error.message });
  }
});

// Kök dizinde index.html'i kontrol et
app.get('/', (req, res) => {
  const indexPath = path.join(__dirname, 'public', 'index.html');
  
  if (fs.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    res.send(`
      <!DOCTYPE html>
      <html lang="tr">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TradeBotMaster - Kurulum Rehberi</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
          }
          h1 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
          }
          .error {
            color: #e74c3c;
            background-color: #fadbd8;
            padding: 10px;
            border-radius: 5px;
            margin: 15px 0;
          }
          .success {
            color: #27ae60;
            background-color: #d4efdf;
            padding: 10px;
            border-radius: 5px;
            margin: 15px 0;
          }
          code {
            background-color: #f7f7f7;
            padding: 3px 5px;
            border-radius: 3px;
          }
          .step {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            border-left: 4px solid #3498db;
          }
        </style>
      </head>
      <body>
        <h1>TradeBotMaster - Replit Kurulum Rehberi</h1>
        
        <div class="error">
          <strong>Dikkat:</strong> Web siteniz henüz düzgün şekilde kurulmamış görünüyor. Aşağıdaki adımları takip edin:
        </div>
        
        <div class="step">
          <h3>Adım 1: Web Sitenizi Yükleyin</h3>
          <p>Replit'in sol tarafındaki dosya gezgininde, dosyalarınızı "public" klasörüne yüklemeniz gerekiyor.</p>
          <ol>
            <li>Sol tarafta, "Files" sekmesine tıklayın</li>
            <li>Sağ tıklayıp "New Folder" seçeneğini seçin ve "public" adında bir klasör oluşturun</li>
            <li>Zip dosyanızı açın ve içindeki tüm dosyaları bu "public" klasörüne yükleyin</li>
          </ol>
        </div>
        
        <div class="step">
          <h3>Adım 2: Web Sitenizi Çalıştırın</h3>
          <p>Dosyalarınızı yükledikten sonra:</p>
          <ol>
            <li>Üst menüdeki "Run" butonuna tıklayın</li>
            <li>Sunucu başlatıldıktan sonra, web siteniz https://[kullanıcı-adı].[proje-adı].repl.co adresinde yayınlanacaktır</li>
          </ol>
        </div>
        
        <div class="step">
          <h3>Adım 3: Sorun Giderme</h3>
          <p>Eğer siteniz PHP, Node.js, Python veya başka bir arka uç teknolojisini kullanıyorsa, README.md dosyasındaki talimatları takip edin.</p>
          <p>Sunucu dosyalarınızı kontrol etmek için <a href="/api/files">buraya tıklayabilirsiniz</a>.</p>
        </div>
      </body>
      </html>
    `);
  }
});

// Sunucuyu başlat
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server is running on http://0.0.0.0:${PORT}`);
  console.log(`Web siteniz başarıyla çalıştırıldı! Dosyalarınızı "public" klasörüne yükleyin.`);
});
