import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { TRADING_PAIRS, ORDER_UNITS } from "@/lib/constants";
import { Slider } from "@/components/ui/slider";
import { ChevronDown, ChevronUp, Trash2, Wallet, RefreshCw } from "lucide-react";
import { calculateTakeProfitValues, calculateStopLoss } from "@/lib/binance-api";
import { TakeProfitLevel } from "@shared/schema";

// Schema for smart trade form
const createSmartTradeSchema = z.object({
  tradingPair: z.string().min(1, "Trading pair is required"),
  orderType: z.enum(["MARKET", "LIMIT"]),
  side: z.enum(["BUY", "SELL"]),
  amount: z.number().min(0.1, "Amount must be at least 0.1"),
  amountUnit: z.string().min(1, "Amount unit is required"),
  limitPrice: z.number().optional(),
  leverage: z.number().min(1, "Leverage must be at least 1").default(1),
  stopLoss: z.number().min(0.1, "Stop loss must be at least 0.1%"),
});

type FormValues = z.infer<typeof createSmartTradeSchema> & {
  takeProfitLevels: TakeProfitLevel[];
};

interface CreateSmartTradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  accountInfo?: any;
}

export function CreateSmartTradeModal({ isOpen, onClose, accountInfo }: CreateSmartTradeModalProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("market");
  const [takeProfitLevels, setTakeProfitLevels] = useState<TakeProfitLevel[]>([
    { target: 1.5, volume: 25 },
    { target: 2.5, volume: 25 },
    { target: 4.0, volume: 25 },
    { target: 6.0, volume: 25 },
  ]);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Setup form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(createSmartTradeSchema),
    defaultValues: {
      tradingPair: "BTC/USDT",
      orderType: "MARKET",
      side: "BUY",
      amount: 100,
      amountUnit: "USDT",
      leverage: 1,
      stopLoss: 3.0,
    },
  });

  // Update order type when tab changes
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    form.setValue("orderType", value === "market" ? "MARKET" : "LIMIT");
  };

  const onSubmit = async (data: FormValues) => {
    try {
      // Validate take profit levels
      const totalVolume = takeProfitLevels.reduce((sum, level) => sum + level.volume, 0);
      if (Math.abs(totalVolume - 100) > 0.01) {
        throw new Error("Kar Al seviyelerinin toplam hacmi %100 olmalıdır");
      }

      // İşlem verilerini hazırla
      // Gerçek piyasa fiyatını kullanalım
      let marketPrice = 0;
      try {
        // Önce modal'da hesaplanan fiyatı kullanalım
        marketPrice = estimatedValues.entryPrice;
        
        // Gerçek veriyi almak için buraya OKX API çağrısı eklemek daha iyi olur
        // Şimdilik her işlemde en son hesaplanan fiyatı kullanıyoruz
        console.log(`Using current market price: ${marketPrice} for ${data.tradingPair}`);
      } catch (err) {
        console.error("Piyasa fiyatı alınamadı, tahmini değer kullanılıyor:", err);
      }
      
      // Zaten yukarıda tanımlanmış olduğu için eski fonksiyonu kaldırıyoruz
      // estimatedValues değişkeni zaten tanımlanmış durumda
      
      const tradeData = {
        botId: 1, // Schema'ya göre botId mutlaka bir sayı olmalı
        tradingPair: data.tradingPair.replace("/", ""),
        type: data.side, // side yerine type kullanılmalı, API şemasında type "BUY" veya "SELL" olarak geçiyor
        price: data.orderType === "LIMIT" ? data.limitPrice : marketPrice,
        amount: data.amount,
        status: "OPEN",
        leverage: data.leverage || 1,
        // Take profit ve stop loss değerlerini daha sonra kullanmak için ekstra verileri de gönderelim
        takeProfitLevels: takeProfitLevels,
        stopLoss: data.stopLoss,
      };

      console.log("İşlem verileri (server'a gönderilecek):", tradeData);
      
      // İşlemi sunucuya gönder
      const response = await apiRequest('POST', '/api/trades', tradeData);

      toast({
        title: "Akıllı İşlem Oluşturuldu",
        description: `${data.tradingPair} için ${data.side === "BUY" ? "ALIM" : "SATIM"} emri oluşturuldu`,
      });
      
      // Close the modal
      onClose();
      
      // Refresh trades data
      queryClient.invalidateQueries({ queryKey: ['/api/trades'] });
    } catch (error) {
      console.error("Akıllı işlem oluşturma hatası:", error);
      toast({
        title: "Hata",
        description: error instanceof Error ? error.message : "Akıllı işlem oluşturulamadı.",
        variant: "destructive",
      });
    }
  };

  const addTakeProfitLevel = () => {
    if (takeProfitLevels.length >= 10) {
      toast({
        title: "Maksimum Seviyeye Ulaşıldı",
        description: "En fazla 10 adet kar al seviyesi ekleyebilirsiniz.",
        variant: "destructive",
      });
      return;
    }

    const lastLevel = takeProfitLevels[takeProfitLevels.length - 1];
    const newTarget = lastLevel ? lastLevel.target * 1.5 : 1.5;
    
    setTakeProfitLevels([
      ...takeProfitLevels,
      { target: newTarget, volume: 10 }
    ]);
  };

  const removeTakeProfitLevel = (index: number) => {
    if (takeProfitLevels.length <= 1) {
      toast({
        title: "Minimum Seviye Gerekli",
        description: "En az bir kar al seviyesi belirlemelisiniz.",
        variant: "destructive",
      });
      return;
    }

    setTakeProfitLevels(takeProfitLevels.filter((_, i) => i !== index));
  };

  const updateTakeProfitLevel = (index: number, field: keyof TakeProfitLevel, value: number) => {
    const updatedLevels = [...takeProfitLevels];
    updatedLevels[index] = { ...updatedLevels[index], [field]: value };
    setTakeProfitLevels(updatedLevels);
  };

  // State for current market prices
  const [marketPrices, setMarketPrices] = useState<Record<string, number>>({
    "BTC/USDT": 0,
    "ETH/USDT": 0,
    "SOL/USDT": 0,
    "DOGE/USDT": 0
  });

  // Manually fetch price for the selected trading pair
  const fetchPrice = async (pair: string) => {
    if (!pair) return;
    
    try {
      const formattedPair = pair.replace("/", "");
      const response = await fetch(`/api/okx/price/${formattedPair}`);
      if (response.ok) {
        const data = await response.json();
        setMarketPrices(prev => ({
          ...prev,
          [pair]: data.price
        }));
        console.log(`Fetched price for ${pair}: ${data.price}`);
      }
    } catch (error) {
      console.error(`Error fetching price for ${pair}:`, error);
    }
  };

  // Fetch price when the trading pair changes
  const tradingPair = form.watch("tradingPair");
  if (tradingPair && !marketPrices[tradingPair]) {
    fetchPrice(tradingPair);
  }

  // Calculate estimated price using real market prices
  const calculateEstimatedValues = () => {
    const values = form.getValues();
    // Use real market prices or fallback to recent estimates if not available
    const basePrice = marketPrices[values.tradingPair] || 
                      (values.tradingPair === "BTC/USDT" ? 96000 : 
                      values.tradingPair === "ETH/USDT" ? 3100 :
                      values.tradingPair === "SOL/USDT" ? 145 : 100);
    
    // Calculate TP values
    const takeProfitValues = calculateTakeProfitValues(
      basePrice,
      values.amount,
      takeProfitLevels
    );
    
    // Calculate SL values
    const stopLossValues = calculateStopLoss(
      basePrice,
      values.amount,
      values.stopLoss
    );
    
    // Return summary
    return {
      entryPrice: basePrice,
      takeProfitValues,
      stopLossValues
    };
  };

  const estimatedValues = calculateEstimatedValues();

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-dark-400 text-white border-dark-300 max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            Yeni Akıllı İşlem Oluştur
          </DialogTitle>
        </DialogHeader>
        
        {/* OKX Account Info */}
        {accountInfo && (
          <div className="bg-dark-300 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Wallet className="text-primary mr-2 h-5 w-5" />
                <h3 className="text-lg font-medium">OKX Demo Hesap Bakiyesi</h3>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  queryClient.invalidateQueries({ queryKey: ['/api/okx/account'] });
                  toast({
                    title: "Bakiye Güncellendi",
                    description: "Hesap bakiyesi bilgileri güncellendi.",
                  });
                }}
                className="bg-dark-300 hover:bg-dark-200 text-white"
              >
                <RefreshCw className="h-4 w-4 mr-1" />
                Yenile
              </Button>
            </div>
            <div className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-dark-400 p-3 rounded-lg">
                <p className="text-sm text-dark-100">Toplam Bakiye</p>
                <p className="text-xl font-bold">${accountInfo.totalEq || accountInfo.rawData?.data?.[0]?.adjEq || "0.00"}</p>
              </div>
              <div className="bg-dark-400 p-3 rounded-lg">
                <p className="text-sm text-dark-100">USDT Bakiyesi</p>
                <p className="text-xl font-bold">
                  {accountInfo.availableEq || accountInfo.rawData?.data?.[0]?.details?.find((d: any) => d.ccy === "USDT")?.availBal || "0.00"} USDT
                </p>
              </div>
              <div className="bg-dark-400 p-3 rounded-lg">
                <p className="text-sm text-dark-100">BTC Bakiyesi</p>
                <p className="text-xl font-bold">
                  {accountInfo.rawData?.data?.[0]?.details?.find((d: any) => d.ccy === "BTC")?.availBal || "0.00"} BTC
                </p>
              </div>
            </div>
          </div>
        )}

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Order Type Tabs */}
            <Tabs value={activeTab} onValueChange={handleTabChange}>
              <TabsList className="bg-dark-300 border-dark-300">
                <TabsTrigger value="market" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                  Market
                </TabsTrigger>
                <TabsTrigger value="limit" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                  Limit
                </TabsTrigger>
              </TabsList>

              <TabsContent value="market" className="pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="tradingPair"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Trading Pair</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="bg-dark-300 border-dark-200 text-white">
                              <SelectValue placeholder="Select trading pair" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-dark-300 border-dark-200 text-white">
                            {TRADING_PAIRS.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="side"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Side</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="bg-dark-300 border-dark-200 text-white">
                              <SelectValue placeholder="Select order side" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-dark-300 border-dark-200 text-white">
                            <SelectItem value="BUY" className="text-secondary">Buy</SelectItem>
                            <SelectItem value="SELL" className="text-danger">Sell</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                </div>
              </TabsContent>

              <TabsContent value="limit" className="pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <FormField
                    control={form.control}
                    name="tradingPair"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Trading Pair</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="bg-dark-300 border-dark-200 text-white">
                              <SelectValue placeholder="Select trading pair" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-dark-300 border-dark-200 text-white">
                            {TRADING_PAIRS.map((pair) => (
                              <SelectItem key={pair} value={pair}>
                                {pair}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="side"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Side</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger className="bg-dark-300 border-dark-200 text-white">
                              <SelectValue placeholder="Select order side" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-dark-300 border-dark-200 text-white">
                            <SelectItem value="BUY" className="text-secondary">Buy</SelectItem>
                            <SelectItem value="SELL" className="text-danger">Sell</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="limitPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Limit Price</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          className="bg-dark-300 border-dark-200 text-white"
                          placeholder={`Enter limit price (e.g. ${estimatedValues.entryPrice})`}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </TabsContent>
            </Tabs>

            {/* Amount Input */}
            <div>
              <h3 className="text-lg font-medium mb-4">Order Size</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount</FormLabel>
                      <div className="relative">
                        <FormControl>
                          <Input
                            type="number"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                            className="bg-dark-300 border-dark-200 text-white pr-20"
                            placeholder="e.g. 0.01 BTC or 100 USDT"
                          />
                        </FormControl>
                        <FormField
                          control={form.control}
                          name="amountUnit"
                          render={({ field: unitField }) => (
                            <Select
                              onValueChange={unitField.onChange}
                              defaultValue={unitField.value}
                            >
                              <FormControl>
                                <SelectTrigger className="absolute right-0 top-0 h-full w-20 bg-dark-300 border-l border-dark-200 rounded-r-lg px-3 text-white">
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-dark-300 border-dark-200 text-white">
                                {ORDER_UNITS.map((unit) => (
                                  <SelectItem key={unit} value={unit}>
                                    {unit}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          )}
                        />
                      </div>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="leverage"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between">
                        <FormLabel>Leverage (x{field.value})</FormLabel>
                        <Button 
                          type="button" 
                          size="sm" 
                          variant="outline" 
                          className="h-8 px-2 bg-primary text-white hover:bg-primary/80"
                          onClick={() => {
                            // Burada kaldıraç değeri kaydedilecek
                            // Örneğin OKX API'sine kaldıraç değişikliğini gönderebilirsiniz
                            toast({
                              title: "Kaldıraç Kaydedildi",
                              description: `Kaldıraç değeri ${field.value}x olarak ayarlandı`,
                            });
                          }}
                        >
                          Kaldıracı Kaydet
                        </Button>
                      </div>
                      <FormControl>
                        <Slider
                          value={[field.value]}
                          min={1}
                          max={100}
                          step={1}
                          onValueChange={(value) => field.onChange(value[0])}
                          className="pt-2"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {/* Take Profit Levels */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-lg font-medium">Take Profit Levels</h3>
                <Button
                  type="button"
                  variant="link"
                  className="text-primary hover:underline focus:outline-none p-0 h-auto"
                  onClick={addTakeProfitLevel}
                >
                  + Add Level
                </Button>
              </div>

              <div className="bg-dark-300 rounded-lg p-4">
                <div className="grid grid-cols-12 gap-2 mb-2 text-dark-100 text-xs">
                  <div className="col-span-1">#</div>
                  <div className="col-span-4">Target (%)</div>
                  <div className="col-span-4">Volume (%)</div>
                  <div className="col-span-2">Est. Profit</div>
                  <div className="col-span-1"></div>
                </div>

                {takeProfitLevels.map((level, index) => (
                  <div key={index} className="grid grid-cols-12 gap-2 mb-2 items-center">
                    <div className="col-span-1 text-dark-100">{index + 1}</div>
                    <div className="col-span-4">
                      <Input
                        type="number"
                        value={level.target}
                        onChange={(e) =>
                          updateTakeProfitLevel(index, "target", parseFloat(e.target.value))
                        }
                        className="w-full bg-dark-400 border border-dark-200 rounded p-2 text-white focus:border-primary focus:outline-none"
                        step="0.1"
                        min="0.1"
                      />
                    </div>
                    <div className="col-span-4">
                      <Input
                        type="number"
                        value={level.volume}
                        onChange={(e) =>
                          updateTakeProfitLevel(index, "volume", parseFloat(e.target.value))
                        }
                        className="w-full bg-dark-400 border border-dark-200 rounded p-2 text-white focus:border-primary focus:outline-none"
                        step="1"
                        min="1"
                        max="100"
                      />
                    </div>
                    <div className="col-span-2 text-secondary text-sm">
                      <div className="flex flex-col">
                        <span>+${estimatedValues.takeProfitValues[index]?.profitForLevel.toFixed(2) || "0.00"}</span>
                        <span className="text-xs text-gray-400">${estimatedValues.takeProfitValues[index]?.price || "0.00"}</span>
                      </div>
                    </div>
                    <div className="col-span-1 text-center">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="text-dark-100 hover:text-danger focus:outline-none p-1 h-auto"
                        onClick={() => removeTakeProfitLevel(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Stop Loss */}
            <FormField
              control={form.control}
              name="stopLoss"
              render={({ field }) => (
                <FormItem>
                  <div className="flex justify-between">
                    <FormLabel>Stop Loss (%)</FormLabel>
                    <div className="text-danger text-sm flex flex-col items-end">
                      <span>Est. Loss: -${estimatedValues.stopLossValues.potentialLoss.toFixed(2)}</span>
                      <span className="text-xs text-gray-400">Price: ${estimatedValues.stopLossValues.price || "0.00"}</span>
                    </div>
                  </div>
                  <FormControl>
                    <Input
                      type="number"
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                      className="bg-dark-300 border-dark-200 text-white"
                      placeholder="e.g. 5"
                      step="0.1"
                      min="0.1"
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            {/* Advanced Settings Toggle */}
            <div>
              <div className="flex items-center mb-4">
                <h3 className="text-lg font-medium">Advanced Settings</h3>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="ml-2 text-dark-100 hover:text-white focus:outline-none p-1 h-auto"
                  onClick={() => setShowAdvanced(!showAdvanced)}
                >
                  {showAdvanced ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </Button>
              </div>

              {showAdvanced && (
                <div className="space-y-4 bg-dark-300 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-dark-100">Trailing Stop Loss</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" />
                      <div className="w-11 h-6 bg-dark-400 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-dark-100">DCA (Dollar Cost Averaging)</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" />
                      <div className="w-11 h-6 bg-dark-400 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-dark-100">Auto Close Position</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" />
                      <div className="w-11 h-6 bg-dark-400 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                  </div>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                className="bg-dark-300 hover:bg-dark-200 text-white"
                onClick={onClose}
              >
                İptal
              </Button>
              <Button type="submit" className="bg-primary hover:bg-primary/90 text-white">
                Akıllı İşlem Oluştur
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
