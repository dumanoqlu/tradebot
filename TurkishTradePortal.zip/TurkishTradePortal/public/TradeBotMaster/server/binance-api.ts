import { Signal } from "@shared/schema";
import axios from "axios";
import crypto from "crypto-js";

// Binance API kullanımı durduruldu ve sadece OKX API üzerinden işlemler yapılıyor.
// API için gerekli yapılar

/**
 * Real Binance API client implementation.
 */
export class BinanceApiClient {
  private apiKey: string;
  private apiSecret: string;
  private baseUrl: string = "https://api.binance.com"; // Gerçek Binance API
  private futuresUrl: string = "https://fapi.binance.com"; // Gerçek Binance Futures API
  private useSimulation: boolean = false; // Gerçek işlemler için simülasyon kapalı

  constructor(apiKey: string, apiSecret: string) {
    this.apiKey = apiKey;
    this.apiSecret = apiSecret;
  }

  /**
   * Generate signature for Binance API
   */
  private generateSignature(queryString: string): string {
    return crypto.HmacSHA256(queryString, this.apiSecret).toString(crypto.enc.Hex);
  }

  /**
   * Add authentication headers for Binance API
   */
  private getHeaders(): Record<string, string> {
    return {
      'X-MBX-APIKEY': this.apiKey,
      'Content-Type': 'application/json'
    };
  }

  /**
   * Make a signed request to Binance API
   */
  private async makeSignedRequest(
    method: string,
    endpoint: string,
    params: Record<string, any> = {},
    isSpot: boolean = true
  ) {
    const baseApiUrl = isSpot ? this.baseUrl : this.futuresUrl;
    const timestamp = Date.now();
    const queryParams = new URLSearchParams({ ...params, timestamp: timestamp.toString() });
    const queryString = queryParams.toString();
    const signature = this.generateSignature(queryString);
    
    const url = `${baseApiUrl}${endpoint}?${queryString}&signature=${signature}`;
    
    console.log(`Making signed ${method} request to ${endpoint}`);
    console.log(`API Key: ${this.apiKey.substring(0, 4)}...${this.apiKey.slice(-4)}`);
    
    try {
      const response = await axios({
        method,
        url,
        headers: this.getHeaders(),
        timeout: 15000 // 15 saniye timeout
      });
      
      console.log(`Successful response from ${endpoint}: Status ${response.status}`);
      return response.data;
    } catch (error: any) {
      console.error(`Error in Binance API call to ${endpoint}:`, error.message);
      
      // Axios hatası mı kontrol et
      if (axios.isAxiosError(error)) {
        if (error.response) {
          console.error(`API Error: ${error.response.status} ${error.response.statusText}`);
          console.error('Error data:', JSON.stringify(error.response.data));
          throw new Error(`Binance API error (${error.response.status}): ${JSON.stringify(error.response.data)}`);
        } else if (error.request) {
          console.error('No response received:', error.request);
          throw new Error(`Binance API connection error: No response received`);
        }
      }
      
      // Diğer hatalar
      throw error;
    }
  }

  /**
   * Make a public request to Binance API (no authentication required)
   */
  private async makePublicRequest(endpoint: string, params: Record<string, any> = {}, isSpot: boolean = true) {
    const baseApiUrl = isSpot ? this.baseUrl : this.futuresUrl;
    const queryParams = new URLSearchParams(params);
    const url = `${baseApiUrl}${endpoint}?${queryParams.toString()}`;
    
    console.log(`Making public request to ${endpoint}`);
    
    try {
      const response = await axios.get(url, {
        timeout: 15000 // 15 saniye timeout
      });
      console.log(`Successful public response from ${endpoint}: Status ${response.status}`);
      return response.data;
    } catch (error: any) {
      console.error(`Error in Binance public API call to ${endpoint}:`, error.message);
      
      // Axios hatası mı kontrol et
      if (axios.isAxiosError(error)) {
        if (error.response) {
          console.error(`API Error: ${error.response.status} ${error.response.statusText}`);
          console.error('Error data:', JSON.stringify(error.response.data));
        } else if (error.request) {
          console.error('No response received:', error.request);
        }
      }
      
      throw error;
    }
  }

  /**
   * Test the API key connection to Binance
   */
  async testConnection(): Promise<boolean> {
    try {
      console.log("Testing Binance connection with API key:", this.apiKey.substring(0, 4) + '...' + this.apiKey.slice(-4));
      
      if (!this.apiKey || !this.apiSecret) {
        console.error("API key or secret is missing");
        throw new Error("API key and secret are required");
      }
      
      // İlk adım - Genel API durumunu kontrol et
      try {
        console.log("Step 1: Testing Binance public API (ping)");
        const statusResult = await this.makePublicRequest('/api/v3/ping', {});
        console.log("Binance system status check passed:", statusResult);
      } catch (error: any) {
        console.error("Binance system status check failed:", error.message);
        // Devam ediyoruz, çünkü bu API erişilebilirliğini kontrol ediyor, API anahtarını değil
      }
      
      // İkinci adım - API anahtarını kullanarak imzalı istek yap
      try {
        console.log("Step 2: Testing API key with timestamp endpoint");
        // Daha basit bir imzalı API isteği: /api/v3/time
        const timeResult = await this.makeSignedRequest('GET', '/api/v3/time', {});
        console.log("Timestamp request successful:", timeResult);
      } catch (error: any) {
        console.error("Timestamp request failed:", error.message);
        // Ana hesap kontrolüne geçmeden önce yine devam edelim
      }
      
      // Üçüncü adım - Gerçek hesap bilgisi iste
      console.log("Step 3: Testing account information API");
      const result = await this.makeSignedRequest('GET', '/api/v3/account', {});
      console.log("Binance connection test successful, account info received");
      
      return true;
    } catch (error: any) {
      console.error("Error in Binance connection test:", error.message);
      
      // Axios hatası ise daha fazla detay göster
      if (axios.isAxiosError(error)) {
        if (error.response) {
          console.error("API Response details:", {
            status: error.response.status,
            statusText: error.response.statusText,
            data: error.response.data
          });
          
          // İzin sorunu mu kontrol et
          if (error.response.status === 401 || error.response.status === 403) {
            console.error("Authentication failed. Please check API key permissions.");
          }
        } else if (error.request) {
          console.error("No response received from Binance API. Check your network connection.");
        }
      }
      
      return false;
    }
  }

  /**
   * Test the Futures API key connection to Binance
   */
  async testFuturesConnection(): Promise<boolean> {
    try {
      if (!this.apiKey || !this.apiSecret) {
        throw new Error("API key and secret are required");
      }
      
      // Futures API bağlantı testi
      await this.makeSignedRequest('GET', '/fapi/v2/account', {}, false);
      
      return true;
    } catch (error) {
      console.error("Error testing Binance Futures connection:", error);
      return false;
    }
  }

  /**
   * Get account information from Binance
   */
  async getAccountInfo() {
    try {
      // Artık OKX API kullanıldığı için simülasyon verileri kaldırıldı
      console.log("Getting real account info from Binance API");
      return await this.makeSignedRequest('GET', '/api/v3/account', {});
    } catch (error) {
      console.error("Error getting account info:", error);
      throw error;
    }
  }

  /**
   * Get futures account information from Binance
   */
  async getFuturesAccountInfo() {
    try {
      return await this.makeSignedRequest('GET', '/fapi/v2/account', {}, false);
    } catch (error) {
      console.error("Error getting futures account info:", error);
      throw error;
    }
  }

  /**
   * Get open orders from Binance
   */
  async getOpenOrders(symbol?: string) {
    try {
      const params: Record<string, any> = {};
      if (symbol) {
        params.symbol = formatSymbol(symbol);
      }
      
      return await this.makeSignedRequest('GET', '/api/v3/openOrders', params);
    } catch (error) {
      console.error("Error getting open orders:", error);
      throw error;
    }
  }

  /**
   * Get futures open orders from Binance
   */
  async getFuturesOpenOrders(symbol?: string) {
    try {
      const params: Record<string, any> = {};
      if (symbol) {
        params.symbol = formatSymbol(symbol);
      }
      
      return await this.makeSignedRequest('GET', '/fapi/v1/openOrders', params, false);
    } catch (error) {
      console.error("Error getting futures open orders:", error);
      throw error;
    }
  }

  /**
   * Create a new order on Binance
   */
  async createOrder(symbol: string, side: 'BUY' | 'SELL', quantity: number, price?: number) {
    try {
      const formattedSymbol = formatSymbol(symbol);
      
      const params: Record<string, any> = {
        symbol: formattedSymbol,
        side,
        quantity: quantity.toString()
      };
      
      if (price) {
        // Limit order
        params.type = 'LIMIT';
        params.timeInForce = 'GTC'; // Good Till Cancelled
        params.price = price.toString();
      } else {
        // Market order
        params.type = 'MARKET';
      }
      
      return await this.makeSignedRequest('POST', '/api/v3/order', params);
    } catch (error) {
      console.error("Error creating order:", error);
      throw error;
    }
  }

  /**
   * Create a new futures order on Binance
   */
  async createFuturesOrder(
    symbol: string, 
    side: 'BUY' | 'SELL', 
    quantity: number, 
    leverage: number = 1,
    price?: number,
    stopPrice?: number,
    reduceOnly: boolean = false
  ) {
    try {
      // Set leverage first
      await this.makeSignedRequest('POST', '/fapi/v1/leverage', {
        symbol: formatSymbol(symbol),
        leverage: leverage.toString()
      }, false);
      
      const formattedSymbol = formatSymbol(symbol);
      
      const params: Record<string, any> = {
        symbol: formattedSymbol,
        side,
        quantity: quantity.toString(),
        reduceOnly: reduceOnly
      };
      
      if (stopPrice) {
        // Stop-loss or take-profit order
        params.type = 'STOP_MARKET';
        params.stopPrice = stopPrice.toString();
        params.closePosition = true; // Close the entire position
      } else if (price) {
        // Limit order
        params.type = 'LIMIT';
        params.timeInForce = 'GTC'; // Good Till Cancelled
        params.price = price.toString();
      } else {
        // Market order
        params.type = 'MARKET';
      }
      
      return await this.makeSignedRequest('POST', '/fapi/v1/order', params, false);
    } catch (error) {
      console.error("Error creating futures order:", error);
      throw error;
    }
  }

  /**
   * Process a trading signal
   */
  async processSignal(signal: Signal, stopLoss: number, takeProfitLevels: { target: number, volume: number }[]) {
    try {
      const { pair, action, price } = signal;
      const formattedSymbol = formatSymbol(pair);
      const currentPrice = price || await this.getCurrentPrice(formattedSymbol);
      
      if (!currentPrice) {
        throw new Error(`Could not get current price for ${pair}`);
      }
      
      const isFutures = true; // Futures mu Spot mu?
      
      // Process order based on whether using futures or spot
      let entryOrderResult;
      if (isFutures) {
        // Futures order
        entryOrderResult = await this.createFuturesOrder(
          pair,
          action,
          1, // quantity - hesaplama yapılmalı
          10 // leverage - kullanıcı ayarı
        );
        
        // Stop-loss order
        const stopLossPrice = action === 'BUY' 
          ? currentPrice * (1 - stopLoss / 100) 
          : currentPrice * (1 + stopLoss / 100);
        
        await this.createFuturesOrder(
          pair,
          action === 'BUY' ? 'SELL' : 'BUY',
          1, // quantity - hesaplama yapılmalı
          10, // leverage - kullanıcı ayarı
          undefined, // price
          stopLossPrice, // stopPrice
          true // reduceOnly
        );
        
        // Take-profit orders
        for (const tp of takeProfitLevels) {
          const tpPrice = action === 'BUY' 
            ? currentPrice * (1 + tp.target / 100) 
            : currentPrice * (1 - tp.target / 100);
          
          await this.createFuturesOrder(
            pair,
            action === 'BUY' ? 'SELL' : 'BUY',
            1 * (tp.volume / 100), // quantity - hesaplama yapılmalı
            10, // leverage - kullanıcı ayarı
            tpPrice, // price
            undefined, // stopPrice
            true // reduceOnly
          );
        }
      } else {
        // Spot order
        entryOrderResult = await this.createOrder(
          pair,
          action,
          1, // quantity - hesaplama yapılmalı
          undefined // price - market order
        );
        
        // Spot için stop-loss ve take-profit uygulaması farklı
        // İkisi için de OCO (One Cancels Other) sipariş tipi kullanılabilir
      }
      
      return {
        success: true,
        signal,
        orders: {
          entry: entryOrderResult,
          stopLoss: {
            pair,
            side: action === 'BUY' ? 'SELL' : 'BUY',
            status: 'ACTIVE',
            price: action === 'BUY' 
              ? currentPrice * (1 - stopLoss / 100) 
              : currentPrice * (1 + stopLoss / 100)
          },
          takeProfits: takeProfitLevels.map(tp => ({
            pair,
            side: action === 'BUY' ? 'SELL' : 'BUY',
            status: 'ACTIVE',
            price: action === 'BUY' 
              ? currentPrice * (1 + tp.target / 100) 
              : currentPrice * (1 - tp.target / 100),
            volume: tp.volume
          }))
        }
      };
    } catch (error) {
      console.error("Error processing signal:", error);
      throw error;
    }
  }

  /**
   * Get current price for a trading pair
   */
  async getCurrentPrice(symbol: string): Promise<number> {
    try {
      // Artık gerçek veriler kullanılıyor
      console.log(`Getting real price data for ${symbol}`);
      const response = await this.makePublicRequest('/api/v3/ticker/price', { symbol });
      return parseFloat(response.price);
    } catch (error) {
      console.error("Error getting current price:", error);
      
      // Hata durumunda OKX API üzerinden fiyat almayı dene
      try {
        // Bu bir backend uygulaması olduğu için doğrudan okxApiClient'a erişim yok
        // Gerçekte burada OKX API'ye istek atmak için bir strateji uygulanabilir
        console.error("Failed to get price from Binance, fallback mechanism needed");
        throw error;
      } catch (okxError) {
        // Hata logla ve yeniden fırlat
        console.error("Failed to get price from both Binance and OKX:", okxError);
        throw error;
      }
    }
  }

  /**
   * Get last 24h trade history
   */
  async getTradingHistory(symbol?: string) {
    try {
      const params: Record<string, any> = {};
      if (symbol) {
        params.symbol = formatSymbol(symbol);
      }
      
      return await this.makeSignedRequest('GET', '/api/v3/myTrades', params);
    } catch (error) {
      console.error("Error getting trading history:", error);
      throw error;
    }
  }

  /**
   * Get all coins information
   */
  async getAllCoinsInfo() {
    try {
      return await this.makeSignedRequest('GET', '/sapi/v1/capital/config/getall', {});
    } catch (error) {
      console.error("Error getting all coins info:", error);
      throw error;
    }
  }
}

export function formatSymbol(pair: string): string {
  // Convert trading pairs like "BTC/USDT" to "BTCUSDT" format for Binance API
  return pair.replace('/', '');
}
