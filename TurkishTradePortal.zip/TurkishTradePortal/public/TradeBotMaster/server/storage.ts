import { 
  apiKeys, bots, trades,
  ApiKey, InsertApiKey,
  Bot, InsertBot, 
  Trade, InsertTrade,
  TakeProfitLevel
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // API Keys
  getApiKeys(): Promise<ApiKey[]>;
  getApiKey(id: number): Promise<ApiKey | undefined>;
  createApiKey(apiKey: InsertApiKey): Promise<ApiKey>;
  updateApiKey(id: number, apiKey: Partial<ApiKey>): Promise<ApiKey | undefined>;
  deleteApiKey(id: number): Promise<boolean>;

  // Bots
  getBots(): Promise<Bot[]>;
  getBot(id: number): Promise<Bot | undefined>;
  createBot(bot: InsertBot): Promise<Bot>;
  updateBot(id: number, bot: Partial<Bot>): Promise<Bot | undefined>;
  deleteBot(id: number): Promise<boolean>;

  // Trades
  getTrades(limit?: number): Promise<Trade[]>;
  getTradesForBot(botId: number): Promise<Trade[]>;
  getTrade(id: number): Promise<Trade | undefined>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTrade(id: number, trade: Partial<Trade>): Promise<Trade | undefined>;
}

export class MemStorage implements IStorage {
  private apiKeys: Map<number, ApiKey>;
  private bots: Map<number, Bot>;
  private trades: Map<number, Trade>;
  private currentApiKeyId: number;
  private currentBotId: number;
  private currentTradeId: number;

  constructor() {
    this.apiKeys = new Map();
    this.bots = new Map();
    this.trades = new Map();
    this.currentApiKeyId = 1;
    this.currentBotId = 1;
    this.currentTradeId = 1;

    // Add some initial demo data
    this.createBot({
      name: "BTC/USDT RSI Strategy",
      tradingPair: "BTC/USDT",
      signalSource: "tradingview",
      signalIdentifier: "RSI Indicator",
      signalSettings: "RSI(14) crosses below 30 for buy, above 70 for sell",
      baseOrderSize: 100,
      baseOrderUnit: "USDT",
      leverage: 1,
      isHedgeMode: false,
      takeProfitLevels: [
        { target: 1.5, volume: 25 },
        { target: 2.5, volume: 25 },
        { target: 4.0, volume: 25 },
        { target: 6.0, volume: 25 }
      ],
      stopLoss: 2.5,
      trailingStopLoss: false,
      enableDCA: false,
      maxActiveTrades: 3,
      cooldownPeriod: 30,
      isActive: true
    });

    this.createBot({
      name: "ETH/USDT MACD Cross",
      tradingPair: "ETH/USDT",
      signalSource: "tradingview",
      signalIdentifier: "MACD Indicator",
      signalSettings: "MACD line crosses signal line",
      baseOrderSize: 100,
      baseOrderUnit: "USDT",
      leverage: 1,
      isHedgeMode: false,
      takeProfitLevels: [
        { target: 1.8, volume: 33 },
        { target: 3.2, volume: 33 },
        { target: 5.5, volume: 34 }
      ],
      stopLoss: 3.2,
      trailingStopLoss: false,
      enableDCA: false,
      maxActiveTrades: 2,
      cooldownPeriod: 15,
      isActive: true
    });

    this.createBot({
      name: "SOL/USDT Bollinger Breakout",
      tradingPair: "SOL/USDT",
      signalSource: "twitter",
      signalIdentifier: "@CryptoSignals",
      signalSettings: "Twitter signal parsing from @CryptoSignals",
      baseOrderSize: 200,
      baseOrderUnit: "USDT",
      leverage: 2,
      isHedgeMode: false,
      takeProfitLevels: [
        { target: 2.0, volume: 25 },
        { target: 3.5, volume: 25 },
        { target: 5.0, volume: 25 },
        { target: 7.5, volume: 25 }
      ],
      stopLoss: 2.8,
      trailingStopLoss: true,
      enableDCA: false,
      maxActiveTrades: 3,
      cooldownPeriod: 30,
      isActive: true
    });

    this.createBot({
      name: "DOGE/USDT Momentum",
      tradingPair: "DOGE/USDT",
      signalSource: "tradingview",
      signalIdentifier: "Momentum Indicator",
      signalSettings: "Momentum crosses zero line",
      baseOrderSize: 150,
      baseOrderUnit: "USDT",
      leverage: 3,
      isHedgeMode: false,
      takeProfitLevels: [
        { target: 2.5, volume: 33 },
        { target: 4.0, volume: 33 },
        { target: 6.5, volume: 34 }
      ],
      stopLoss: 4.0,
      trailingStopLoss: false,
      enableDCA: true,
      maxActiveTrades: 2,
      cooldownPeriod: 20,
      isActive: false
    });

    // Add some sample trades
    const now = new Date();

    this.createTrade({
      botId: 2,
      tradingPair: "ETH/USDT",
      type: "BUY",
      price: 1785.34,
      amount: 0.25,
      profit: 42.18,
      status: "CLOSED",
      openedAt: new Date(now.getTime() - 4 * 60 * 60 * 1000) // 4 hours ago
    });

    this.createTrade({
      botId: 1,
      tradingPair: "BTC/USDT",
      type: "SELL",
      price: 29345.12,
      amount: 0.032,
      profit: 87.24,
      status: "CLOSED",
      openedAt: new Date(now.getTime() - 6 * 60 * 60 * 1000) // 6 hours ago
    });

    this.createTrade({
      botId: 3,
      tradingPair: "SOL/USDT",
      type: "BUY",
      price: 24.78,
      amount: 40,
      profit: 38.40,
      status: "CLOSED",
      openedAt: new Date(now.getTime() - 9 * 60 * 60 * 1000) // 9 hours ago
    });

    this.createTrade({
      botId: 2,
      tradingPair: "ETH/USDT",
      type: "BUY",
      price: 1765.22,
      amount: 0.15,
      profit: -12.75,
      status: "CLOSED",
      openedAt: new Date(now.getTime() - 25 * 60 * 60 * 1000) // 25 hours ago
    });

    this.createTrade({
      botId: 1,
      tradingPair: "BTC/USDT",
      type: "SELL",
      price: 29112.87,
      amount: 0.025,
      profit: 65.32,
      status: "CLOSED",
      openedAt: new Date(now.getTime() - 29 * 60 * 60 * 1000) // 29 hours ago
    });
  }

  // API Keys methods
  async getApiKeys(): Promise<ApiKey[]> {
    return Array.from(this.apiKeys.values());
  }

  async getApiKey(id: number): Promise<ApiKey | undefined> {
    return this.apiKeys.get(id);
  }

  async createApiKey(apiKey: InsertApiKey): Promise<ApiKey> {
    const id = this.currentApiKeyId++;
    const newApiKey: ApiKey = { ...apiKey, id };
    this.apiKeys.set(id, newApiKey);
    return newApiKey;
  }

  async updateApiKey(id: number, apiKey: Partial<ApiKey>): Promise<ApiKey | undefined> {
    const existingApiKey = this.apiKeys.get(id);
    if (!existingApiKey) return undefined;

    const updatedApiKey = { ...existingApiKey, ...apiKey };
    this.apiKeys.set(id, updatedApiKey);
    return updatedApiKey;
  }

  async deleteApiKey(id: number): Promise<boolean> {
    return this.apiKeys.delete(id);
  }

  // Bots methods
  async getBots(): Promise<Bot[]> {
    return Array.from(this.bots.values());
  }

  async getBot(id: number): Promise<Bot | undefined> {
    return this.bots.get(id);
  }

  async createBot(bot: InsertBot): Promise<Bot> {
    const id = this.currentBotId++;
    const createdAt = new Date();
    const newBot: Bot = { ...bot, id, createdAt };
    this.bots.set(id, newBot);
    return newBot;
  }

  async updateBot(id: number, bot: Partial<Bot>): Promise<Bot | undefined> {
    const existingBot = this.bots.get(id);
    if (!existingBot) return undefined;

    const updatedBot = { ...existingBot, ...bot };
    this.bots.set(id, updatedBot);
    return updatedBot;
  }

  async deleteBot(id: number): Promise<boolean> {
    return this.bots.delete(id);
  }

  // Trades methods
  async getTrades(limit: number = 100): Promise<Trade[]> {
    const trades = Array.from(this.trades.values());
    trades.sort((a, b) => b.openedAt.getTime() - a.openedAt.getTime());
    return trades.slice(0, limit);
  }

  async getTradesForBot(botId: number): Promise<Trade[]> {
    const trades = Array.from(this.trades.values())
      .filter(trade => trade.botId === botId);
    trades.sort((a, b) => b.openedAt.getTime() - a.openedAt.getTime());
    return trades;
  }

  async getTrade(id: number): Promise<Trade | undefined> {
    return this.trades.get(id);
  }

  async createTrade(trade: InsertTrade): Promise<Trade> {
    const id = this.currentTradeId++;
    const newTrade: Trade = { 
      ...trade, 
      id, 
      closedAt: trade.status === 'CLOSED' ? new Date() : null 
    };
    this.trades.set(id, newTrade);
    return newTrade;
  }

  async updateTrade(id: number, trade: Partial<Trade>): Promise<Trade | undefined> {
    const existingTrade = this.trades.get(id);
    if (!existingTrade) return undefined;

    const updatedTrade = { ...existingTrade, ...trade };
    
    // If status changed to CLOSED, set the closedAt time
    if (trade.status === 'CLOSED' && existingTrade.status !== 'CLOSED') {
      updatedTrade.closedAt = new Date();
    }
    
    this.trades.set(id, updatedTrade);
    return updatedTrade;
  }
}

export class DatabaseStorage implements IStorage {
  // API Keys methods
  async getApiKeys(): Promise<ApiKey[]> {
    return await db.select().from(apiKeys);
  }

  async getApiKey(id: number): Promise<ApiKey | undefined> {
    const [apiKey] = await db.select().from(apiKeys).where(eq(apiKeys.id, id));
    return apiKey || undefined;
  }

  async createApiKey(apiKey: InsertApiKey): Promise<ApiKey> {
    const [newApiKey] = await db.insert(apiKeys).values(apiKey).returning();
    return newApiKey;
  }

  async updateApiKey(id: number, apiKey: Partial<ApiKey>): Promise<ApiKey | undefined> {
    const [updatedApiKey] = await db
      .update(apiKeys)
      .set(apiKey)
      .where(eq(apiKeys.id, id))
      .returning();
    return updatedApiKey || undefined;
  }

  async deleteApiKey(id: number): Promise<boolean> {
    const result = await db.delete(apiKeys).where(eq(apiKeys.id, id));
    return result.rowCount > 0;
  }

  // Bots methods
  async getBots(): Promise<Bot[]> {
    return await db.select().from(bots);
  }

  async getBot(id: number): Promise<Bot | undefined> {
    const [bot] = await db.select().from(bots).where(eq(bots.id, id));
    return bot || undefined;
  }

  async createBot(bot: InsertBot): Promise<Bot> {
    const [newBot] = await db.insert(bots).values(bot).returning();
    return newBot;
  }

  async updateBot(id: number, bot: Partial<Bot>): Promise<Bot | undefined> {
    const [updatedBot] = await db
      .update(bots)
      .set(bot)
      .where(eq(bots.id, id))
      .returning();
    return updatedBot || undefined;
  }

  async deleteBot(id: number): Promise<boolean> {
    const result = await db.delete(bots).where(eq(bots.id, id));
    return result.rowCount > 0;
  }

  // Trades methods
  async getTrades(limit: number = 100): Promise<Trade[]> {
    return await db.select().from(trades).limit(limit).orderBy(desc(trades.openedAt));
  }

  async getTradesForBot(botId: number): Promise<Trade[]> {
    return await db
      .select()
      .from(trades)
      .where(eq(trades.botId, botId))
      .orderBy(desc(trades.openedAt));
  }

  async getTrade(id: number): Promise<Trade | undefined> {
    const [trade] = await db.select().from(trades).where(eq(trades.id, id));
    return trade || undefined;
  }

  async createTrade(trade: InsertTrade): Promise<Trade> {
    const [newTrade] = await db.insert(trades).values(trade).returning();
    return newTrade;
  }

  async updateTrade(id: number, trade: Partial<Trade>): Promise<Trade | undefined> {
    // If status changed to CLOSED, set the closedAt time
    if (trade.status === 'CLOSED') {
      const [existingTrade] = await db.select().from(trades).where(eq(trades.id, id));
      if (existingTrade && existingTrade.status !== 'CLOSED') {
        trade.closedAt = new Date();
      }
    }
    
    const [updatedTrade] = await db
      .update(trades)
      .set(trade)
      .where(eq(trades.id, id))
      .returning();
    return updatedTrade || undefined;
  }
}

// MemStorage yerine DatabaseStorage kullan
export const storage = new DatabaseStorage();
