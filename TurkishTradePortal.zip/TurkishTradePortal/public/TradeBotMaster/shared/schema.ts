import { pgTable, text, serial, integer, boolean, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// API Key management
export const apiKeys = pgTable("api_keys", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default("OKX API"),
  apiKey: text("api_key").notNull(),
  apiSecret: text("api_secret").notNull(),
  passphrase: text("passphrase"), // OKX için gerekli ek alan
  isActive: boolean("is_active").default(true),
});

// İsim alanını opsiyonel yapalım
export const insertApiKeySchema = createInsertSchema(apiKeys)
  .omit({ id: true })
  .extend({
    name: z.string().default("OKX API").optional(),
    passphrase: z.string().min(1, "Passphrase zorunludur"), // OKX için passphrase alanını zorunlu yapalım
  });

// Signal Bot configuration
export const bots = pgTable("bots", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  tradingPair: text("trading_pair").notNull(),
  signalSource: text("signal_source").notNull(),
  signalIdentifier: text("signal_identifier").notNull(),
  signalSettings: text("signal_settings"),
  // Common settings
  totalFunds: real("total_funds").default(1000),
  isHedgeMode: boolean("is_hedge_mode").default(false),
  enableDCA: boolean("enable_dca").default(false),
  maxActiveTrades: integer("max_active_trades").default(1),
  cooldownPeriod: integer("cooldown_period").default(0), // in minutes
  isActive: boolean("is_active").default(true),
  // Long position settings
  longEnabled: boolean("long_enabled").default(true),
  longOrderSize: real("long_order_size").default(100),
  longOrderUnit: text("long_order_unit").default("USDT"),
  longLeverage: integer("long_leverage").default(1),
  longStopLoss: real("long_stop_loss").default(3.0),
  longTrailingStop: boolean("long_trailing_stop").default(false),
  longTrailingStopValue: real("long_trailing_stop_value").default(0.5),
  longTakeProfitLevels: jsonb("long_take_profit_levels").notNull(), // Array of {target: number, volume: number}
  // Short position settings
  shortEnabled: boolean("short_enabled").default(true),
  shortOrderSize: real("short_order_size").default(100),
  shortOrderUnit: text("short_order_unit").default("USDT"),
  shortLeverage: integer("short_leverage").default(1),
  shortStopLoss: real("short_stop_loss").default(3.0),
  shortTrailingStop: boolean("short_trailing_stop").default(false),
  shortTrailingStopValue: real("short_trailing_stop_value").default(0.5),
  shortTakeProfitLevels: jsonb("short_take_profit_levels").notNull(), // Array of {target: number, volume: number}
  // Backward compatibility for older bots
  baseOrderSize: real("base_order_size").default(100),
  baseOrderUnit: text("base_order_unit").default("USDT"),
  leverage: integer("leverage").default(1),
  takeProfitLevels: jsonb("take_profit_levels").notNull(), // Array of {target: number, volume: number}
  stopLoss: real("stop_loss").default(3.0),
  trailingStopLoss: boolean("trailing_stop_loss").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertBotSchema = createInsertSchema(bots).omit({
  id: true,
  createdAt: true
});

// Trades executed by bots
export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  botId: integer("bot_id").notNull(),
  tradingPair: text("trading_pair").notNull(),
  type: text("type").notNull(), // "BUY" or "SELL"
  price: real("price").notNull(),
  amount: real("amount").notNull(),
  leverage: real("leverage").default(1),
  profit: real("profit").default(0),
  status: text("status").notNull(), // "OPEN", "CLOSED", "CANCELLED"
  openedAt: timestamp("opened_at").defaultNow(),
  closedAt: timestamp("closed_at"),
  externalId: text("external_id"), // OKX API işlem ID'si
  notes: text("notes"), // Additional notes, like TradingView alert ID
});

export const insertTradeSchema = createInsertSchema(trades).omit({
  id: true,
  closedAt: true,
  openedAt: true
});

// Types
export type InsertApiKey = z.infer<typeof insertApiKeySchema>;
export type ApiKey = typeof apiKeys.$inferSelect;

export type InsertBot = z.infer<typeof insertBotSchema>;
export type Bot = typeof bots.$inferSelect;

export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type Trade = typeof trades.$inferSelect;

// Signal type for bot signal processing
export type Signal = {
  // Basic signal data
  pair: string;                // Trading pair (e.g., "BTCUSDT") 
  action: "BUY" | "SELL";      // Direction of the trade
  price?: number;              // Optional price for limit orders
  
  // TradingView webhook specific fields
  tradingview_alert_id?: string; // ID from TradingView alert
  secret?: string;              // Security token from webhook
  bot_id?: number | string;     // Bot ID from webhook (might come as string)
  timeframe?: string;           // Timeframe from TradingView
  
  // Order parameters
  orderSize?: number;           // Size of the order
  orderUnit?: string;           // Unit of the order (USDT, BTC, etc)
  leverage?: number;            // Leverage for the order
  stopLoss?: number;            // Stop loss percentage
  takeProfitLevels?: TakeProfitLevel[]; // Take profit levels
  
  // Alternative field names for compatibility
  trading_pair?: string;        // Alternative field name for pair
  
  // Extended webhook format with position data
  position?: {
    action?: string;            // Direction from TradingView (buy/sell)
    long?: {                    // Long position settings
      enabled?: boolean;
      size?: number;
      unit?: string;
      leverage?: number;
      stopLoss?: number;
      takeProfitLevels?: TakeProfitLevel[];
    };
    short?: {                   // Short position settings
      enabled?: boolean;
      size?: number;
      unit?: string;
      leverage?: number;
      stopLoss?: number;
      takeProfitLevels?: TakeProfitLevel[];
    };
  };
  
  // Additional data fields
  [key: string]: any;           // Allow for any additional fields
};

// TakeProfit level type
export type TakeProfitLevel = {
  target: number;  // percentage
  volume: number;  // percentage
};
