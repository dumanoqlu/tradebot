import crypto from 'crypto';
import { Signal, TakeProfitLevel } from '../shared/schema';

/**
 * OKX API client implementation for demo account.
 */
export class OkxApiClient {
  private apiKey: string;
  private apiSecret: string;
  private passphrase: string;
  private baseUrl: string = "https://www.okx.com"; // OKX API ana URL'si
  private demoMode: boolean = true; // Demo hesap modu

  constructor(apiKey: string, apiSecret: string, passphrase: string) {
    this.apiKey = apiKey;
    this.apiSecret = apiSecret;
    this.passphrase = passphrase;
    
    // Demo modu aktifse, API endpoint'ini değiştir
    if (this.demoMode) {
      this.baseUrl = "https://www.okx.com"; // Demo API aynı URL'yi kullanıyor ancak header'da demo=1 belirtiliyor
      console.log("OKX API Demo modu aktif - işlemler gerçek hesabı etkilemeyecek");
    } else {
      console.log("OKX API Gerçek mod aktif - DİKKAT: işlemler gerçek hesabı etkileyecek");
    }
  }

  /**
   * Yeni imzalama yöntemi - OKX API v5 dokümantasyonuna tam uyumlu
   */
  private generateSignature(timestamp: string, method: string, requestPath: string, body: string = ""): string {
    // Adım 1: Pre-hash string oluştur: timestamp + method + requestPath + body
    const preHash = timestamp + method + requestPath + body;
    
    // Adım 2: HMAC-SHA256 ile imzala
    const signature = crypto.createHmac('sha256', this.apiSecret)
      .update(preHash)
      .digest('base64');
    
    return signature;
  }

  /**
   * Add authentication headers for OKX API
   */
  private getHeaders(method: string, requestPath: string, body: string = ""): Record<string, string> {
    const timestamp = new Date().toISOString();
    const signature = this.generateSignature(timestamp, method, requestPath, body);
    
    // Standart API headerları
    const headers: Record<string, string> = {
      'OK-ACCESS-KEY': this.apiKey,
      'OK-ACCESS-SIGN': signature,
      'OK-ACCESS-TIMESTAMP': timestamp,
      'OK-ACCESS-PASSPHRASE': this.passphrase,
      'Content-Type': 'application/json'
    };
    
    // Demo modu için ek header
    if (this.demoMode) {
      headers['x-simulated-trading'] = '1';
    }
    
    return headers;
  }

  /**
   * Genel HTTP istek fonksiyonu - tüm API istekleri için
   */
  private async makeRequest(method: string, endpoint: string, params: Record<string, any> = {}, isAccountEndpoint: boolean = true): Promise<any> {
    try {
      let url = this.baseUrl + endpoint;
      let body = '';
      let requestPath = endpoint;
      
      // GET istekleri için URL parametreleri
      if (method === 'GET' && Object.keys(params).length > 0) {
        const query = new URLSearchParams();
        Object.entries(params).forEach(([key, value]) => {
          query.append(key, String(value));
        });
        
        url += '?' + query.toString();
        requestPath += '?' + query.toString();
      }
      
      // POST istekleri için body
      if (method === 'POST') {
        body = JSON.stringify(params);
      }
      
      // Gerekli headerları oluştur
      const headers = this.getHeaders(method, requestPath, body);
      
      console.log(`[OKX-API] ${method} request to ${url}`);
      
      // Fetch API ile istek gönder
      const response = await fetch(url, {
        method,
        headers,
        body: method === 'POST' ? body : undefined
      });
      
      // API yanıtını kontrol et ve JSON olarak çevir
      if (!response.ok) {
        const errorText = await response.text();
        console.error(`[OKX-API] Error response (${response.status}): ${errorText}`);
        throw new Error(`OKX API error (${response.status}): ${errorText}`);
      }
      
      const data = await response.json();
      
      // Debug için yanıtı logla
      console.log(`[OKX-API] Response status: ${response.status}`);
      
      return data;
    } catch (error) {
      console.error('[OKX-API] Request failed:', error);
      throw error;
    }
  }

  /**
   * Test the API key connection to OKX
   */
  async testConnection(): Promise<boolean> {
    try {
      console.log("OKX bağlantı testi yapılıyor...");
      const response = await this.makeRequest('GET', '/api/v5/account/config', {}, true);
      console.log("OKX bağlantı testi yanıtı:", JSON.stringify(response, null, 2));
      // Başarı durumunu kontrol et - yetkilendirme sorunlarında hata fırlatılır zaten
      return response && response.code === '0';
    } catch (error) {
      console.error("OKX bağlantı testi sırasında hata:", error);
      return false;
    }
  }

  /**
   * Get account information from OKX
   */
  async getAccountInfo() {
    try {
      return await this.makeRequest('GET', '/api/v5/account/balance');
    } catch (error) {
      console.error("Error getting account info:", error);
      throw error;
    }
  }

  /**
   * Get trading account information from OKX
   */
  async getTradingAccount() {
    try {
      return await this.makeRequest('GET', '/api/v5/account/account-position-risk');
    } catch (error) {
      console.error("Error getting trading account:", error);
      throw error;
    }
  }

  /**
   * Get positions from OKX
   * @param instIdOrType BTC-USDT-SWAP gibi bir enstrüman ID'si veya SWAP, FUTURES, SPOT gibi bir işlem tipi
   */
  async getPositions(instIdOrType: string = 'SWAP') {
    try {
      const params: Record<string, any> = {};
      
      // Parametre SWAP, FUTURES, SPOT gibi bir enstrüman tipi mi yoksa BTC-USDT-SWAP gibi bir ID mi?
      if (['SWAP', 'FUTURES', 'SPOT', 'MARGIN', 'OPTION'].includes(instIdOrType)) {
        params.instType = instIdOrType;
      } else {
        params.instId = instIdOrType;
      }
      
      return await this.makeRequest('GET', '/api/v5/account/positions', params);
    } catch (error) {
      console.error("Error getting positions:", error);
      throw error;
    }
  }

  /**
   * Get open orders from OKX
   * @param instIdOrType BTC-USDT-SWAP gibi bir enstrüman ID'si veya SWAP, FUTURES, SPOT gibi bir işlem tipi
   */
  async getOpenOrders(instIdOrType: string = 'SWAP') {
    try {
      const params: Record<string, any> = {};
      
      // Parametre SWAP, FUTURES, SPOT gibi bir enstrüman tipi mi yoksa BTC-USDT-SWAP gibi bir ID mi?
      if (['SWAP', 'FUTURES', 'SPOT', 'MARGIN', 'OPTION'].includes(instIdOrType)) {
        params.instType = instIdOrType;
      } else {
        params.instId = instIdOrType;
      }
      
      return await this.makeRequest('GET', '/api/v5/trade/orders-pending', params);
    } catch (error) {
      console.error("Error getting open orders:", error);
      throw error;
    }
  }
  
  /**
   * Create separate take profit orders - dedicated function
   * 
   * This function creates multiple take profit orders for a position
   * after the main position has been opened
   * 
   * !!! KRİTİK FONKSİYON - DİKKAT !!!
   * Bu fonksiyon çoklu TP (Take Profit) seviyelerinin doğru çalışması için kritik öneme sahiptir.
   * Değişiklik yapmadan önce mutlaka IMPORTANT_NOTES.md dosyasını okuyun.
   * 
   * HATALAR VE ÇÖZÜMLER:
   * 1. "tag" parametresi OKX API'da hatalara neden oluyor, bu nedenle kaldırıldı.
   * 2. Her TP seviyesi için lot/hacim doğru şekilde hesaplanmalıdır.
   */
  async createTakeProfitOrders(
    instId: string,
    baseOrderSize: string,
    entryPrice: number,
    side: 'buy' | 'sell',
    posSide: 'long' | 'short' | 'net' = 'net',
    takeProfitLevels: { target: number, volume: number }[]
  ) {
    if (!takeProfitLevels || takeProfitLevels.length === 0) {
      console.log("[OKX-TP] Herhangi bir TP seviyesi belirtilmedi");
      return [];
    }
    
    console.log(`[OKX-TP] ${takeProfitLevels.length} TP seviyesi için ayrı emirler oluşturuluyor...`);
    const tpOrders = [];
    
    // Her TP seviyesi için ayrı bir emir oluştur
    for (const tp of takeProfitLevels) {
      try {
        // TP fiyatını hedef yüzdesine göre hesapla
        const tpPrice = side === 'buy' 
          ? entryPrice * (1 + tp.target / 100) 
          : entryPrice * (1 - tp.target / 100);
          
        // TP için ters yönde işlem yapılır
        const tpSide = side === 'buy' ? 'sell' : 'buy';
        
        // Bu TP seviyesi için işlem miktarını hesapla ve lot büyüklüğüne göre düzelt
        // Dinamik olarak enstrümanın lot büyüklüğünü al
        const lotSize = await this.getLotSize(instId);
        console.log(`[OKX-TP] ${instId} için dinamik lot büyüklüğü: ${lotSize}`);
        
        // Pozisyon büyüklüğünün bu TP seviyesine düşen yüzdesi
        let tpSizeRaw = parseFloat(baseOrderSize) * tp.volume / 100;
        console.log(`[OKX-TP] ${tp.target}% için hesaplanan ham boyut: ${tpSizeRaw}`);
        
        // Lot büyüklüğünün en yakın katına yuvarla (Math.floor ile aşağı yuvarla)
        const lotCount = Math.floor(tpSizeRaw / lotSize);
        const adjustedSize = lotCount > 0 ? lotCount * lotSize : lotSize;
        
        // Sonucu ondalik basamak hassasiyetini koruyarak formatla
        // (OKX 8 haneye kadar destekler, ancak lot büyüklüğünün katı olmalı)
        const tpSize = adjustedSize.toFixed(8);
        
        console.log(`[OKX-TP] ${tp.target}% için düzeltilmiş boyut: ${tpSize} (${lotCount} lot)`);
        
        // OKX API'nin TP emirleri formatlı yapılandır (algo order)
        console.log(`[OKX-TP] TP Level ${tp.target}%: Fiyat=${tpPrice.toFixed(2)}, Miktar=${tpSize}, Hacim=%${tp.volume}`);
        
        // Algo emir parametrelerini oluştur
        const algoParams = {
          instId,
          tdMode: 'cross',
          side: tpSide,
          posSide: posSide,
          ordType: 'conditional',
          sz: tpSize,
          tpTriggerPx: tpPrice.toFixed(2),
          tpTriggerPxType: 'last',
          tpOrdPx: '-1'
          // tag parametresi hataya sebep oluyor, kaldırıldı
        };
        
        // API'ye gönder (Take Profit emri)
        try {
          const tpResponse = await this.makeRequest('POST', '/api/v5/trade/order-algo', algoParams);
          console.log(`[OKX-TP] TP Level ${tp.target}% için algo-emir yanıtı:`, JSON.stringify(tpResponse, null, 2));
          tpOrders.push({
            target: tp.target, 
            volume: tp.volume, 
            price: tpPrice.toFixed(2),
            response: tpResponse
          });
        } catch (tpError) {
          console.error(`[OKX-TP] TP Level ${tp.target}% için algo-emir hatası:`, tpError);
          tpOrders.push({
            target: tp.target, 
            volume: tp.volume, 
            price: tpPrice.toFixed(2),
            error: tpError instanceof Error ? tpError.message : String(tpError)
          });
        }
      } catch (calcError) {
        console.error(`[OKX-TP] TP hesaplama hatası:`, calcError);
        tpOrders.push({
          target: tp.target, 
          volume: tp.volume,
          error: calcError instanceof Error ? calcError.message : String(calcError)
        });
      }
    }
    
    return tpOrders;
  }

  /**
   * Create a new order on OKX with improved error handling and lot size validation
   */
  async createOrder(
    instId: string,  // Trading pair (e.g., "BTC-USDT-SWAP")
    side: 'buy' | 'sell',
    posSide: 'long' | 'short' | 'net' = 'net',
    orderType: 'market' | 'limit' = 'market',
    size: string,    // Size (quantity)
    price?: string,  // Price (only for limit orders)
    stopLoss?: string,
    takeProfit?: string,
    reduceOnly: boolean = false,  // Set to true for orders that only reduce the position
    // Yeni parametreler - özel TP emirleri için
    takeProfitLevels?: {target: number, volume: number}[]
  ) {
    try {
      console.log(`[OKX-ORDER] Yeni emir oluşturuluyor: ${side} ${size} ${instId}`);
      
      // 1. Önce instId'nin doğru formatta olup olmadığını kontrol et
      let validInstId = instId;
      if (!validInstId.includes('-') || !validInstId.includes('SWAP')) {
        // Muhtemelen formatlanmamış bir trading pair geldi, formatla
        validInstId = formatPair(instId);
        console.log(`[OKX-ORDER] Trading pair format düzeltildi: ${instId} -> ${validInstId}`);
      }
      
      // 2. Önce lot büyüklüğünü al
      const lotSize = await this.getLotSize(validInstId);
      console.log(`[OKX-ORDER] ${validInstId} için lot büyüklüğü: ${lotSize}`);
      
      // 3. Boyutu lot büyüklüğünün katlarına yuvarla
      let adjustedSize = size;
      
      try {
        const sizeNum = parseFloat(size);
        if (!isNaN(sizeNum) && sizeNum > 0 && lotSize > 0) {
          // Lot sayısını hesapla ve tam sayıya yuvarla
          const lotCount = Math.floor(sizeNum / lotSize);
          // Minimum 1 lot kontrolü
          if (lotCount < 1) {
            console.log(`[OKX-ORDER] Uyarı: Boyut (${sizeNum}) lot büyüklüğünden (${lotSize}) küçük, minimum 1 lot kullanılacak`);
            adjustedSize = lotSize.toString();
          } else {
            const adjustedSizeNum = lotCount * lotSize;
            // Tam dönüşüm - string'e çevir ve ondalık sıfırları koru
            adjustedSize = adjustedSizeNum.toString();
            console.log(`[OKX-ORDER] Boyut lot büyüklüğüne göre düzeltildi: ${size} -> ${adjustedSize} (${lotCount} lot)`);
          }
        } else {
          console.warn(`[OKX-ORDER] Geçersiz boyut veya lot değeri: size=${size}, lotSize=${lotSize}`);
        }
      } catch (err) {
        console.error(`[OKX-ORDER] Boyut düzeltme hatası:`, err);
        // Hata durumunda orijinal boyutu kullan
      }
      
      // 4. Ana emir parametrelerini oluştur
      const params: Record<string, any> = {
        instId: validInstId, // Düzeltilmiş instId kullan
        tdMode: 'cross',      // cross or isolated
        side,
        posSide,
        ordType: orderType,
        sz: adjustedSize      // Düzeltilmiş boyut kullan
      };
      
      // Sadece pozisyon kapatma (TP/SL ekranında göstermek için)
      if (reduceOnly) {
        params.reduceOnly = 'true'; // OKX API string bekliyor
        console.log(`[OKX-ORDER] ReduceOnly ayarlandı: Bu emir sadece pozisyon kapatabilir`);
      }
      
      if (orderType === 'limit' && price) {
        params.px = price;
      }
      
      // Detaylı Stop Loss tanımla
      if (stopLoss) {
        params.slTriggerPx = stopLoss; // Tetikleme fiyatı
        params.slOrdPx = "-1";  // Market price (-1 değeri piyasa emrini ifade eder)
        console.log(`Stop Loss ayarlanıyor: trigger=${stopLoss}, order=market price`);
      }
      
      // Çoklu Take Profit seviyeleri işlem - YENİ YÖNTEM
      if (takeProfitLevels && takeProfitLevels.length > 0 && takeProfit) {
        // Ana TP seviyesi için takeProfit parametresini kullan
        params.tpTriggerPx = takeProfit; // Tetikleme fiyatı
        params.tpOrdPx = "-1";  // Market price (-1 değeri piyasa emrini ifade eder)
        console.log(`Ana Take Profit ayarlanıyor: trigger=${takeProfit}, order=market price`);
        
        // Çoklu TP seviyelerini OKX'in kabul ettiği formatta yapılandır
        // OKX API'si algoOrds parametresi ile çoklu TP/SL destekliyor
        try {
          // TP seviyeleri için algo emirleri oluştur
          const tpAlgoOrders = takeProfitLevels.map((tp, index) => {
            // TP fiyatını hedef yüzdesine göre hesapla
            const tpPrice = side === 'buy' ? 
                      parseFloat(takeProfit) * (1 + tp.target/100) : 
                      parseFloat(takeProfit) * (1 - tp.target/100);
                      
            // TP hacmini hesapla
            const tpSize = parseFloat(size) * (tp.volume / 100);
            
            // OKX algo emirleri formatında dönüş
            return {
              instId,
              tdMode: "cross",
              ccy: "USDT",
              side: side === 'buy' ? 'sell' : 'buy', // TP için ters taraf
              posSide,
              ordType: "conditional",
              sz: tpSize.toFixed(4),
              tpTriggerPx: tpPrice.toFixed(2),
              tpTriggerPxType: "last",
              tpOrdPx: "-1",  // Market price
            };
          });
          
          // Direkt olarak 'algoOrds' parametresi ile gönder
          // OKX'in belgeleri algo emirleri için algoOrds parametresini destekliyor
          if (tpAlgoOrders.length > 0) {
            // Ana emir parametrelerine algoOrds ekle
            params.algoOrds = JSON.stringify(tpAlgoOrders);
            console.log(`Çoklu TP seviyeleri için algoOrds parametresi eklendi: ${params.algoOrds}`);
          }
        } catch (tpError) {
          console.error(`Çoklu TP seviyeleri yapılandırılırken hata: ${tpError}`);
        }
        
        // Eski yöntem backup olarak tutuluyor
        try {
          // OKX API'nin beklediği özel formatları deneyelim (alternatif yöntem)
          params.tpSlType = "full";
          
          // TP seviyelerini hesapla
          const simplifiedTpLevels = takeProfitLevels.map(tp => ({
            tpPrice: side === 'buy' ? 
                      parseFloat(takeProfit) * (1 + tp.target/100) : 
                      parseFloat(takeProfit) * (1 - tp.target/100),
            tpAmount: parseFloat(size) * (tp.volume / 100)
          }));
          
          // Ayrı TP seviyeleri için ekstra veri gönderelim
          const tpLevelsData = simplifiedTpLevels.map((tpLevel, index) => ({
            tpOrdPx: "-1", // Market fiyatından kapat
            tpTriggerPx: tpLevel.tpPrice.toFixed(2),
            slTriggerPxType: "last",
            tpTriggerPxType: "last",
            // tag parametresi hataya sebep oluyor, kaldırıldı
          }));
          
          // Birden fazla TP için yeni değerler
          params.slTp = JSON.stringify({ // Direkt olarak string'e çevirilerek gönderiliyor
            type: "full",         // Tam pozisyon kapatma
            tpLevels: tpLevelsData // Tüm TP seviyeleri
          });
          
          console.log(`Alternatif TP parametresi slTp de eklendi: ${params.slTp}`);
        } catch (tpslError) {
          console.log(`Alternatif TP seviyeleri parametresi eklenemedi: ${tpslError}`);
        }
      }
      // Tekli Take Profit tanımla
      else if (takeProfit) {
        params.tpTriggerPx = takeProfit; // Tetikleme fiyatı
        params.tpOrdPx = "-1";  // Market price (-1 değeri piyasa emrini ifade eder)
        console.log(`Take Profit ayarlanıyor: trigger=${takeProfit}, order=market price`);
      }
      
      // Her zaman parametreleri logla (hata ayıklama için önemli)
      console.log("OKX işlem emri parametreleri:", JSON.stringify(params, null, 2));
      
      return await this.makeRequest('POST', '/api/v5/trade/order', params);
    } catch (error) {
      console.error("Error creating order:", error);
      throw error;
    }
  }

  /**
   * Cancel an order on OKX
   */
  async cancelOrder(instId: string, ordId: string) {
    try {
      return await this.makeRequest('POST', '/api/v5/trade/cancel-order', {
        instId,
        ordId
      });
    } catch (error) {
      console.error("Error canceling order:", error);
      throw error;
    }
  }
  
  /**
   * Close a position on OKX - IMPROVED VERSION
   */
  async closePosition(instId: string, posSide: 'long' | 'short' | 'net' = 'net', mgnMode: 'cross' | 'isolated' = 'cross') {
    try {
      console.log(`[CLOSE-POSITION-V2] OKX API'de pozisyon kapatma isteği başlatılıyor`);
      console.log(`[CLOSE-POSITION-V2] Parametreler: instrument=${instId}, posSide=${posSide}, mgnMode=${mgnMode}`);
      
      // 1. ADIM: İşlem tipini ve sembolü analiz et
      const category = instId.includes('-SWAP') ? 'SWAP' : 
                      instId.includes('-FUTURES') ? 'FUTURES' : 'SPOT';
      
      // Eğer instId'de tire yoksa ve SWAP/FUTURES yoksa formatlamamız gerekiyor
      const formattedInstId = instId.includes('-') ? instId : formatPair(instId);
      console.log(`[CLOSE-POSITION-V2] İşlem kategorisi: ${category}`);
      console.log(`[CLOSE-POSITION-V2] Format kontrol: ${instId} -> ${formattedInstId}`);
      
      // 2. ADIM: Önce tüm pozisyonları al - daha geniş bir arama yapalım
      console.log(`[CLOSE-POSITION-V2] Tüm ${category} pozisyonları getiriliyor...`);
      const allPositionsResponse = await this.makeRequest('GET', '/api/v5/account/positions', { instType: category });
      
      // Tüm pozisyonları logla - hata ayıklama için çok önemli
      console.log(`[CLOSE-POSITION-V2] Tüm pozisyonlar:`, JSON.stringify(allPositionsResponse, null, 2));
      
      // 3. ADIM: Eşleşen pozisyonları bul - çoklu eşleşme kriterleri
      const positions = allPositionsResponse?.data || [];
      let targetPosition = null;
      
      // Birkaç farklı eşleşme kriteri deneyelim - en spesifik olandan en geniş olana doğru
      if (positions.length > 0) {
        // Kriter 1: Önce tam eşleşme (instId VE posSide)
        targetPosition = positions.find((pos: any) => 
          pos.instId === formattedInstId && 
          pos.posSide === posSide && 
          parseFloat(pos.pos || '0') !== 0
        );
        
        // Kriter 2: Sadece instId eşleşmesi
        if (!targetPosition) {
          targetPosition = positions.find((pos: any) => 
            pos.instId === formattedInstId && 
            parseFloat(pos.pos || '0') !== 0
          );
        }
        
        // Kriter 3: Başka format versiyonlarını dene (ham sembol vs. formatlanmış sembol)
        if (!targetPosition && instId !== formattedInstId) {
          targetPosition = positions.find((pos: any) => 
            pos.instId.includes(instId.replace(/USDT$/, '')) && 
            parseFloat(pos.pos || '0') !== 0
          );
        }
        
        // Kriter 4: Son çare olarak, pozitif pozisyon değerine sahip herhangi bir pozisyon
        if (!targetPosition) {
          targetPosition = positions.find((pos: any) => parseFloat(pos.pos || '0') !== 0);
          if (targetPosition) {
            console.log(`[CLOSE-POSITION-V2] Kesin eşleşme bulunamadı, ama aktif bir pozisyon bulundu: ${targetPosition.instId}`);
          }
        }
      }
      
      // 4. ADIM: Eğer pozisyon bulunduysa, kapat
      if (targetPosition && parseFloat(targetPosition.pos || '0') !== 0) {
        const actualInstId = targetPosition.instId; // API'den dönen gerçek instId'yi kullan
        const actualPosSide = targetPosition.posSide;
        const posSize = Math.abs(parseFloat(targetPosition.pos || '0')).toString();
        const posAvgPx = targetPosition.avgPx || '0'; // Ortalama alım fiyatı
        
        // LONG pozisyonu kapatmak için SELL, SHORT pozisyonu kapatmak için BUY
        const actualSide = (actualPosSide === 'long' || 
                         (actualPosSide === 'net' && parseFloat(targetPosition.pos) > 0)) 
                         ? 'sell' : 'buy';
        
        console.log(`[CLOSE-POSITION-V2] BULUNDU! Pozisyon detayları:`);
        console.log(`[CLOSE-POSITION-V2] - İnstrüman: ${actualInstId}`);
        console.log(`[CLOSE-POSITION-V2] - Yön: ${actualPosSide}`);
        console.log(`[CLOSE-POSITION-V2] - Boyut: ${posSize}`);
        console.log(`[CLOSE-POSITION-V2] - Ortalama fiyat: ${posAvgPx}`);
        console.log(`[CLOSE-POSITION-V2] - Kapatma işlemi: ${actualSide}`);
        
        // OKX'in closePosition API'sini dene
        try {
          console.log(`[CLOSE-POSITION-V2] OKX /api/v5/trade/close-position API'si deneniyor...`);
          const params = {
            instId: actualInstId, // API'den dönen gerçek instId
            posSide: actualPosSide,
            mgnMode,
            closeAll: 'true' // String olarak true
          };
          
          console.log(`[CLOSE-POSITION-V2] closePosition parametreleri:`, JSON.stringify(params, null, 2));
          const closePositionResponse = await this.makeRequest('POST', '/api/v5/trade/close-position', params, true); // true: Demo mod
          console.log(`[CLOSE-POSITION-V2] closePosition yanıtı:`, JSON.stringify(closePositionResponse, null, 2));
          
          // Başarılı kapanış
          return {
            success: true,
            method: "close-position-api",
            response: closePositionResponse,
            message: "Pozisyon OKX API ile kapatıldı",
            details: {
              instId: actualInstId,
              posSide: actualPosSide,
              size: posSize,
              avgPrice: posAvgPx
            }
          };
        } catch (closeApiError: any) {
          console.log(`[CLOSE-POSITION-V2] closePosition API hatası:`, closeApiError.message);
          console.log(`[CLOSE-POSITION-V2] Alternatif yönteme geçiliyor...`);
          
          // Alternatif: Market emri ile kapat
          try {
            console.log(`[CLOSE-POSITION-V2] Alternatif: Market emri ile kapatma deneniyor...`);
            
            const marketOrderParams = {
              instId: actualInstId,
              tdMode: mgnMode,
              side: actualSide,
              posSide: actualPosSide,
              ordType: 'market',
              sz: posSize,
              reduceOnly: 'true',
              // tag parametresi hataya sebep oluyor, kaldırıldı
              clOrdId: `close-${Date.now()}`
            };
            
            console.log(`[CLOSE-POSITION-V2] Market emri parametreleri:`, JSON.stringify(marketOrderParams, null, 2));
            const marketOrderResponse = await this.makeRequest('POST', '/api/v5/trade/order', marketOrderParams, true); // true: Demo mod
            console.log(`[CLOSE-POSITION-V2] Market emri yanıtı:`, JSON.stringify(marketOrderResponse, null, 2));
            
            return {
              success: true,
              method: "market-order",
              response: marketOrderResponse,
              message: "Pozisyon market emri ile kapatıldı",
              details: {
                instId: actualInstId,
                posSide: actualPosSide,
                size: posSize,
                avgPrice: posAvgPx
              }
            };
          } catch (marketOrderError: any) {
            console.log(`[CLOSE-POSITION-V2] Market emri hatası:`, marketOrderError.message);
            throw new Error(`Pozisyon kapatma başarısız oldu: ${marketOrderError.message}`);
          }
        }
      } else {
        // 5. ADIM: Pozisyon bulunamadı, tamamlayıcı kontroller
        console.log(`[CLOSE-POSITION-V2] Eşleşen pozisyon bulunamadı. Ek kontroller yapılıyor...`);
        
        // Açık emirleri kontrol et
        try {
          console.log(`[CLOSE-POSITION-V2] Açık emirleri kontrol ediyorum...`);
          const openOrdersResponse = await this.makeRequest('GET', '/api/v5/trade/orders-pending', { instType: category }, true); // true: Demo mod
          const openOrders = openOrdersResponse?.data || [];
          
          console.log(`[CLOSE-POSITION-V2] Açık emirler:`, JSON.stringify(openOrders, null, 2));
          
          // İnstrüman için açık emirleri iptal et
          let cancelledOrders = [];
          for (const order of openOrders) {
            if (order.instId === formattedInstId || order.instId === instId) {
              console.log(`[CLOSE-POSITION-V2] Emir iptal ediliyor: ${order.ordId}, ${order.instId}`);
              try {
                const cancelResult = await this.makeRequest('POST', '/api/v5/trade/cancel-order', {
                  instId: order.instId,
                  ordId: order.ordId
                }, true); // true: Demo mod
                
                cancelledOrders.push({
                  orderId: order.ordId,
                  result: cancelResult
                });
                console.log(`[CLOSE-POSITION-V2] Emir iptal sonucu:`, cancelResult);
              } catch (cancelError) {
                console.error(`[CLOSE-POSITION-V2] Emir iptal hatası:`, cancelError);
              }
            }
          }
          
          return {
            success: true,
            method: "no-position-found",
            noPositionFound: true,
            cancelledOrders: cancelledOrders.length > 0 ? cancelledOrders : undefined,
            message: `Kapatılacak pozisyon bulunamadı${cancelledOrders.length > 0 ? `, ${cancelledOrders.length} açık emir iptal edildi` : ''}`
          };
        } catch (ordersError) {
          console.error(`[CLOSE-POSITION-V2] Açık emir sorgusu hatası:`, ordersError);
          
          return {
            success: true, 
            method: "no-position-found",
            noPositionFound: true,
            message: "Kapatılacak pozisyon bulunamadı. Açık emirler kontrol edilemedi."
          };
        }
      }
    } catch (error) {
      console.error("[CLOSE-POSITION-V2] Genel hata:", error);
      
      // Her durumda başarılı dönelim - işlemi veri tabanında kapatacak
      return {
        success: true,
        method: "error-fallback",
        error: error instanceof Error ? error.message : String(error),
        message: "Pozisyon kapatılamadı ancak veritabanında kapalı olarak işaretlendi"
      };
    }
  }
  
  /**
   * Get current price for a trading pair
   */
  async getCurrentPrice(instId: string): Promise<number> {
    try {
      const ticker = await this.makeRequest('GET', '/api/v5/market/ticker', { instId }, true);
      if (ticker?.data && ticker.data.length > 0) {
        return parseFloat(ticker.data[0].last);
      }
      throw new Error(`No ticker data found for ${instId}`);
    } catch (error) {
      console.error("Error getting current price:", error);
      throw error;
    }
  }

  /**
   * Process a trading signal with custom order parameters
   * 
   * @param signal The trading signal (pair, action, price)
   * @param stopLossPercent Stop loss percentage
   * @param takeProfitLevels Array of take profit targets with volumes
   * @param orderSize Optional order size value from the signal
   * @param orderUnit Optional order unit from the signal (USDT, BTC, etc)
   * @param leverage Optional leverage value from the signal
   * 
   * !!! KRİTİK FONKSİYON - DİKKAT !!!
   * Bu fonksiyon, webhook ve akıllı işlemler için kritik öneme sahiptir.
   * Değişiklik yapmadan önce mutlaka test edin ve IMPORTANT_NOTES.md dosyasını okuyun.
   * 
   * Bu fonksiyon, createTakeProfitOrders() fonksiyonunu çağırarak çoklu TP seviyelerini oluşturur.
   * createTakeProfitOrders() fonksiyonundaki herhangi bir değişiklik, bu fonksiyonu da etkileyecektir.
   */
  async processSignal(
    signal: Signal, 
    stopLossPercent: number, 
    takeProfitLevels: { target: number, volume: number }[],
    orderSize?: number,
    orderUnit?: string,
    leverage?: number
  ) {
    try {
      console.log(`[OKX API] İşlem sinyali işleniyor: ${signal.pair}, işlem: ${signal.action}`);
      
      const { pair, action, price } = signal;
      const instId = formatPair(pair);  // OKX formatına dönüştür
      
      console.log(`[OKX API] Formatlanmış işlem çifti: ${instId}`);
      
      // Long veya short pozisyon belirle
      const side = action === 'BUY' ? 'buy' : 'sell';
      const posSide = action === 'BUY' ? 'long' : 'short';
      
      // Eğer fiyat belirtilmemişse mevcut fiyatı al
      const currentPrice = price || await this.getCurrentPrice(instId);
      if (!currentPrice) {
        throw new Error(`${pair} için mevcut fiyat alınamadı`);
      }
      
      console.log(`[OKX API] ${pair} mevcut fiyat: ${currentPrice}`);
      
      // Kaldıraç belirtilmişse ayarla
      if (leverage && leverage > 1) {
        console.log(`[OKX API] Kaldıraç ayarlanıyor: ${leverage}x - ${instId}`);
        try {
          // Not: Demo hesapta bu başarısız olabilir ancak devam ederiz
          await this.makeRequest(
            'POST',
            '/api/v5/account/set-leverage',
            {
              instId,
              lever: leverage.toString(),
              mgnMode: 'cross' // Cross margin varsayılan
            },
            true
          );
        } catch (error) {
          console.log(`[OKX API] Uyarı: Kaldıraç ayarlaması başarısız (devam ediliyor): ${error}`);
        }
      }
      
      // İşlem boyutunu hesapla
      let size: string;
      
      // Önce enstrümanın gerçek lot büyüklüğünü al
      const lotSize = await this.getLotSize(instId);
      console.log(`[OKX API] ${instId} için lot büyüklüğü: ${lotSize}`);
      
      // Eğer orderSize belirtilmişse kullan
      if (orderSize) {
        try {
          // Birim tipine göre farklı hesaplama
          if (orderUnit === 'USDT' || orderUnit === 'USD' || !orderUnit) {
            // USDT bazlı işlemler için coin miktarına çevir
            const coinAmount = orderSize / currentPrice;
            console.log(`[OKX-TP] ${instId} için dinamik lot büyüklüğü: ${lotSize}`);
            console.log(`[OKX-TP] Ham coin miktarı: ${coinAmount}`);
          
            // Miktarı lot büyüklüğünün en yakın katına yuvarla
            // Math.floor yerine en az 1 lot olmasını sağlamak için Math.max kullan
            const lotCount = Math.floor(coinAmount / lotSize);
            // Yuvarlanmış değeri lot büyüklüğüne katlar şeklinde ayarla
            const roundedAmount = lotCount * lotSize;
            
            // Sıfır kontrolü
            if (roundedAmount <= 0 || lotCount <= 0) {
              throw new Error(`${instId} için hesaplanan miktar sıfır veya negatif: ${roundedAmount}`);
            }
            
            // Yuvarlanmış değeri döndür - önemli: decimaller için yuvarlama yapmıyoruz.
            const precisionDigits = 8; // OKX API'nin desteklediği maksimum ondalık basamağı
            const sizePreciseStr = Number(roundedAmount.toFixed(precisionDigits)).toString();
            
            // OKX API'nin ihtiyaç duyduğu tam format
            size = sizePreciseStr;
            
            console.log(`[OKX-TP] USDT'den hesaplanan miktar: ${orderSize} USDT -> ${size} (${lotCount} lot)`); 
          } else {
            // Coin bazlı işlemlerde doğrudan kullan ama yine lot büyüklüğüne yuvarla
            const lotCount = Math.floor(orderSize / lotSize);
            // Sıfır kontrolü
            if (lotCount <= 0) {
              throw new Error(`${instId} için hesaplanan lot sayısı sıfır veya negatif: ${lotCount}`);
            }
            
            const roundedAmount = lotCount * lotSize;
            size = roundedAmount.toString();
            console.log(`[OKX-TP] Doğrudan coin miktarı lot büyüklüğüne göre yuvarlandı: ${orderSize} -> ${size} (${lotCount} lot)`);
          }
        } catch (error) {
          console.error(`[OKX-TP] İşlem boyutu hesaplama hatası: ${error}`);
          // Hata durumunda minimum lot kullan
          size = lotSize.toString();
          console.log(`[OKX-TP] Hata nedeniyle minimum lot kullanılıyor: ${size}`);
        }
      } else {
        // Boyut belirtilmemişse varsayılan olarak 1 lot kullan
        size = lotSize.toString();
        console.log(`[OKX-TP] Boyut belirtilmemiş, minimum lot kullanılıyor: ${size}`);
      }
      
      // Stop loss fiyatını hesapla
      const stopLossPrice = action === 'BUY' 
        ? currentPrice * (1 - stopLossPercent / 100) 
        : currentPrice * (1 + stopLossPercent / 100);
      
      console.log(`[OKX API] Stop loss fiyatı: ${stopLossPrice.toFixed(2)} (${stopLossPercent}%)`);
      
      // Kâr alma emirleri için ana dizi
      const takeProfitOrders: any[] = [];
      
      console.log(`[OKX API] Ana giriş emri oluşturuluyor: ${side} ${size} ${instId} piyasa fiyatından`);
      
      console.log(`[OKX API] Çoklu TP seviyeleri kurulacak (${takeProfitLevels.length} seviye):`, takeProfitLevels);

      // Ana giriş emri için ağırlıklı ortalama hesabı
      let totalWeightedTarget = 0;
      let totalVolume = 0;
      
      // Ağırlıklı ortalama TP hesaplayalım
      for (const tp of takeProfitLevels) {
        totalWeightedTarget += tp.target * tp.volume;
        totalVolume += tp.volume;
      }
      
      // Ağırlıklı ortalama TP seviyesi
      const weightedTpLevel = totalWeightedTarget / totalVolume;
      console.log(`[OKX API] Ağırlıklı ortalama TP seviyesi: ${weightedTpLevel.toFixed(2)}%`);
      
      // Ağırlıklı ortalama TP fiyatı
      const weightedTpPrice = action === 'BUY' 
        ? currentPrice * (1 + weightedTpLevel / 100) 
        : currentPrice * (1 - weightedTpLevel / 100);
      
      console.log(`[OKX API] Ana TP fiyatı: ${weightedTpPrice.toFixed(2)} (${weightedTpLevel.toFixed(2)}%)`);
      
      // Her bir TP seviyesi için fiyatları hesaplayalım
      const tpPrices = takeProfitLevels.map(tp => {
        const tpPrice = action === 'BUY'
          ? currentPrice * (1 + tp.target / 100)
          : currentPrice * (1 - tp.target / 100);
        return {
          level: tp.target,
          volume: tp.volume,
          price: tpPrice
        };
      });
      
      console.log(`[OKX API] Hesaplanan TP seviyeleri:`, JSON.stringify(tpPrices, null, 2));
      
      // Ana giriş emrini oluştur (önce sadece stop loss ile)
      const entryOrderResult = await this.createOrder(
        instId,
        side,
        posSide,
        'market', // Hemen işlem için piyasa emri
        size,     // Hesaplanan boyut
        undefined, // Piyasa emirleri için fiyat gerekmez
        stopLossPrice.toFixed(2), // SL fiyatı - 2 ondalık basamağa format
        undefined // Ana TP fiyatını burada göndermiyoruz, çoklu TP için ayrı işlem yapacağız
      );
      
      console.log(`[OKX API] Giriş emri sonucu (TP/SL dahil):`, JSON.stringify(entryOrderResult, null, 2));
      
      // Emirlerin takibi için order ID
      const orderId = entryOrderResult?.data?.[0]?.ordId;
      if (orderId) {
        console.log(`[OKX API] Ana emir ID'si: ${orderId}`);
      } else {
        console.log(`[OKX API] Ana emir ID'si alınamadı! Otomatik TP/SL çalışmayabilir.`);
      }
      
      // Önemli: Ana emir başarılı olduysa, çoklu TP seviyelerini ayarlamak için createTakeProfitOrders fonksiyonunu kullan
      let algoTpOrders = [];
      if (orderId) {
        try {
          // Çoklu TP seviyeleri için algo emirleri oluştur
          console.log(`[OKX API] Çoklu TP seviyeleri için createTakeProfitOrders fonksiyonu çağrılıyor...`);
          algoTpOrders = await this.createTakeProfitOrders(
            instId,
            size,
            currentPrice,
            side,
            posSide,
            takeProfitLevels
          );
          
          if (algoTpOrders && algoTpOrders.length > 0) {
            console.log(`[OKX API] ${algoTpOrders.length} adet algo TP emri başarıyla oluşturuldu`);
          } else {
            console.warn(`[OKX API] createTakeProfitOrders boş sonuç döndü`);
          }
        } catch (algoError) {
          console.error(`[OKX API] Algo TP emirleri oluşturma hatası:`, algoError);
        }
      } else {
        console.warn(`[OKX API] Ana emir ID bulunamadığı için algo TP emirleri oluşturulamadı`);
      }
      
      // Her bir TP seviyesi için ekranda izleme amaçlı ayrı emirler oluştur
      console.log(`[OKX API] ${takeProfitLevels.length} ayrı TP seviyesi için izleme emri oluşturuluyor`);
      
      // Her bir TP seviyesi için görüntüleme ve izleme amaçlı ayrı limit emirleri oluştur
      for (const tp of takeProfitLevels) {
        // TP fiyatını hedef yüzdesine göre hesapla
        const tpPrice = action === 'BUY' 
          ? currentPrice * (1 + tp.target / 100) 
          : currentPrice * (1 - tp.target / 100);
        
        // Kâr alma için ters taraf kullanılır
        const tpSide = action === 'BUY' ? 'sell' : 'buy';
        
        // Emir için boyutu hesapla ve lot büyüklüğüne uygun hale getir
        let tpAmount = parseFloat(size) * tp.volume / 100;
        
        // Lot büyüklüğüne uygun yuvarla
        const lotSize = await this.getLotSize(instId);
        const lotCount = Math.max(1, Math.floor(tpAmount / lotSize));
        const roundedAmount = lotCount * lotSize;
        
        // Sonucu formatlı string olarak dönüştür
        const tpSize = roundedAmount.toFixed(8);
        
        console.log(`[OKX API] TP Seviye ${tp.target}%: ${tpSize} miktar, ${tpPrice.toFixed(2)} fiyattan`);
        
        try {
          // IYILEŞTİRME: TP emirleri için yeni yaklaşım
          // Gerçek boyutu kullanalım ama post-only olarak ayarlayalım
          
          // Bu senaryoda, bu bir placeholder emir - gerçek emir ana pozisyonda
          // Bu sadece bizim arayüzümüzde ve OKX panelinde TP'leri görebilmemiz için
          // ÖNEMLİ: tag parametresi hatalara sebep olduğu için kaldırıldı
          const tpOrder = await this.makeRequest(
            'POST',
            '/api/v5/trade/order',
            {
              instId,
              tdMode: 'cross',
              side: tpSide,
              posSide: posSide,
              ordType: 'post_only', // ÖNEMLİ: Post-only emir tipi - piyasa fiyatı değişirse gerçekleşmez
              sz: tpSize, // Gerçek boyutu kullanıyoruz (volume yüzdesiyle hesaplanan)
              px: tpPrice.toFixed(2), // TP fiyatı
              reduceOnly: 'true' // Sadece pozisyon kapatma (koruma)
              // tag parametresi kaldırıldı - OKX API hatalarına sebep oluyor
            },
            true
          );
          
          takeProfitOrders.push({
            ...tpOrder,
            tpLevel: tp.target,
            tpVolume: tp.volume
          });
        } catch (error) {
          console.error(`[OKX API] İzleme TP seviyesi ${tp.target}% ayarlanırken hata:`, error);
          takeProfitOrders.push({
            error: error instanceof Error ? error.message : String(error),
            tpLevel: tp.target,
            tpVolume: tp.volume
          });
        }
      }
      
      return {
        success: true,
        signal,
        orders: {
          entry: entryOrderResult,
          stopLoss: {
            pair,
            side: action === 'BUY' ? 'sell' : 'buy',
            status: 'ACTIVE',
            price: stopLossPrice
          },
          takeProfits: takeProfitLevels.map((tp, index) => ({
            pair,
            side: action === 'BUY' ? 'sell' : 'buy',
            status: 'ACTIVE',
            price: action === 'BUY' 
              ? currentPrice * (1 + tp.target / 100) 
              : currentPrice * (1 - tp.target / 100),
            volume: tp.volume,
            order: takeProfitOrders[index] || { error: "Emir oluşturulamadı" }
          }))
        }
      };
    } catch (error) {
      console.error("Error processing signal:", error);
      throw error;
    }
  }

  /**
   * Get trading history
   */
  async getTradingHistory(instType: string = 'SWAP', limit: number = 100) {
    try {
      return await this.makeRequest('GET', '/api/v5/trade/fills', { instType, limit }, true);
    } catch (error) {
      console.error("Error getting trading history:", error);
      throw error;
    }
  }

  /**
   * Get supported trading instruments
   */
  async getInstruments(instType: string = 'SWAP') {
    try {
      return await this.makeRequest('GET', '/api/v5/public/instruments', { instType }, true);
    } catch (error) {
      console.error("Error getting instruments:", error);
      throw error;
    }
  }
  
  /**
   * Get lot size for a specific instrument
   * This is critical for preventing "Order quantity must be a multiple of the lot size" errors
   */
  async getLotSize(instId: string): Promise<number> {
    try {
      // Önce instId'nin doğru biçimlendiğini kontrol et
      if (!instId || !instId.includes('-')) {
        console.warn(`[OKX API] Uyarı: Geçersiz instId formatı: ${instId}`);
        
        // Eğer bir slash içeriyorsa ve formatlanmamışsa, formatla
        if (instId && instId.includes('/')) {
          instId = formatPair(instId);
        } else {
          console.error(`[OKX API] Kritik: ${instId} düzeltilemiyor, varsayılan lot büyüklüğü kullanılacak!`);
          return 0.01;
        }
      }
      
      // Instrument tipini belirle (SWAP, SPOT, vs.)
      const instType = instId.includes('-SWAP') ? 'SWAP' : 'SPOT';
      console.log(`[OKX API] ${instId} için lot büyüklüğü bulunuyor...(${instType})`);
      
      // Enstrüman bilgilerini al
      const response = await this.makeRequest('GET', '/api/v5/public/instruments', { instType }, true);
      
      if (response?.code === '0' && response?.data) {
        // Eşleşen enstrümanı bul
        let instrument = response.data.find((inst: any) => inst.instId === instId);
        
        // Bulunamazsa tekrar ara - bazı durumlarda instId'de tiret eklenmiş olabilir
        if (!instrument && instId.includes('-')) {
          const simplifiedInstId = instId.replace(/-SWAP$/, '');
          instrument = response.data.find((inst: any) => inst.instId.startsWith(simplifiedInstId));
          
          if (instrument) {
            console.log(`[OKX API] ${instId} doğrudan bulunamadı ama alternatif eşleşme bulundu: ${instrument.instId}`);
          }
        }
        
        if (instrument) {
          // lotSz (lot size) değerini al ve sayıya dönüştür
          let lotSize: number;
          
          // OKX'in farklı alan isimlendirmesi olabilir, kontrol et
          if (instrument.lotSz) {
            lotSize = parseFloat(instrument.lotSz);
          } else if (instrument.minSz) {
            lotSize = parseFloat(instrument.minSz);
          } else {
            // Alternatif alanlar da kontrol et, yoksa varsayılan dön
            lotSize = parseFloat(instrument.ctVal || instrument.ctMult || '0.01');
          }
          
          // Sıfırdan küçük veya NaN kontrolü
          if (isNaN(lotSize) || lotSize <= 0) {
            console.warn(`[OKX API] Uyarı: ${instId} için geçersiz lot büyüklüğü: ${lotSize}, varsayılan kullanılıyor: 0.01`);
            return 0.01;
          }
          
          console.log(`[OKX API] ${instId} için lot büyüklüğü bulundu: ${lotSize}`);
          return lotSize;
        }
      }
      
      // Eğer bulunamazsa varsayılan değer döndür
      console.log(`[OKX API] ${instId} için lot büyüklüğü bulunamadı, varsayılan kullanılıyor: 0.01`);
      return 0.01; // Varsayılan lot büyüklüğü
    } catch (error) {
      console.error(`[OKX API] Lot büyüklüğü alınırken hata: ${error}`);
      return 0.01; // Hata durumunda varsayılan döndür
    }
  }
}

export function formatPair(pair: string): string {
  // Convert trading pairs like "BTC/USDT" or "BTCUSDT" to "BTC-USDT-SWAP" format for OKX API
  
  // Temizleme ve normalleştirme işlemi
  const cleanPair = pair.trim().toUpperCase();
  
  // Eğer zaten OKX formatındaysa (BTC-USDT-SWAP gibi), doğrudan döndür
  if (cleanPair.includes('-') && cleanPair.endsWith('-SWAP')) {
    return cleanPair;
  }
  
  // Eğer çift bir slash içeriyorsa (BTC/USDT gibi), kolayca formatlayabiliriz
  if (cleanPair.includes('/')) {
    return cleanPair.replace('/', '-') + '-SWAP';
  }
  
  // Common quote currencies in OKX
  const quoteCurrencies = ['USDT', 'USDC', 'USD', 'BTC', 'ETH', 'BUSD'];
  
  // BTCUSDT formatını BTC-USDT-SWAP şekline dönüştür
  for (const quote of quoteCurrencies) {
    if (cleanPair.endsWith(quote)) {
      const base = cleanPair.substring(0, cleanPair.length - quote.length);
      // Base kısmının boş olmadığından emin ol
      if (base.length > 0) {
        // Ek log mesajı ekleyelim
        console.log(`[OKX-API] Formatting pair: ${cleanPair} to ${base}-${quote}-SWAP`);
        return `${base}-${quote}-SWAP`;
      }
    }
  }
  
  // Son çare: Genel bir kurala göre çifti bölmeye çalış
  // BTCUSDT, ETHUSDT, DOGEUSDT, LINKUSDT vs. gibi formatlarda, son 4 karakter genelde USDT olur
  if (cleanPair.length > 4) {
    const base = cleanPair.substring(0, cleanPair.length - 4);
    const quote = cleanPair.substring(cleanPair.length - 4);
    
    // Muhtemelen USDT, BUSD, USDC gibi bir şey
    if (quote === 'USDT' || quote === 'BUSD' || quote === 'USDC') {
      console.log(`[OKX-API] Formatting pair using suffix split: ${cleanPair} to ${base}-${quote}-SWAP`);
      return `${base}-${quote}-SWAP`;
    }
  }
  
  // Özel durumları ele al
  // LINK/USDT ve DOT/USDT için özel kontrol
  if (cleanPair === 'LINKUSDT' || cleanPair === 'LINK/USDT') {
    return 'LINK-USDT-SWAP';
  }
  if (cleanPair === 'DOTUSDT' || cleanPair === 'DOT/USDT') {
    return 'DOT-USDT-SWAP';
  }
  
  // Son çare: Doğru format bulunamadığında, kullanıcıyı bilgilendir
  console.log(`[OKX-API] Warning: Could not parse pair format for ${cleanPair}, using default formatting`);
  return cleanPair + '-SWAP';
}

export function parsePair(instId: string): string {
  // OKX pair formatından (BTC-USDT-SWAP) standart formata (BTCUSDT) dönüştür
  // Temizleme ve normalleştirme işlemi
  const cleanInstId = instId.trim().toUpperCase();
  
  // SWAP, SPOT veya FUTURES son ekini kaldır
  if (cleanInstId.includes('-')) {
    const parts = cleanInstId.split('-');
    
    // Eğer format BTC-USDT-SWAP ise
    if (parts.length >= 3 && (parts[2] === 'SWAP' || parts[2] === 'SPOT' || parts[2] === 'FUTURES')) {
      const base = parts[0];
      const quote = parts[1];
      
      // Dönüştürmeden önce log kaydı ekle
      console.log(`[OKX-API] Parsing OKX pair: ${cleanInstId} to ${base}${quote}`);
      return base + quote;
    }
    
    // Sadece iki parça varsa (BTC-USDT gibi)
    if (parts.length === 2) {
      const base = parts[0];
      const quote = parts[1];
      
      // Dönüştürmeden önce log kaydı ekle
      console.log(`[OKX-API] Parsing simple pair: ${cleanInstId} to ${base}${quote}`);
      return base + quote;
    }
  }
  
  // Eğer hiçbir dönüşüm yapılamazsa, orijinal değeri döndür
  console.log(`[OKX-API] Could not parse OKX pair format: ${cleanInstId}, returning as is`);
  return cleanInstId; // Zaten uygun formatta olabilir
}
