import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import {
  insertBotSchema,
  insertApiKeySchema,
  insertTradeSchema,
  Signal,
} from "@shared/schema";
// import { BinanceApiClient, formatSymbol } from "./binance-api"; // Eski Binance API
import { OkxApiClient, formatPair } from "./okx-api"; // Yeni OKX API

// OKX API client değişkeni
let okxClient: OkxApiClient | null = null;

// Demo mod kontrolü için global değişken
const isDemoMode = true; // OKX istemcisi demo modda olduğu için true olarak ayarladık

// Server başlatılırken API anahtarlarını kontrol et ve okxClient'ı ayarla
async function initializeOkxClient() {
  try {
    console.log("API anahtarları kontrol ediliyor...");
    const apiKeys = await storage.getApiKeys();
    const activeKey = apiKeys.find((key) => key.isActive);

    if (
      activeKey &&
      activeKey.apiKey &&
      activeKey.apiSecret &&
      activeKey.passphrase
    ) {
      console.log(
        `Aktif API anahtarı bulundu: ${activeKey.apiKey.substring(0, 4)}...`,
      );
      okxClient = new OkxApiClient(
        activeKey.apiKey,
        activeKey.apiSecret,
        activeKey.passphrase,
      );
      console.log("OKX client başarıyla başlatıldı");
      return true;
    } else {
      if (activeKey) {
        console.log(
          "Aktif API anahtarı eksik bilgilere sahip (passphrase gerekli)",
        );
      } else {
        console.log("Aktif API anahtarı bulunamadı");
      }
    }
  } catch (error) {
    console.error("API anahtarı kontrolü sırasında hata:", error);
  }
  return false;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Önce OKX client'ı başlat
  await initializeOkxClient();
  
  // Webhook endpoint for TradingView and other external systems
  app.post("/api/webhook", async (req: Request, res: Response) => {
    try {
      // Log the incoming webhook data (except secrets)
      const signalBody = { ...req.body };
      if (signalBody.secret) signalBody.secret = "***REDACTED***";
      
      console.log("Webhook received:", JSON.stringify(signalBody));
      
      // Bot ID kontrolü
      if (!signalBody.bot_id) {
        console.error("Bot ID missing in webhook payload");
        return res.status(400).json({ 
          success: false, 
          message: "Bot ID missing", 
          details: "Webhook must include 'bot_id' field. Check your TradingView webhook settings."
        });
      }
      
      // Bot ID'yi al
      const botId = signalBody.bot_id;
      
      // Bot ID'yi çevir
      let botIdNum: number;
      try {
        botIdNum = parseInt(String(botId));
        if (isNaN(botIdNum)) {
          throw new Error("Bot ID number parsing failed");
        }
      } catch (e) {
        console.error("Invalid bot ID format:", botId);
        return res.status(400).json({
          success: false,
          message: "Invalid bot ID format",
          details: "Bot ID must be a valid number"
        });
      }
      
      // URL'i oluştur
      const redirectUrl = `/api/bots/${botIdNum}/signal`;
      console.log(`Webhook yönlendiriliyor: ${botIdNum} -> ${redirectUrl}`);
      
      // Ana controller'a yönlendir
      return res.redirect(307, redirectUrl);
    } catch (error) {
      console.error("Error processing webhook:", error);
      return res.status(500).json({ 
        success: false, 
        message: "Webhook processing error", 
        error: String(error) 
      });
    }
  });

  // Binance uyumluluğu için yönlendirmeler (okx api kullan)
  app.get("/api/binance/account", async (_req: Request, res: Response) => {
    return res.redirect(307, "/api/okx/account");
  });

  app.get("/api/binance/price/:symbol", async (req: Request, res: Response) => {
    return res.redirect(307, `/api/okx/price/${req.params.symbol}`);
  });

  app.post("/api/binance/test", async (req: Request, res: Response) => {
    return res.redirect(307, "/api/okx/test");
  });

  // API KEY ROUTES
  app.get("/api/keys", async (_req: Request, res: Response) => {
    try {
      const keys = await storage.getApiKeys();

      // Mask secrets in API response
      const maskedKeys = keys.map((key) => ({
        ...key,
        apiKey: key.apiKey.substring(0, 4) + "..." + key.apiKey.slice(-4),
        apiSecret: "••••••••••••••••",
      }));

      res.json(maskedKeys);
    } catch (error) {
      console.error("Error fetching API keys:", error);
      res.status(500).json({ message: "Failed to fetch API keys" });
    }
  });

  app.post("/api/keys", async (req: Request, res: Response) => {
    try {
      console.log("Creating new API key");
      const validatedKey = insertApiKeySchema.parse(req.body);

      // Test etmeden direkt kaydet
      console.log("Saving API key");
      const newKey = await storage.createApiKey(validatedKey);

      // API anahtarını hemen kullanmaya başla
      if (validatedKey.isActive) {
        console.log("Initializing OKX client with new API key");
        if (
          validatedKey.apiKey &&
          validatedKey.apiSecret &&
          validatedKey.passphrase
        ) {
          const newClient = new OkxApiClient(
            validatedKey.apiKey,
            validatedKey.apiSecret,
            validatedKey.passphrase,
          );
          okxClient = newClient;
        } else {
          console.log("API key, secret, or passphrase is missing");
        }
      }

      // Mask secrets in response
      const maskedKey = {
        ...newKey,
        apiKey: newKey.apiKey.substring(0, 4) + "..." + newKey.apiKey.slice(-4),
        apiSecret: "••••••••••••••••",
        passphrase: "••••••••",
      };

      res.status(201).json(maskedKey);
    } catch (error) {
      console.error("Error creating API key:", error);

      if (error instanceof z.ZodError) {
        return res
          .status(400)
          .json({ message: "Invalid data", errors: error.errors });
      }

      res.status(500).json({ message: "Failed to create API key" });
    }
  });

  app.put("/api/keys/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }

      const existing = await storage.getApiKey(id);
      if (!existing) {
        return res.status(404).json({ message: "API key not found" });
      }

      // Only validate fields that are present
      const updates = req.body;

      const updated = await storage.updateApiKey(id, updates);

      // If this key is now active, initialize the OKX client
      if (
        updated?.isActive &&
        updates.apiKey &&
        updates.apiSecret &&
        updates.passphrase
      ) {
        okxClient = new OkxApiClient(
          updates.apiKey,
          updates.apiSecret,
          updates.passphrase,
        );
      }

      // Mask secrets in response
      const maskedKey = updated
        ? {
            ...updated,
            apiKey:
              updated.apiKey.substring(0, 4) + "..." + updated.apiKey.slice(-4),
            apiSecret: "••••••••••••••••",
            passphrase: "••••••••",
          }
        : null;

      res.json(maskedKey);
    } catch (error) {
      console.error("Error updating API key:", error);

      if (error instanceof z.ZodError) {
        return res
          .status(400)
          .json({ message: "Invalid data", errors: error.errors });
      }

      res.status(500).json({ message: "Failed to update API key" });
    }
  });

  app.delete("/api/keys/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }

      const deleted = await storage.deleteApiKey(id);
      if (!deleted) {
        return res.status(404).json({ message: "API key not found" });
      }

      res.status(204).end();
    } catch (error) {
      console.error("Error deleting API key:", error);
      res.status(500).json({ message: "Failed to delete API key" });
    }
  });

  // Test OKX API connection
  app.post("/api/okx/test", async (req: Request, res: Response) => {
    console.log("API test endpoint called");

    try {
      const { apiKey, apiSecret, passphrase } = req.body;

      // Log ama gizlilik için maskele
      if (apiKey && apiSecret && passphrase) {
        console.log(
          "Received API test request with keys:",
          apiKey.substring(0, 4) + "..." + apiKey.slice(-4),
          "Secret provided (masked)",
        );
      } else {
        console.log(
          "Missing API credentials:",
          !apiKey ? "Missing API Key" : "API Key provided",
          !apiSecret ? "Missing Secret Key" : "Secret Key provided",
          !passphrase ? "Missing Passphrase" : "Passphrase provided",
        );

        return res.status(400).json({
          success: false,
          message: "API key, gizli anahtar ve passphrase gereklidir",
        });
      }

      // API anahtarının format kontrolü
      if (apiKey.length < 10) {
        return res.status(400).json({
          success: false,
          message: "API anahtarı geçersiz formatta",
        });
      }

      // API sırrının format kontrolü
      if (apiSecret.length < 10) {
        return res.status(400).json({
          success: false,
          message: "API gizli anahtarı geçersiz formatta",
        });
      }

      // Passphrase kontrolü
      if (passphrase.length < 1) {
        return res.status(400).json({
          success: false,
          message: "Passphrase geçersiz formatta",
        });
      }

      console.log("Creating temporary OKX client for testing");
      const testClient = new OkxApiClient(apiKey, apiSecret, passphrase);

      console.log("Testing OKX connection");
      const isValid = await testClient.testConnection();

      console.log("OKX connection test result:", isValid);

      if (isValid) {
        return res.json({
          success: true,
          message: "OKX API bağlantısı başarılı",
        });
      } else {
        return res.status(400).json({
          success: false,
          message:
            "OKX API bağlantısı başarısız. API anahtarlarınızı kontrol edin.",
        });
      }
    } catch (error: any) {
      console.error("Error testing OKX connection:", error);

      // Hata yanıtını kullanıcıya anlaşılır hale getir
      let errorMessage = "Bağlantı testi sırasında bir hata oluştu";

      if (error?.message) {
        if (error.message.includes("Invalid API Key")) {
          errorMessage = "Geçersiz API anahtarı";
        } else if (error.message.includes("Invalid signature")) {
          errorMessage = "Geçersiz API gizli anahtarı";
        } else if (error.message.includes("Invalid passphrase")) {
          errorMessage = "Geçersiz passphrase";
        } else if (error.message.includes("Permission denied")) {
          errorMessage = "Bu API anahtarının yeterli izni yok";
        } else if (error.message.includes("Network error")) {
          errorMessage = "Ağ hatası: OKX sunucusuna erişilemiyor";
        }
      }

      return res.status(500).json({
        success: false,
        message: errorMessage,
        details: error.message || "Bilinmeyen hata",
      });
    }
  });

  // Get account information
  app.get("/api/okx/account", async (_req: Request, res: Response) => {
    try {
      if (!okxClient) {
        return res.status(400).json({
          message: "OKX API yapılandırılmamış",
          description:
            "Lütfen Ayarlar sayfasından geçerli bir OKX API anahtarı ekleyin ve etkinleştirin.",
        });
      }

      // Hesap bilgilerini al
      const accountInfo = await okxClient.getAccountInfo();

      // Direct API yanıtını konsola yazdır
      console.log(
        "RAW API response:",
        JSON.stringify(accountInfo).substring(0, 100) + "...",
      );

      // API yanıtını basit bir formata dönüştür - daha sağlam şekilde
      const simplifiedData = {
        success: true,
        totalEq: "0",
        availableEq: "0",
        details: [],
        rawData: accountInfo,
      };

      // OKX API yanıt formatını doğru şekilde işle
      if (accountInfo && accountInfo.code === "0" && Array.isArray(accountInfo.data)) {
        // OKX yanıt formatı: { code: "0", data: [{ ... }] }
        const accountData = accountInfo.data[0];
        
        console.log("Using simplified data structure");

        if (accountData) {
          // Toplam bakiye değeri
          simplifiedData.totalEq = accountData.adjEq || accountData.totalEq || "0";

          // USDT ve diğer para birimleri için detayları işle
          if (Array.isArray(accountData.details)) {
            simplifiedData.details = accountData.details;
            
            // USDT bakiyesini bul
            const usdtDetail = accountData.details.find((d: any) => d.ccy === "USDT");
            if (usdtDetail) {
              simplifiedData.availableEq = usdtDetail.availBal || usdtDetail.availEq || "0";
            }
          }
        }
        
        console.log("Successfully processed account data");
      }

      console.log(
        "Sending simplified data:",
        JSON.stringify(simplifiedData).substring(0, 100) + "...",
      );
      res.json(simplifiedData);
    } catch (error) {
      console.error("Error fetching account info:", error);
      res.status(500).json({
        success: false,
        message: "Hesap bilgilerini alırken hata oluştu",
        error: String(error),
      });
    }
  });

  // Get current price for a trading pair
  app.get("/api/okx/price/:symbol", async (req: Request, res: Response) => {
    try {
      if (!okxClient) {
        return res.status(400).json({
          message: "OKX API yapılandırılmamış",
          description:
            "Lütfen Ayarlar sayfasından geçerli bir OKX API anahtarı ekleyin ve etkinleştirin.",
        });
      }

      const symbol = req.params.symbol;
      // Debug modu
      console.log("Request for price of symbol:", symbol);
      console.log("Formatted as OKX symbol:", formatPair(symbol));

      try {
        const price = await okxClient.getCurrentPrice(formatPair(symbol));
        console.log("Successfully retrieved price for", symbol, ":", price);
        res.json({ symbol, price });
      } catch (error) {
        console.error("Error getting price:", error);
        res.status(500).json({
          message: "Fiyat bilgisi alınırken hata oluştu",
          error: String(error),
        });
      }
    } catch (error) {
      console.error("Error fetching price:", error);
      res.status(500).json({ message: "Fiyat bilgisi alınırken hata oluştu" });
    }
  });

  // BOT ROUTES
  app.get("/api/bots", async (_req: Request, res: Response) => {
    try {
      const bots = await storage.getBots();
      res.json(bots);
    } catch (error) {
      console.error("Error fetching bots:", error);
      res.status(500).json({ message: "Failed to fetch bots" });
    }
  });

  app.get("/api/bots/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }

      const bot = await storage.getBot(id);
      if (!bot) {
        return res.status(404).json({ message: "Bot not found" });
      }

      res.json(bot);
    } catch (error) {
      console.error("Error fetching bot:", error);
      res.status(500).json({ message: "Failed to fetch bot" });
    }
  });

  app.post("/api/bots", async (req: Request, res: Response) => {
    try {
      const validatedBot = insertBotSchema.parse(req.body);
      const newBot = await storage.createBot(validatedBot);
      res.status(201).json(newBot);
    } catch (error) {
      console.error("Error creating bot:", error);

      if (error instanceof z.ZodError) {
        return res
          .status(400)
          .json({ message: "Invalid data", errors: error.errors });
      }

      res.status(500).json({ message: "Failed to create bot" });
    }
  });

  app.put("/api/bots/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }

      const existing = await storage.getBot(id);
      if (!existing) {
        return res.status(404).json({ message: "Bot not found" });
      }

      // Only validate fields that are present
      const updates = req.body;

      const updated = await storage.updateBot(id, updates);
      res.json(updated);
    } catch (error) {
      console.error("Error updating bot:", error);

      if (error instanceof z.ZodError) {
        return res
          .status(400)
          .json({ message: "Invalid data", errors: error.errors });
      }

      res.status(500).json({ message: "Failed to update bot" });
    }
  });

  app.delete("/api/bots/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }

      const deleted = await storage.deleteBot(id);
      if (!deleted) {
        return res.status(404).json({ message: "Bot not found" });
      }

      res.status(204).end();
    } catch (error) {
      console.error("Error deleting bot:", error);
      res.status(500).json({ message: "Failed to delete bot" });
    }
  });

  // Process signal for a bot from TradingView or other sources
  app.post("/api/bots/:id/signal", async (req: Request, res: Response) => {
    try {
      // Log the incoming webhook for debugging (redacted sensitive information)
      const signalBody = { ...req.body };
      if (signalBody.secret) signalBody.secret = "***REDACTED***";

      console.log("Webhook payload received:", JSON.stringify(signalBody));
      console.log("Bot ID from params:", req.params.id);

      // !!! KRİTİK KOD PARÇASI - DİKKAT !!!
      // Bu kod bloğu, webhook işleminin doğru çalışması için kritik öneme sahiptir.
      // Burada, webhook işlemi için gereken bot ID'sini URL veya JSON gövdesinden alıyoruz.
      // Değişiklik yapmadan önce mutlaka IMPORTANT_NOTES.md dosyasını okuyun.
      
      // Get bot ID from params or request body
      let id;
      
      // Önce URL parametresini kontrol et
      if (req.params.id && req.params.id !== "BOT_ID" && req.params.id !== "<BOT_ID>" && !isNaN(parseInt(req.params.id))) {
        id = parseInt(req.params.id);
        console.log(`Bot ID URL'den alındı: ${id}`);
      } 
      // Eğer URL'de geçerli ID yoksa, request body'deki bot_id alanını kontrol et
      else if (req.body.bot_id && req.body.bot_id !== "" && !isNaN(parseInt(req.body.bot_id))) {
        id = parseInt(req.body.bot_id);
        console.log(`Bot ID JSON gövdesinden alındı: ${id}`);
      }
      // Eğer hala geçerli bir ID bulunamadıysa hata döndür
      else {
        console.error("Invalid bot ID in webhook URL and request body:", req.params.id, req.body.bot_id);
        return res
          .status(400)
          .json({ 
            success: false, 
            message: "Geçersiz bot ID", 
            details: "Bot ID URL'de veya JSON içerisinde geçerli bir sayı olmalıdır. Placeholder değerler (<BOT_ID> veya BOT_ID) geçerli değildir."
          });
      }

      // Get the bot configuration
      const bot = await storage.getBot(id);
      if (!bot) {
        console.error("Bot not found with ID:", id);
        return res
          .status(404)
          .json({ success: false, message: "Bot bulunamadı" });
      }

      // Check if bot is active
      if (!bot.isActive) {
        console.error("Inactive bot received signal:", id, bot.name);
        return res
          .status(400)
          .json({ success: false, message: "Bot aktif değil" });
      }

      // Check if OKX API client is available
      if (!okxClient) {
        console.error("OKX API client not configured for bot:", id, bot.name);
        return res.status(400).json({
          success: false,
          message: "OKX API yapılandırılmamış",
          description:
            "Lütfen Ayarlar sayfasından geçerli bir OKX API anahtarı ekleyin ve etkinleştirin.",
        });
      }

      // API bağlantısını test et
      const isConnected = await okxClient.testConnection();
      if (!isConnected) {
        return res.status(400).json({
          success: false,
          message: "OKX API bağlantısı başarısız",
          description:
            "API anahtarınızı, gizli anahtarınızı, passphrase'inizi ve IP kısıtlamalarını kontrol edin.",
        });
      }

      // Parse and validate the signal
      const signal: Signal = req.body;

      // Normalize signal data - support both old and new webhook formats
      // The new format might include a position object with nested long/short settings
      let normalizedSignal = { ...signal };

      // İlk adım: TradingView şablonlarını işle
      // "{{strategy.order.price}}" gibi değerlerin gerçek sayılara dönüştürülmesi gerekiyor
      Object.keys(normalizedSignal).forEach(key => {
        const value = normalizedSignal[key];
        if (typeof value === 'string') {
          // TradingView şablon placeholder'larını temizle
          if (value.includes('{{') && value.includes('}}')) {
            console.log(`TradingView şablon değişkeni algılandı: ${key}=${value}, 0 olarak ayarlanıyor`);
            // Bu bir şablon değişkeni - geçici olarak sıfıra ayarla ve devam etmemize izin ver
            normalizedSignal[key] = 0;
          }
        }
      });
      
      // Check for alternative pair field name
      if (!normalizedSignal.pair && signal.trading_pair) {
        normalizedSignal.pair = signal.trading_pair;
      }

      // Check for action in position object
      if (
        !normalizedSignal.action &&
        signal.position &&
        signal.position.action
      ) {
        // Önce büyük harfe çevir, sonra normalized değere ata
        const posAction = signal.position.action.toString().toUpperCase();
        // BUY veya SELL olarak doğrudan ata
        normalizedSignal.action =
          posAction === "BUY" || posAction === "SELL"
            ? (posAction as "BUY" | "SELL")
            : posAction === "buy" || posAction === "LONG"
              ? ("BUY" as "BUY" | "SELL")
              : ("SELL" as "BUY" | "SELL");
      }

      // Get action and normalize it
      let action = normalizedSignal.action?.toString().toUpperCase();

      // Handle TradingView format (buy, sell) vs our format (BUY, SELL)
      if (action === "buy") action = "BUY";
      if (action === "sell") action = "SELL";

      // Validate required fields
      if (
        !normalizedSignal.pair ||
        !action ||
        (action !== "BUY" && action !== "SELL")
      ) {
        console.error("Invalid signal data:", normalizedSignal);
        return res.status(400).json({
          success: false,
          message: "Geçersiz sinyal verisi",
          expectedFormat: {
            pair: "BTCUSDT",
            action: "BUY or SELL",
            price: "Optional price",
          },
        });
      }

      // Store the normalized action and pair
      const validatedAction: "BUY" | "SELL" = action === "BUY" ? "BUY" : "SELL";
      normalizedSignal.action = validatedAction;

      // Update original signal with normalized data for processing
      signal.action = normalizedSignal.action;
      signal.pair = normalizedSignal.pair;
      signal.price = normalizedSignal.price; // TradingView template'i için normalizedSignal.price kullan

      // Use TradingView alert ID if available for tracing
      const alertId = signal.tradingview_alert_id || "manual";
      console.log(
        `Processing ${action} signal for ${signal.pair} from alert ${alertId}`,
      );

      // Process the signal using OKX API with correct settings
      let stopLoss = bot.stopLoss;
      let takeProfitLevels = Array.isArray(bot.takeProfitLevels)
        ? (bot.takeProfitLevels as { target: number; volume: number }[])
        : [];

      let orderSize, orderUnit, leverage;

      // Choose settings based on trade direction
      if (action === "BUY") {
        // Use long-specific settings if available
        if (bot.longEnabled) {
          console.log("Using LONG specific settings for bot:", bot.name);
          stopLoss = bot.longStopLoss || bot.stopLoss;
          takeProfitLevels =
            Array.isArray(bot.longTakeProfitLevels) &&
            bot.longTakeProfitLevels.length > 0
              ? (bot.longTakeProfitLevels as {
                  target: number;
                  volume: number;
                }[])
              : takeProfitLevels;
          orderSize = bot.longOrderSize;
          orderUnit = bot.longOrderUnit;
          leverage = bot.longLeverage;
        } else {
          console.log("LONG trades disabled for bot:", bot.name);
          return res.status(400).json({
            success: false,
            message: "Long (Alım) işlemleri bu bot için devre dışı",
          });
        }
      } else {
        // SELL action
        // Use short-specific settings if available
        if (bot.shortEnabled) {
          console.log("Using SHORT specific settings for bot:", bot.name);
          stopLoss = bot.shortStopLoss || bot.stopLoss;
          takeProfitLevels =
            Array.isArray(bot.shortTakeProfitLevels) &&
            bot.shortTakeProfitLevels.length > 0
              ? (bot.shortTakeProfitLevels as {
                  target: number;
                  volume: number;
                }[])
              : takeProfitLevels;
          orderSize = bot.shortOrderSize;
          orderUnit = bot.shortOrderUnit;
          leverage = bot.shortLeverage;
        } else {
          console.log("SHORT trades disabled for bot:", bot.name);
          return res.status(400).json({
            success: false,
            message: "Short (Satım) işlemleri bu bot için devre dışı",
          });
        }
      }

      // Use signal params if provided, otherwise use bot settings
      // Also check for nested parameters in position object (new webhook format)
      let signalOrderSize, signalOrderUnit, signalLeverage;

      // For nested position format
      if (signal.position) {
        if (action === "BUY" && signal.position.long) {
          signalOrderSize =
            signal.position.long.size || signal.orderSize || orderSize;
          signalOrderUnit =
            signal.position.long.unit || signal.orderUnit || orderUnit;
          signalLeverage =
            signal.position.long.leverage || signal.leverage || leverage;
        } else if (action === "SELL" && signal.position.short) {
          signalOrderSize =
            signal.position.short.size || signal.orderSize || orderSize;
          signalOrderUnit =
            signal.position.short.unit || signal.orderUnit || orderUnit;
          signalLeverage =
            signal.position.short.leverage || signal.leverage || leverage;
        } else {
          // Fallback to direct parameters or bot settings
          signalOrderSize = signal.orderSize || orderSize;
          signalOrderUnit = signal.orderUnit || orderUnit;
          signalLeverage = signal.leverage || leverage;
        }
      } else {
        // Original webhook format
        signalOrderSize = signal.orderSize || orderSize;
        signalOrderUnit = signal.orderUnit || orderUnit;
        signalLeverage = signal.leverage || leverage;
      }

      console.log(
        `Executing trade: ${action} ${signalOrderSize} ${signalOrderUnit} of ${signal.pair} with ${signalLeverage}x leverage`,
      );
      console.log(
        `Stop Loss: ${stopLoss}%, Take Profit Levels: ${JSON.stringify(takeProfitLevels)}`,
      );

      // Current market price should be used if the price is a TradingView template or undefined
      let signalMarketPrice = null;
      if (typeof signal.price === 'string' && signal.price.includes('{{')) {
        console.log(`TradingView template fiyatı algılandı: ${signal.price}, piyasa fiyatı kullanılacak`);
        try {
          // Güncel piyasa fiyatını almayı dene
          signalMarketPrice = await okxClient.getCurrentPrice(signal.pair);
          console.log(`${signal.pair} için güncel fiyat alındı: ${signalMarketPrice}`);
        } catch (priceError) {
          console.error(`Piyasa fiyatı alma hatası:`, priceError);
          signalMarketPrice = null;
        }
      }
      
      // Process the signal with OKX API
      let result;
      try {
        result = await okxClient.processSignal(
          {
            pair: signal.pair,
            action: signal.action,
            price: signalMarketPrice || signal.price, // Önce güncel piyasa fiyatını deneyelim
          },
          stopLoss || 0,
          takeProfitLevels,
          signalOrderSize || undefined,
          signalOrderUnit || undefined,
          signalLeverage || undefined,
        );
      } catch (error: any) {
        console.error("Trade execution error:", error);
        let errorMessage = "İşlem oluşturulamadı";
        let errorDetails = String(error);

        if (error.message.includes("Invalid API-key")) {
          errorMessage = "Geçersiz API anahtarı, IP veya izinler";
          errorDetails =
            "Lütfen API anahtarınızı, gizli anahtarınızı, passphrase'inizi ve IP kısıtlamalarını kontrol edin.";
        } else if (isDemoMode && error.message.includes("PERMISSION_DENIED")) {
          errorMessage = "Demo hesapta işlem oluşturma izni yok";
          errorDetails =
            "Lütfen demo hesap izinlerini kontrol edin veya tek TP seviyesiyle deneyin.";
        }

        return res.status(400).json({
          success: false,
          message: errorMessage,
          description: errorDetails,
        });
      }

      // Create a trade record
      // Özellikle price değeri için TradingView template değişkenlerini kontrol et
      let tradePrice = 0;
      // Eğer fiyat bir TradingView şablonu içeriyorsa temizle ve güncel fiyatı kullan
      if (typeof signal.price === 'string' && signal.price.includes('{{')) {
        console.log(`Trade kaydı için geçersiz fiyat değeri: ${signal.price}, 0 kullanılacak`);
        tradePrice = 0;
      } else if (signal.price) {
        // Fiyat varsa sayıya çevir
        tradePrice = Number(signal.price) || 0;
      }
      
      const trade = await storage.createTrade({
        botId: bot.id,
        tradingPair: signal.pair,
        type: signal.action,
        price: tradePrice,
        amount: signalOrderSize || 0,
        leverage: signalLeverage ? signalLeverage : 1,
        profit: 0, // Will be updated when the trade is closed
        status: "OPEN",
        notes: `TradingView Alert ID: ${alertId}`,
        // openedAt field is automatically handled by the database with DEFAULT NOW()
      });

      console.log(`Successfully processed signal. Trade ID: ${trade.id}`);

      res.json({
        success: true,
        message: `${action} emri başarıyla oluşturuldu`,
        trade_id: trade.id,
        order_result: result,
      });
    } catch (error) {
      console.error("Error processing signal:", error);
      res.status(500).json({
        success: false,
        message: "Sinyal işlenirken hata oluştu",
        error: error instanceof Error ? error.message : String(error),
      });
    }
  });

  // TRADE ROUTES
  app.get("/api/trades", async (_req: Request, res: Response) => {
    try {
      const trades = await storage.getTrades();
      res.json(trades);
    } catch (error) {
      console.error("Error fetching trades:", error);
      res.status(500).json({ message: "Failed to fetch trades" });
    }
  });

  app.get("/api/bots/:id/trades", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }

      const trades = await storage.getTradesForBot(id);
      res.json(trades);
    } catch (error) {
      console.error("Error fetching trades for bot:", error);
      res.status(500).json({ message: "Failed to fetch trades for bot" });
    }
  });

  app.post("/api/trades", async (req: Request, res: Response) => {
    try {
      console.log(
        "Creating trade with data:",
        JSON.stringify(req.body, null, 2),
      );

      // Gelen verileri manuel olarak doğrulayalım
      const { botId, tradingPair, type, price, amount, status } = req.body;

      // Kritik alanları kontrol edelim
      if (!botId || !tradingPair || !type || !price || !amount || !status) {
        console.error("Missing required fields:", {
          botId: !!botId,
          tradingPair: !!tradingPair,
          type: !!type,
          price: !!price,
          amount: !!amount,
          status: !!status,
        });
        return res.status(400).json({
          message: "Invalid data",
          errors:
            "All required fields must be provided: botId, tradingPair, type, price, amount, status",
        });
      }

      console.log(
        "Trade data validation passed, attempting to create trade in database",
      );

      // Yeni işlemi oluşturalım (açık bir şekilde ZodError'dan kaçınalım)
      const tradeData: any = {
        botId: Number(botId),
        tradingPair,
        type,
        price: Number(price),
        amount: Number(amount),
        status,
      };

      console.log("Normalized trade data:", JSON.stringify(tradeData, null, 2));

      // OKX API'ye işlem gönderme - Demo hesapta izin yoksa bu kısmı atlayacağız
      // Ancak API iletişim loglarını görmek isteyebileceğiniz için başarısız olsa da çağrıya devam ediyoruz
      if (okxClient) {
        try {
          console.log("OKX API'ye işlem istemi gönderilmeye çalışılıyor...");
          console.log(
            "NOTE: Demo hesapta izin yoksa bu işlem başarısız olabilir ancak veritabanına kaydımız gerçekleşecek",
          );

          // Trading pair formatını hazırla
          const instId = formatPair(tradingPair);
          console.log(`Formatlanmış trading pair: ${instId}`);

          // İşlem tipini belirle
          const side = type === "BUY" ? "buy" : "sell";
          const posSide = type === "BUY" ? "long" : "short";

          // Miktar hesaplama (USDT değerini kontrata çevirme)
          // BTC-USDT-SWAP için lot boyutu 0.01'dir
          const rawSize = amount / price;
          // Lot boyutuna göre yuvarlama (0.01 lot boyutu için)
          const lotSize = 0.01;
          const sizeInLots = Math.floor(rawSize / lotSize);
          let orderSize = (sizeInLots * lotSize).toFixed(2); // İki ondalık basamağa sabitleme

          console.log(
            `Hesaplanan ham kontrat büyüklüğü: ${rawSize.toFixed(8)}`,
          );
          console.log(`Lot boyutu: ${lotSize}`);
          console.log(`Lot sayısı: ${sizeInLots}`);
          console.log(
            `Düzeltilmiş kontrat büyüklüğü: ${orderSize} (miktar: ${amount} / fiyat: ${price})`,
          );

          // Kontrol et - minimum 1 lot olmalı
          if (Number(orderSize) < lotSize) {
            console.log(
              `Uyarı: Hesaplanan miktar (${orderSize}) minimum lot boyutundan (${lotSize}) küçük. Minimum lot boyutu kullanılacak.`,
            );
            orderSize = lotSize.toFixed(2);
          }

          try {
            // OKX'e işlem göndermeyi dene ama başarısız olursa sorun değil
            // TP ve SL değerlerini işlemdeki takeProfitLevels ve stopLoss alanlarından al
            const stopLoss = req.body.stopLoss;
            const takeProfitLevels = req.body.takeProfitLevels;

            console.log(`Stop Loss: ${stopLoss}`);
            console.log(
              `Take Profit Levels: ${JSON.stringify(takeProfitLevels)}`,
            );

            // Şu anki fiyatı al
            const currentPrice = price;
            let stopLossPrice = null;
            let takeProfitPrice = null;

            // Stop loss hesapla
            if (stopLoss && stopLoss > 0) {
              stopLossPrice =
                type === "BUY"
                  ? currentPrice * (1 - stopLoss / 100) // Long için stop loss, giriş fiyatının altında
                  : currentPrice * (1 + stopLoss / 100); // Short için stop loss, giriş fiyatının üstünde
              console.log(`Hesaplanan stop loss fiyatı: ${stopLossPrice}`);
            }

            // Take profit hesapla (ana TP emisyonu için ağırlıklı ortalama kullanalım)
            // Tüm TP seviyelerini hesaplayalım
            let totalWeightedTarget = 0;
            let totalVolume = 0;
            
            if (takeProfitLevels && takeProfitLevels.length > 0) {
              // Ağırlıklı ortalama hesapla
              for (const tp of takeProfitLevels) {
                totalWeightedTarget += tp.target * tp.volume;
                totalVolume += tp.volume;
              }
              
              // Ağırlıklı ortalama TP seviyesi
              const weightedTpLevel = totalWeightedTarget / totalVolume;
              console.log(`Ağırlıklı ortalama TP seviyesi: ${weightedTpLevel.toFixed(2)}%`);
              
              // Ağırlıklı ortalama TP fiyatı
              takeProfitPrice = type === "BUY" 
                ? currentPrice * (1 + weightedTpLevel / 100) 
                : currentPrice * (1 - weightedTpLevel / 100);
              
              // Her bir TP seviyesi için detaylı log
              console.log(`Çoklu TP seviyeleri (${takeProfitLevels.length} seviye):`);
              takeProfitLevels.forEach((tp: { target: number; volume: number }, index: number) => {
                const tpPrice = type === "BUY"
                  ? currentPrice * (1 + tp.target / 100)
                  : currentPrice * (1 - tp.target / 100);
                console.log(`  Seviye ${index+1}: Hedef %${tp.target}, Hacim %${tp.volume}, Fiyat ${tpPrice.toFixed(2)}`);
              });
              
              console.log(`Ana TP fiyatı (ağırlıklı ortalama): ${takeProfitPrice}`);
            }

            // Dinamik lot büyüklüğü al
            const dynamicLotSize = await okxClient.getLotSize(instId);
            console.log(`${instId} için dinamik lot büyüklüğü: ${dynamicLotSize}`);
            
            // Dinamik lot büyüklüğüne göre miktarı düzelt
            const rawSizeNum = Number(orderSize);
            const lotCount = Math.floor(rawSizeNum / dynamicLotSize);
            
            // Minimum 1 lot kontrolü
            let adjustedSize = '';
            if (lotCount <= 0) {
              console.log(`Uyarı: Hesaplanan lot sayısı (${lotCount}) geçersiz, minimum lot kullanılıyor`);
              adjustedSize = dynamicLotSize.toString();
            } else {
              const adjustedSizeNum = lotCount * dynamicLotSize;
              adjustedSize = adjustedSizeNum.toString();
            }
            
            console.log(`Son hesaplanan boyut: ${adjustedSize} (${lotCount || 1} lot * ${dynamicLotSize})`);
            
            // OKX API'ye ana emri oluştur (sadece Stop Loss ile)
            console.log("Ana emri oluşturuluyor - çoklu TP seviyesiz");
            const orderResult = await okxClient.createOrder(
              instId,
              side,
              posSide,
              "market",
              adjustedSize, // Düzeltilmiş boyut kullan
              undefined,
              stopLossPrice ? stopLossPrice.toString() : undefined,
              undefined, // TP seviyelerini sadeleştirmek için burada TP kullanmıyoruz
              false,
              takeProfitLevels // Çoklu TP seviyelerini doğrudan geçir
            );

            // Başarılı emir sonucu alındıysa çoklu TP seviyelerini ekle
            if (orderResult?.data && orderResult.data.length > 0 && orderResult.data[0].ordId) {
              const orderId = orderResult.data[0].ordId;
              console.log(`Ana emir oluşturuldu, ID: ${orderId}. Çoklu TP seviyeleri ayarlanıyor...`);
              
              // Çoklu TP seviyelerini ayrı bir işlemle oluştur (createTakeProfitOrders fonksiyonu)
              try {
                const tpResults = await okxClient.createTakeProfitOrders(
                  instId,
                  adjustedSize, // Düzeltilmiş boyut kullan
                  currentPrice,
                  side,
                  posSide,
                  takeProfitLevels
                );
                
                console.log(`${tpResults.length} adet TP seviyesi için algo emirleri oluşturuldu:`);
                console.log(JSON.stringify(tpResults, null, 2));
              } catch (tpError: any) {
                console.error(`Çoklu TP seviyeleri oluşturulurken hata: ${tpError.message || tpError}`);
              }
            } else {
              console.warn("Ana emir ID'si alınamadı, çoklu TP seviyeleri ayarlanamadı");
            }

            console.log(
              "OKX API başarılı yanıt:",
              JSON.stringify(orderResult, null, 2),
            );

            // İşlem bilgisini trade objesine ekle
            if (orderResult?.data && orderResult.data.length > 0 && orderResult.data[0].ordId) {
              tradeData.externalId = orderResult.data[0].ordId;
            }
          } catch (error: any) {
            console.log(
              "OKX API izin hatası (beklenen bir durum):",
              error.message,
            );
            console.log(
              "Bu hata önemli değil, sistem sadece veritabanına kayıt yapacak.",
            );
          }
        } catch (apiError: any) {
          console.error("OKX işlem hazırlama hatası:", apiError.message);
        }
      } else {
        console.warn("OKX client bulunamadı, API işlemi atlanıyor");
      }

      // Veritabanı işlemini gerçekleştirelim
      console.log("Creating trade in database...");
      const newTrade = await storage.createTrade(tradeData);
      console.log(
        "Trade created successfully:",
        JSON.stringify(newTrade, null, 2),
      );

      res.status(201).json(newTrade);
    } catch (error) {
      console.error("Error creating trade:", error);

      if (error instanceof z.ZodError) {
        console.error(
          "ZodError details:",
          JSON.stringify(error.errors, null, 2),
        );
        return res.status(400).json({
          message: "Invalid data format",
          errors: error.errors,
          details: "Please check all required fields have correct format",
        });
      }

      res.status(500).json({ message: "Failed to create trade" });
    }
  });

  app.put("/api/trades/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }

      const existing = await storage.getTrade(id);
      if (!existing) {
        return res.status(404).json({ message: "Trade not found" });
      }

      const updates = req.body;
      console.log(
        `Received update request for trade ${id}:`,
        JSON.stringify(updates, null, 2),
      );

      // İşlemin borsa tarafında kapatılması gerekiyorsa (işlem statüsü CLOSED olarak değiştiriliyorsa)
      if (updates.status === "CLOSED" && existing.status === "OPEN") {
        console.log(
          `[TRADE-CLOSE] İşlem #${id} kapatma isteği alındı - ${existing.tradingPair}`,
        );

        // OKX istemcisini kontrol et
        if (!okxClient) {
          console.log(`[TRADE-CLOSE] OKX istemcisi bulunamadı.`);
          return res.status(400).json({
            success: false,
            message: "OKX istemcisi yapılandırılmamış",
            description: "Pozisyon kapatma için OKX API gerekli.",
          });
        }

        // Trading pair'i formatla
        let instId;
        try {
          // OKX API formatında çifti hazırla
          instId = formatPair(existing.tradingPair);
          console.log(
            `[TRADE-CLOSE] İşlem formatlandı: ${existing.tradingPair} -> ${instId}`,
          );
        } catch (error) {
          // Manuel formatla
          instId = existing.tradingPair.replace("/", "-") + "-SWAP";
          if (!existing.tradingPair.includes("/")) {
            if (existing.tradingPair.endsWith("USDT")) {
              const base = existing.tradingPair.substring(
                0,
                existing.tradingPair.length - 4,
              );
              instId = `${base}-USDT-SWAP`;
            }
          }
          console.log(
            `[TRADE-CLOSE] Manuel formatlandı: ${existing.tradingPair} -> ${instId}`,
          );
        }

        // İşlemin pozisyon tarafını belirle (BUY -> long, SELL -> short)
        const posSide = existing.type === "BUY" ? "long" : "short";
        console.log(`[TRADE-CLOSE] Pozisyon yönü: ${posSide}`);

        try {
          // Pozisyon durumunu kontrol et - getPositions fonksiyonunu kullan (getPosition değil)
          const positions = await okxClient.getPositions(instId);
          
          // Debug için tüm pozisyonları log'a yaz
          console.log(`[TRADE-CLOSE] Tüm pozisyonlar:`, JSON.stringify(positions?.data || [], null, 2));
          
          // Pozisyonları kontrol et
          const positionData = positions && positions.data;
          
          // Önce tam eşleşme (instId ve posSide) arayan bir kontrol yapalım
          let position = Array.isArray(positionData) ? 
                        positionData.find(p => p.instId === instId && p.posSide === posSide) : null;
          
          // Tam eşleşme bulamazsa, sadece instId'ye göre deneyelim (posSide farklı olabilir veya 'net' olabilir)
          if (!position && Array.isArray(positionData)) {
            position = positionData.find(p => p.instId === instId);
            console.log(`[TRADE-CLOSE] Farklı posSide ile pozisyon bulundu:`, position);
          }
          
          // Pozisyon dürümünü logla
          console.log(`[TRADE-CLOSE] Pozisyon durumu:`, position ? 
                      `Bulundu: ${position.instId}, posSide: ${position.posSide}, miktar: ${position.pos}` : 
                      "Pozisyon bulunamadı");
                        
          if (!position || position.pos === "0") {
            console.log(
              `[TRADE-CLOSE] Pozisyon zaten kapalı veya bulunamadı: ${instId}`,
            );
            updates.status = "CLOSED";
            updates.profit = updates.profit || 0;
          } else {
            // Pozisyonu kapat
            console.log(
              `[TRADE-CLOSE] OKX pozisyon kapatma başlatılıyor: ${instId}`,
            );
            const closeResult = await okxClient.closePosition(instId, posSide);

            if (!closeResult.success) {
              console.error(
                `[TRADE-CLOSE] Pozisyon kapatılamadı:`,
                closeResult,
              );
              if (
                isDemoMode &&
                closeResult.error?.includes("PERMISSION_DENIED")
              ) {
                return res.status(400).json({
                  success: false,
                  message: "Demo hesapta pozisyon kapatma izni yok",
                  description:
                    "Lütfen demo hesap izinlerini kontrol edin veya manuel olarak pozisyonu kapatın.",
                });
              }
              // Alternatif kapatma yöntemi: Ters emir oluştur
              try {
                console.log(
                  `[TRADE-CLOSE] Alternatif yöntem: Ters emir oluşturuluyor`,
                );
                const side = posSide === "long" ? "sell" : "buy";
                const closeOrder = await okxClient.createOrder(
                  instId,
                  side,
                  posSide,
                  "market",
                  position.pos, // Pozisyon büyüklüğü
                  existing.leverage?.toString(),
                );
                if (closeOrder.ordId) {
                  console.log(
                    `[TRADE-CLOSE] Ters emir başarıyla oluşturuldu: ${closeOrder.ordId}`,
                  );
                } else {
                  throw new Error("Ters emir oluşturulamadı");
                }
              } catch (altError: any) {
                console.error(`[TRADE-CLOSE] Ters emir hatası:`, altError);
                return res.status(500).json({
                  success: false,
                  message: "Pozisyon kapatılamadı",
                  error: closeResult.error || (altError?.message || 'Bilinmeyen hata'),
                });
              }
            }

            console.log(
              `[TRADE-CLOSE] Pozisyon başarıyla kapatıldı. Yöntem: ${closeResult.method}`,
            );
            if (closeResult.noPositionFound) {
              console.log(
                `[TRADE-CLOSE] Not: Kapatılacak açık pozisyon bulunamadı veya zaten kapalı.`,
              );
            }

            // Gerçek kapanış fiyatı/kârı almaya çalış
            try {
              // Güncel fiyat bilgisini al
              const currentPrice = await okxClient.getCurrentPrice(instId);
              console.log(
                `[TRADE-CLOSE] Güncel ${existing.tradingPair} fiyatı: ${currentPrice}`,
              );

              // Basit bir kâr hesabı
              if (!updates.profit && currentPrice) {
                const priceDiff =
                  existing.type === "BUY"
                    ? currentPrice - existing.price
                    : existing.price - currentPrice;

                const profitAmount = existing.amount * priceDiff;
                updates.profit = profitAmount;
                console.log(
                  `[TRADE-CLOSE] Hesaplanan kâr: ${profitAmount.toFixed(2)} USDT`,
                );
              }
            } catch (priceError) {
              console.log(`[TRADE-CLOSE] Fiyat hesaplama hatası:`, priceError);

              // Fiyat alınamazsa varsayılan değer
              if (!updates.profit) {
                updates.profit = 0;
                updates.needsProfitUpdate = true;
                console.log(
                  `[TRADE-CLOSE] Kâr hesaplanamadı, varsayılan değer (0) kullanıldı.`,
                );
              }
            }
          }
        } catch (error: any) {
          console.error(
            `[TRADE-CLOSE] Pozisyon kapatma hatası: ${error.message}`,
          );
          if (isDemoMode && error.message.includes("PERMISSION_DENIED")) {
            return res.status(400).json({
              success: false,
              message: "Demo hesapta pozisyon kapatma izni yok",
              description:
                "Lütfen demo hesap izinlerini kontrol edin veya manuel olarak pozisyonu kapatın.",
            });
          }
          return res.status(500).json({
            success: false,
            message: "Pozisyon kapatılamadı",
            error: error.message,
          });
        }
      }

      // Veritabanında güncelleme yap
      const updated = await storage.updateTrade(id, updates);
      console.log(
        `Trade updated successfully: ${JSON.stringify(updated, null, 2)}`,
      );
      res.json(updated);
    } catch (error) {
      console.error("Error updating trade:", error);

      if (error instanceof z.ZodError) {
        return res
          .status(400)
          .json({ message: "Invalid data", errors: error.errors });
      }

      res.status(500).json({ message: "Failed to update trade" });
    }
  });

  // Create the HTTP server
  const httpServer = createServer(app);
  return httpServer;
}
